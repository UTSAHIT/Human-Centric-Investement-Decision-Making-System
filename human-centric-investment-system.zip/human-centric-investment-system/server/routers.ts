import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { marketRouter } from "./routers/market";
import { predictionsRouter } from "./routers/predictions";
import { quizRouter } from "./routers/quiz";
import { portfolioRouter } from "./routers/portfolio";
import { alertsRouter } from "./routers/alerts";
import { z } from "zod";
import * as crypto from "crypto";
import { getDb } from "./db";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { sessionStore } from "./_core/sessionStore";
import { userStore } from "./_core/userStore";
import { ENV } from "./_core/env";

const simpleHash = (password: string, salt: string): string => {
  return crypto.createHash("sha256").update(password + salt).digest("hex");
};

const LoginSchema = z.object({
  email: z.string().min(1),
  password: z.string().min(1),
});

const RegisterSchema = z.object({
  name: z.string().min(1),
  email: z.string().min(1),
  password: z.string().min(1),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      return ctx.user || null;
    }),
    
    register: publicProcedure
      .input(RegisterSchema)
      .mutation(async ({ input }) => {
        if (userStore.has(input.email)) {
          return { error: "Email already registered" };
        }
        
        const userId = userStore.getNextId();
        userStore.set(input.email, {
          id: userId,
          name: input.name,
          email: input.email,
          password: input.password,
        });
        
        const sessionToken = crypto.randomBytes(32).toString("hex");
        const expiryDays = parseInt(ENV.SESSION_EXPIRY_DAYS) || 30;
        sessionStore.set(sessionToken, {
          userId,
          email: input.email,
          name: input.name,
          expiresAt: Date.now() + expiryDays * 24 * 60 * 60 * 1000,
        });
        
        return { 
          success: true, 
          token: sessionToken, 
          user: { id: userId, name: input.name, email: input.email }
        };
      }),
    
    login: publicProcedure
      .input(LoginSchema)
      .mutation(async ({ input }) => {
        const user = userStore.get(input.email);
        if (!user || user.password !== input.password) {
          return { error: "Invalid email or password" };
        }
        
        const sessionToken = crypto.randomBytes(32).toString("hex");
        const expiryDays = parseInt(ENV.SESSION_EXPIRY_DAYS) || 30;
        sessionStore.set(sessionToken, {
          userId: user.id,
          email: user.email,
          name: user.name,
          expiresAt: Date.now() + expiryDays * 24 * 60 * 60 * 1000,
        });
        
        return { 
          success: true, 
          token: sessionToken, 
          user: { id: user.id, name: user.name, email: user.email }
        };
      }),
    
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true };
    }),
  }),

  market: marketRouter,
  predictions: predictionsRouter,
  quiz: quizRouter,
  portfolio: portfolioRouter,
  alerts: alertsRouter,
});

export type AppRouter = typeof appRouter;
