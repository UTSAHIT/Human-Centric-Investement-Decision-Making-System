import pino from "pino";
import { ENV } from "./env";

const transport = ENV.NODE_ENV === "production" 
  ? { target: "pino-pretty" }
  : { target: "pino-pretty", options: { colorize: true } };

export const logger = pino({
  level: ENV.NODE_ENV === "production" ? "info" : "debug",
  transport: transport as any,
  formatters: {
    level: (label: string) => { return { level: label }; },
  },
});

logger.info("Logger initialized");