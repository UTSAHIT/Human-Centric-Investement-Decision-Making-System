import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.string().default("3000"),
  
  // Database (optional - app works without)
  DB_HOST: z.string().optional(),
  DB_PORT: z.string().default("3306"),
  DB_USER: z.string().optional(),
  DB_PASSWORD: z.string().optional(),
  DB_NAME: z.string().optional(),
  DATABASE_URL: z.string().optional(),
  
  // Redis (optional - falls back to in-memory)
  REDIS_URL: z.string().optional(),
  
  // External APIs
  ALPHA_VANTAGE_API_KEY: z.string().optional(),
  FINNHUB_API_KEY: z.string().optional(),
  TWELVE_DATA_API_KEY: z.string().optional(),
  BYTEZ_API_KEY: z.string().optional(),
  
  // Auth
  JWT_SECRET: z.string().optional(),
  
  // Session config
  SESSION_SECRET: z.string().default("dev-secret-change-in-production"),
  SESSION_EXPIRY_DAYS: z.string().default("30"),
  
  // Rate limiting
  RATE_LIMIT_WINDOW_MS: z.string().default("900000"),
  RATE_LIMIT_MAX_REQUESTS: z.string().default("100"),
  
  // OAuth
  OAUTH_SERVER_URL: z.string().optional(),
  VITE_APP_ID: z.string().optional(),
  VITE_OAUTH_PORTAL_URL: z.string().optional(),
  OWNER_OPEN_ID: z.string().optional(),
  
  // Forge
  BUILT_IN_FORGE_API_KEY: z.string().optional(),
  BUILT_IN_FORGE_API_URL: z.string().optional(),
});

export type EnvConfig = z.infer<typeof envSchema>;

let envConfig: EnvConfig | null = null;

export const ENV: EnvConfig & {
  alphaVantageApiKey?: string;
  finnhubApiKey?: string;
  twelveDataApiKey?: string;
  bytezApiUrl?: string;
  bytezApiKey?: string;
  forgeApiUrl?: string;
  forgeApiKey?: string;
  oAuthPortalUrl?: string;
  appId?: string;
  oAuthServerUrl?: string;
  cookieSecret?: string;
  isProduction?: boolean;
  databaseUrl?: string;
  ownerOpenId?: string;
} = {
  NODE_ENV: process.env.NODE_ENV as any || "development",
  PORT: process.env.PORT || "3000",
  DB_HOST: process.env.DB_HOST,
  DB_PORT: process.env.DB_PORT || "3306",
  DB_USER: process.env.DB_USER,
  DB_PASSWORD: process.env.DB_PASSWORD,
  DB_NAME: process.env.DB_NAME,
  DATABASE_URL: process.env.DATABASE_URL,
  REDIS_URL: process.env.REDIS_URL,
  ALPHA_VANTAGE_API_KEY: process.env.ALPHA_VANTAGE_API_KEY,
  FINNHUB_API_KEY: process.env.FINNHUB_API_KEY,
  TWELVE_DATA_API_KEY: process.env.TWELVE_DATA_API_KEY,
  BYTEZ_API_KEY: process.env.BYTEZ_API_KEY,
  JWT_SECRET: process.env.JWT_SECRET,
  SESSION_SECRET: process.env.SESSION_SECRET || "dev-secret-change-in-production",
  SESSION_EXPIRY_DAYS: process.env.SESSION_EXPIRY_DAYS || "30",
  RATE_LIMIT_WINDOW_MS: process.env.RATE_LIMIT_WINDOW_MS || "900000",
  RATE_LIMIT_MAX_REQUESTS: process.env.RATE_LIMIT_MAX_REQUESTS || "100",
  OAUTH_SERVER_URL: process.env.OAUTH_SERVER_URL,
  VITE_APP_ID: process.env.VITE_APP_ID,
  VITE_OAUTH_PORTAL_URL: process.env.VITE_OAUTH_PORTAL_URL,
  OWNER_OPEN_ID: process.env.OWNER_OPEN_ID,
  BUILT_IN_FORGE_API_KEY: process.env.BUILT_IN_FORGE_API_KEY,
  BUILT_IN_FORGE_API_URL: process.env.BUILT_IN_FORGE_API_URL,
  // Aliases for backward compatibility
  alphaVantageApiKey: process.env.ALPHA_VANTAGE_API_KEY,
  finnhubApiKey: process.env.FINNHUB_API_KEY,
  twelveDataApiKey: process.env.TWELVE_DATA_API_KEY,
  bytezApiUrl: process.env.BYTEZ_API_KEY ? "https://api.bytez.io" : undefined,
  bytezApiKey: process.env.BYTEZ_API_KEY,
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL,
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY,
  oAuthPortalUrl: process.env.VITE_OAUTH_PORTAL_URL,
  appId: process.env.VITE_APP_ID,
  oAuthServerUrl: process.env.OAUTH_SERVER_URL,
  cookieSecret: process.env.JWT_SECRET,
  isProduction: process.env.NODE_ENV === "production",
  databaseUrl: process.env.DATABASE_URL,
  ownerOpenId: process.env.OWNER_OPEN_ID,
};

export function validateEnv(): EnvConfig {
  if (envConfig) return envConfig;
  
  const result = envSchema.safeParse(process.env);
  
  if (!result.success) {
    console.error("❌ Environment validation failed:");
    result.error.issues.forEach(issue => {
      console.error(`  - ${issue.path.join(".")}: ${issue.message}`);
    });
    throw new Error("Invalid environment configuration");
  }
  
  envConfig = result.data;
  
  console.log("✅ Environment validated successfully");
  console.log(`   Mode: ${envConfig.NODE_ENV}`);
  console.log(`   Redis: ${envConfig.REDIS_URL ? "enabled" : "disabled (using in-memory)"}`);
  console.log(`   Rate Limiting: ${envConfig.RATE_LIMIT_MAX_REQUESTS} req/${Number(envConfig.RATE_LIMIT_WINDOW_MS)/1000/60}min`);
  
  return envConfig;
}

export function getEnv(): EnvConfig {
  return ENV;
}