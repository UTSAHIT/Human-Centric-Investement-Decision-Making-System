import { ENV } from "./env";
import fs from "fs/promises";
import path from "path";

interface User {
  id: number;
  name: string;
  email: string;
  password: string;
}

interface StoredUserData {
  users: [string, User][];
  nextId: number;
  profiles: [number, UserProfile][];
}

class UserStore {
  private users: Map<string, User> = new Map();
  private nextId: number = 1;
  private useRedis: boolean = false;
  private redis: any = null;
  private dataPath: string = "";
  private profiles: Map<number, UserProfile> = new Map();

  async init(): Promise<void> {
    if (ENV.REDIS_URL) {
      try {
        const Redis = (await import("ioredis")).default;
        this.redis = new Redis(ENV.REDIS_URL, { lazyConnect: true });
        await this.redis.connect();
        this.useRedis = true;
        console.log("✅ Redis user store connected");
        return;
      } catch (e) {
        console.warn("⚠️  Redis user store failed, using file-based");
      }
    }
    
    try {
      this.dataPath = path.join(process.cwd(), ".users.json");
      
      const fileData = await fs.readFile(this.dataPath, "utf-8");
      const data: StoredUserData = JSON.parse(fileData);
      this.users = new Map(data.users || []);
      this.nextId = data.nextId || 1;
      this.profiles = new Map(data.profiles || []);
      console.log(`✅ Loaded ${this.users.size} users and ${this.profiles.size} profiles from file`);
    } catch (e: any) {
      if (e.code !== "ENOENT") {
        console.warn("⚠️  Could not load users from file:", e.message);
      } else {
        console.log("📄 No existing users file, starting fresh");
      }
    }
    
    console.log("📁 Using file-based user store");
  }

  private async saveToFile(): Promise<void> {
    if (!this.dataPath) return;
    
    try {
      const data: StoredUserData = {
        users: Array.from(this.users.entries()),
        nextId: this.nextId,
        profiles: Array.from(this.profiles.entries()),
      };
      await fs.writeFile(this.dataPath, JSON.stringify(data, null, 2));
    } catch (e: any) {
      console.error("Failed to save users:", e.message);
    }
  }

  set(email: string, user: User): void {
    this.users.set(email, user);
    this.saveToFile().catch(() => {});
  }

  get(email: string): User | undefined {
    return this.users.get(email);
  }

  has(email: string): boolean {
    return this.users.has(email);
  }

  getNextId(): number {
    return this.nextId++;
  }

  getProfile(userId: number): UserProfile | undefined {
    return this.profiles.get(userId);
  }

  setProfile(userId: number, profile: UserProfile): void {
    this.profiles.set(userId, profile);
    this.saveToFile().catch(() => {});
  }

  cleanup(): void {
    if (this.redis) {
      this.redis.quit().catch(() => {});
    }
  }
}

export interface UserProfile {
  riskTolerance: string;
  investmentGoal: string | null;
  timeHorizon: string;
  experienceLevel: string;
  monthlyInvestment: string | null;
  quizResponses: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export const userStore = new UserStore();