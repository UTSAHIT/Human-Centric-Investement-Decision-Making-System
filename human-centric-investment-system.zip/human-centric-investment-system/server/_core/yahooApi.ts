/**
 * Free Stock API Integration
 * Provides real-time stock data from multiple free APIs
 * Priority: Alpha Vantage > Finnhub > Twelve Data > Direct Yahoo
 */

import { ENV } from "./env";

interface CacheEntry<T> {
  data: T;
  expiry: number;
}

class YahooCache {
  private cache: Map<string, CacheEntry<any>> = new Map();
  
  get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (entry && entry.expiry > Date.now()) {
      return entry.data as T;
    }
    this.cache.delete(key);
    return null;
  }
  
  set<T>(key: string, data: T, ttl: number = 60000): void {
    this.cache.set(key, { data, expiry: Date.now() + ttl });
  }
  
  clear(): void {
    this.cache.clear();
  }
}

export const yahooCache = new YahooCache();

// Clear cache on startup to ensure fresh data
yahooCache.clear();
console.log("[Cache] Cache cleared for fresh data");

// ==================== ALPHA VANTAGE (Primary - with API key) ====================
const ALPHA_VANTAGE_BASE = "https://www.alphavantage.co/query";

export async function fetchAlphaVantageQuote(symbol: string): Promise<{
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  open: number;
  high: number;
  low: number;
  volume: number;
  prevClose: number;
} | null> {
  const key = ENV.alphaVantageApiKey;
  if (!key) return null;
  
  const cacheKey = `av:${symbol.toUpperCase()}`;
  const cached = yahooCache.get<any>(cacheKey);
  if (cached) return cached;
  
  try {
    const url = `${ALPHA_VANTAGE_BASE}?function=GLOBAL_QUOTE&symbol=${encodeURIComponent(symbol)}&apikey=${key}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    
    if (!response.ok) return null;
    
    const data = await response.json();
    const quote = data["Global Quote"];
    
    if (!quote || !quote["05. price"] || parseFloat(quote["05. price"]) === 0) {
      return null;
    }
    
    const result = {
      symbol: quote["01. symbol"] || symbol.toUpperCase(),
      name: symbol.toUpperCase(),
      price: parseFloat(quote["05. price"]) || 0,
      change: parseFloat(quote["09. change"]) || 0,
      changePercent: parseFloat(quote["10. change percent"]?.replace("%", "")) || 0,
      open: parseFloat(quote["02. open"]) || 0,
      high: parseFloat(quote["03. high"]) || 0,
      low: parseFloat(quote["04. low"]) || 0,
      volume: parseInt(quote["06. volume"]) || 0,
      prevClose: parseFloat(quote["08. previous close"]) || 0
    };
    
    if (result.price > 0) {
      yahooCache.set(cacheKey, result, 60000);
      console.log(`[Alpha Vantage] ✓ ${result.symbol}: $${result.price}`);
      return result;
    }
    
    return null;
  } catch (err) {
    console.warn(`[Alpha Vantage] Failed for ${symbol}:`, (err as any).message);
    return null;
  }
}

export async function fetchAlphaVantageSearch(query: string): Promise<any[]> {
  const key = ENV.alphaVantageApiKey;
  if (!key) return [];
  
  const cacheKey = `avs:${query.toLowerCase()}`;
  const cached = yahooCache.get<any[]>(cacheKey);
  if (cached) return cached;
  
  try {
    const url = `${ALPHA_VANTAGE_BASE}?function=SYMBOL_SEARCH&keywords=${encodeURIComponent(query)}&apikey=${key}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    
    if (!response.ok) return [];
    
    const data = await response.json();
    const matches = data.bestMatches || [];
    
    const results = matches.slice(0, 20).map((m: any) => ({
      symbol: m["1. symbol"],
      shortName: m["2. name"],
      longName: m["2. name"],
      exchange: m["4. region"] || "NASDAQ",
      type: m["3. type"] === "Mutual Fund" ? "mutual_fund" : "stock",
      quoteType: m["3. type"] === "Mutual Fund" ? "MUTUALFUND" : "EQUITY"
    }));
    
    if (results.length > 0) {
      yahooCache.set(cacheKey, results, 300000);
      console.log(`[Alpha Vantage Search] Found ${results.length} results for "${query}"`);
    }
    
    return results;
  } catch (err) {
    console.warn(`[Alpha Vantage Search] Failed for "${query}":`, (err as any).message);
    return [];
  }
}

export async function fetchAlphaVantageTimeSeries(symbol: string): Promise<any[]> {
  const key = ENV.alphaVantageApiKey;
  if (!key) return [];
  
  try {
    const url = `${ALPHA_VANTAGE_BASE}?function=TIME_SERIES_DAILY&symbol=${encodeURIComponent(symbol)}&outputsize=compact&apikey=${key}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    
    if (!response.ok) return [];
    
    const data = await response.json();
    const timeSeries = data["Time Series (Daily)"];
    
    if (!timeSeries) return [];
    
    return Object.entries(timeSeries)
      .map(([date, values]: [string, any]) => ({
        timestamp: new Date(date),
        close: parseFloat(values["4. close"]),
        open: parseFloat(values["1. open"]),
        high: parseFloat(values["2. high"]),
        low: parseFloat(values["3. low"]),
        volume: parseInt(values["5. volume"])
      }))
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
      .slice(-100);
  } catch (err) {
    console.warn(`[Alpha Vantage Chart] Failed for ${symbol}:`, (err as any).message);
    return [];
  }
}

// ==================== FINNHUB (Secondary - with API key) ====================
export async function fetchFinnhubQuote(symbol: string, apiKey?: string): Promise<{
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  open: number;
  high: number;
  low: number;
  prevClose: number;
} | null> {
  const key = apiKey || ENV.FINNHUB_API_KEY || ENV.FINNHUB_API_KEY;
  if (!key) return null;
  
  const cacheKey = `fh:${symbol.toUpperCase()}`;
  const cached = yahooCache.get<any>(cacheKey);
  if (cached) return cached;
  
  try {
    const url = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${key}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    
    if (!response.ok) return null;
    
    const data = await response.json();
    if (!data.c || data.c === 0) return null;
    
    const result = {
      symbol: symbol.toUpperCase(),
      name: symbol.toUpperCase(),
      price: data.c,
      change: data.d,
      changePercent: data.dp,
      open: data.o,
      high: data.h,
      low: data.l,
      prevClose: data.pc
    };
    
    yahooCache.set(cacheKey, result, 60000);
    console.log(`[Finnhub] ✓ ${result.symbol}: $${result.price}`);
    return result;
  } catch (err) {
    console.warn(`[Finnhub] Failed for ${symbol}:`, (err as any).message);
    return null;
  }
}

// ==================== DIRECT YAHOO (Tertiary - no auth) ====================
const YAHOO_HEADERS = {
  "Accept": "application/json, text/plain, */*",
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Accept-Language": "en-US,en;q=0.9",
  "Origin": "https://finance.yahoo.com",
  "Referer": "https://finance.yahoo.com/"
};

export async function fetchYahooDirectQuote(symbol: string): Promise<{
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  open: number;
  high: number;
  low: number;
  volume: number;
  prevClose: number;
} | null> {
  const cacheKey = `yahoo:${symbol.toUpperCase()}`;
  const cached = yahooCache.get<any>(cacheKey);
  if (cached) return cached;
  
  try {
    // Try chart endpoint first
    const chartUrl = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1d&range=1d`;
    const response = await fetch(chartUrl, { 
      headers: YAHOO_HEADERS,
      signal: AbortSignal.timeout(10000)
    });
    
    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        console.log(`[Yahoo Direct] Auth required for ${symbol}`);
        return null;
      }
      return null;
    }
    
    const data = await response.json();
    const result = data?.chart?.result?.[0];
    
    if (!result) return null;
    
    const meta = result.meta;
    if (!meta?.regularMarketPrice) return null;
    
    const price = meta.regularMarketPrice;
    const prevClose = meta.chartPreviousClose || meta.previousClose || price;
    
    const output = {
      symbol: meta.symbol || symbol.toUpperCase(),
      name: meta.shortName || meta.longName || symbol.toUpperCase(),
      price: price,
      change: price - prevClose,
      changePercent: prevClose > 0 ? ((price - prevClose) / prevClose) * 100 : 0,
      open: meta.regularMarketOpen || prevClose,
      high: meta.regularMarketDayHigh || price,
      low: meta.regularMarketDayLow || price,
      volume: meta.regularMarketVolume || 0,
      prevClose: prevClose
    };
    
    yahooCache.set(cacheKey, output, 30000);
    console.log(`[Yahoo Direct] ✓ ${output.symbol}: $${output.price}`);
    return output;
  } catch (err) {
    console.warn(`[Yahoo Direct] Failed for ${symbol}:`, (err as any).message);
    return null;
  }
}

// ==================== LEGACY EXPORTS FOR COMPATIBILITY ====================

// Stock prices - tries multiple sources, returns full data
export async function fetchStockPrices(symbol: string): Promise<{
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  open?: number;
  high?: number;
  low?: number;
  volume?: number;
  prevClose?: number;
} | null> {
  const sym = symbol.toUpperCase();
  
  // Try Alpha Vantage first
  const avQuote = await fetchAlphaVantageQuote(sym);
  if (avQuote && avQuote.price > 0) {
    return avQuote;
  }
  
  // Try Finnhub
  const fhQuote = await fetchFinnhubQuote(sym);
  if (fhQuote && fhQuote.price > 0) {
    return fhQuote;
  }
  
  // Try Yahoo Direct
  const yQuote = await fetchYahooDirectQuote(sym);
  if (yQuote && yQuote.price > 0) {
    return yQuote;
  }
  
  console.warn(`[fetchStockPrices] All sources failed for ${sym}`);
  return null;
}

// Legacy export
export const fetchYahooQuote = fetchStockPrices;

// Search stocks
export async function searchStocks(query: string): Promise<any[]> {
  if (!query || query.trim().length < 1) return [];
  
  // Try Yahoo Finance screener API for real stock data
  try {
    const searchUrl = `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=20&newsCount=0`;
    const response = await fetch(searchUrl, {
      headers: YAHOO_HEADERS,
      signal: AbortSignal.timeout(8000)
    });
    
    if (response.ok) {
      const data = await response.json();
      const quotes = data?.quotes || [];
      
      if (quotes.length > 0) {
        const results = quotes
          .filter((q: any) => q.quoteType === "EQUITY" || q.quoteType === "ETF")
          .map((q: any) => ({
            symbol: q.symbol,
            shortName: q.shortname || q.symbol,
            longName: q.longname || q.shortname || q.symbol,
            exchange: q.exchange || "N/A",
            type: q.quoteType === "ETF" ? "mutual_fund" : "stock",
            quoteType: q.quoteType || "EQUITY",
            sector: q.sector || null,
            industry: q.industry || null
          }));
        
        if (results.length > 0) {
          console.log(`[Search] Yahoo Finance found ${results.length} results for "${query}"`);
          return results;
        }
      }
    }
  } catch (yahooErr) {
    console.warn(`[Search] Yahoo Finance search failed:`, (yahooErr as any).message);
  }

  // Try Alpha Vantage search as fallback
  try {
    const avResults = await fetchAlphaVantageSearch(query);
    if (avResults.length > 0) {
      console.log(`[Search] Alpha Vantage found ${avResults.length} results for "${query}"`);
      return avResults;
    }
  } catch (avErr) {
    console.warn(`[Search] Alpha Vantage search failed:`, (avErr as any).message);
  }
  
  // If all APIs fail, search curated list
  console.log(`[Search] Falling back to curated list for "${query}"`);
  return [];
}

// Legacy exports
export async function fetchYahooJson(url: string, cacheKey?: string, ttl?: number): Promise<any> {
  try {
    const response = await fetch(url, {
      headers: YAHOO_HEADERS,
      signal: AbortSignal.timeout(10000)
    });
    if (!response.ok) return {};
    return await response.json();
  } catch (err) {
    console.warn(`[fetchYahooJson] Failed:`, (err as any).message);
    return {};
  }
}

export async function fetchYahooChartPrices(symbol: string, range: string = "1y"): Promise<number[]> {
  // Try Alpha Vantage first for historical data
  const avData = await fetchAlphaVantageTimeSeries(symbol);
  if (avData.length > 0) {
    return avData.map(d => d.close);
  }
  
  // Try Yahoo chart endpoint
  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=${range}&interval=1d`;
    const data = await fetchYahooJson(url);
    const closes = data?.chart?.result?.[0]?.indicators?.quote?.[0]?.close;
    if (closes) {
      return (closes as (number | null)[]).filter((p): p is number => typeof p === "number" && p > 0);
    }
  } catch {}
  
  return [];
}

export async function fetchYahooScreener(screeners: string[], count: number = 50): Promise<any[]> {
  // Not implemented - return empty
  return [];
}

// Twelve Data support
export async function fetchTwelveDataQuote(symbol: string, apiKey: string): Promise<{
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
} | null> {
  if (!apiKey) return null;
  
  try {
    const url = `https://api.twelvedata.com/price?symbol=${encodeURIComponent(symbol)}&apikey=${apiKey}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    
    if (!response.ok) return null;
    
    const data = await response.json();
    if (data.status === "error" || !data.price) return null;
    
    return {
      symbol: symbol.toUpperCase(),
      name: symbol.toUpperCase(),
      price: parseFloat(data.price),
      change: parseFloat(data.change || 0),
      changePercent: parseFloat(data.percent_change || 0)
    };
  } catch {
    return null;
  }
}

export async function fetchFinnhubCandles(symbol: string, resolution: string = "D", from?: number, to?: number): Promise<number[]> {
  const key = ENV.FINNHUB_API_KEY;
  if (!key) return [];

  const now = Math.floor(Date.now() / 1000);
  const fromTs = from || now - 365 * 24 * 60 * 60;
  const toTs = to || now;

  try {
    const url = `https://finnhub.io/api/v1/series/candle?symbol=${encodeURIComponent(symbol.toUpperCase())}&resolution=${resolution}&from=${fromTs}&to=${toTs}&token=${key}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!response.ok) return [];

    const data = await response.json();
    if (data.s !== "ok" || !data.c || data.c.length === 0) return [];

    return data.c;
  } catch {
    return [];
  }
}

// Fetch mutual fund NAV data via Yahoo Finance
export async function fetchYahooFundNAV(symbol: string): Promise<{ nav: number; change: number; changePercent: number } | null> {
  const cacheKey = `fundNav:${symbol.toUpperCase()}`;
  const cached = yahooCache.get<any>(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol.toUpperCase())}?range=5d&interval=1d`;
    const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!response.ok) return null;

    const json = await response.json();
    const result = json?.chart?.result?.[0];
    if (!result) return null;

    const closes = result.indicators?.quote?.[0]?.close as (number | null)[] | undefined;
    const valid = (closes || []).filter((p): p is number => typeof p === "number" && p > 0);

    if (valid.length === 0) return null;

    const nav = valid[valid.length - 1];
    const prevNav = valid.length >= 2 ? valid[valid.length - 2] : nav;
    const change = nav - prevNav;
    const changePercent = prevNav > 0 ? (change / prevNav) * 100 : 0;

    const data = { nav, change, changePercent };
    yahooCache.set(cacheKey, data, 300000);
    return data;
  } catch {
    return null;
  }
}

// Fetch mutual fund historical NAV for charts via Yahoo
export async function fetchYahooFundChart(symbol: string, range: string = "3mo"): Promise<number[]> {
  const cacheKey = `fundChart:${symbol.toUpperCase()}:${range}`;
  const cached = yahooCache.get<number[]>(cacheKey);
  if (cached && cached.length > 0) return cached;

  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol.toUpperCase())}?range=${range}&interval=1d`;
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!response.ok) return [];

    const json = await response.json();
    const closes = json?.chart?.result?.[0]?.indicators?.quote?.[0]?.close as (number | null)[] | undefined;
    const valid = (closes || []).filter((p): p is number => typeof p === "number" && p > 0);

    if (valid.length > 0) {
      yahooCache.set(cacheKey, valid, 3600000);
      return valid;
    }
  } catch {}

  return [];
}

export async function fetchFinnhubSearch(query: string, apiKey: string): Promise<any[]> {
  if (!apiKey) return [];
  
  try {
    const url = `https://finnhub.io/api/v1/search?q=${encodeURIComponent(query)}&token=${apiKey}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
    
    if (!response.ok) return [];
    
    const data = await response.json();
    if (!data.result) return [];
    
    return data.result.slice(0, 10).map((r: any) => ({
      symbol: r.symbol,
      shortName: r.description || r.symbol,
      longName: r.description || r.symbol,
      exchange: r.exchange || "N/A",
      type: "stock",
      quoteType: "EQUITY"
    }));
  } catch {
    return [];
  }
}