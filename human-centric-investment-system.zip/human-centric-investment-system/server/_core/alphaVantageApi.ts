/**
 * Alpha Vantage API Integration
 * Real-time stock and mutual fund data fetching using Alpha Vantage.
 * This client is fully dependent on the configured Alpha Vantage API key.
 */

import { ENV } from "./env";

const BASE_URL = "https://www.alphavantage.co/query";

export interface AlphaVantageQuote {
  symbol: string;
  name: string;
  type: "stock" | "mutual_fund";
  price: number;
  change: number;
  changePercent: number;
  open: number;
  high: number;
  low: number;
  volume: number;
  marketCap?: number;
  peRatio?: number;
  dividendYield?: number;
  exchange?: string;
  sector?: string;
  industry?: string;
}

export interface AlphaVantageTimeSeries {
  timestamp: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// In-Memory TTL Cache for Alpha Vantage responses to bypass standard limits and preserve key allocation
const searchCache = new Map<string, { data: AlphaVantageQuote[]; expiry: number }>();
const quoteCache = new Map<string, { data: AlphaVantageQuote; expiry: number }>();
const overviewCache = new Map<string, { data: any; expiry: number }>();
const timeSeriesCache = new Map<string, { data: AlphaVantageTimeSeries[]; expiry: number }>();
const technicalCache = new Map<string, { data: any; expiry: number }>();

// Core Alpha Vantage Fetcher dependent on ENV.alphaVantageApiKey
async function fetchFromAlphaVantage(params: Record<string, string>): Promise<any> {
  const fullParams: Record<string, string> = {
    ...params,
    apikey: ENV.alphaVantageApiKey || "",
  };

  const queryString = new URLSearchParams(fullParams).toString();
  const url = `${BASE_URL}?${queryString}`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Alpha Vantage API error: ${response.status}`);
    }
    const data = await response.json();

    // Check for API errors
    if (data["Error Message"]) {
      throw new Error(`Alpha Vantage Error: ${data["Error Message"]}`);
    }
    if (data["Note"]) {
      console.warn("[Alpha Vantage Rate Limit Note]", data["Note"]);
      throw new Error("Alpha Vantage API rate limit reached");
    }

    return data;
  } catch (error) {
    console.error("[Alpha Vantage]", error);
    throw error;
  }
}

/**
 * Search for stocks and mutual funds
 */
export async function searchSymbols(query: string): Promise<AlphaVantageQuote[]> {
  const cacheKey = query.toLowerCase().trim();
  if (!cacheKey) return [];
  const cached = searchCache.get(cacheKey);
  if (cached && cached.expiry > Date.now()) {
    console.log(`[Alpha Vantage Cache] HIT for searchSymbols: "${query}"`);
    return cached.data;
  }

  try {
    const data = await fetchFromAlphaVantage({
      function: "SYMBOL_SEARCH",
      keywords: query,
    });

    if (!data.bestMatches) {
      return [];
    }

    const results = data.bestMatches.slice(0, 10).map((match: any) => ({
      symbol: match["1. symbol"],
      name: match["2. name"],
      type: match["3. type"] === "Mutual Fund" ? "mutual_fund" : "stock",
      price: 0,
      change: 0,
      changePercent: 0,
      open: 0,
      high: 0,
      low: 0,
      volume: 0,
      exchange: match["4. region"],
      currency: match["8. currency"],
    }));

    // Cache search results for 1 hour to optimize key usages
    searchCache.set(cacheKey, { data: results, expiry: Date.now() + 3600000 });
    return results;
  } catch (error) {
    console.error("[Alpha Vantage Search]", error);
    return [];
  }
}

/**
 * Get real-time quote data for a symbol
 */
export async function getQuote(symbol: string): Promise<AlphaVantageQuote | null> {
  const cacheKey = symbol.toUpperCase().trim();
  if (!cacheKey) return null;
  const cached = quoteCache.get(cacheKey);
  if (cached && cached.expiry > Date.now()) {
    console.log(`[Alpha Vantage Cache] HIT for getQuote: "${symbol}"`);
    return cached.data;
  }

  try {
    const data = await fetchFromAlphaVantage({
      function: "GLOBAL_QUOTE",
      symbol: symbol,
    });

    const quote = data["Global Quote"];
    if (!quote || Object.keys(quote).length === 0) {
      return null;
    }

    const result: AlphaVantageQuote = {
      symbol: quote["01. symbol"] || symbol,
      name: symbol,
      type: "stock",
      price: parseFloat(quote["05. price"]) || 0,
      change: parseFloat(quote["09. change"]) || 0,
      changePercent: parseFloat(quote["10. change percent"]?.replace("%", "")) || 0,
      open: parseFloat(quote["02. open"]) || 0,
      high: parseFloat(quote["03. high"]) || 0,
      low: parseFloat(quote["04. low"]) || 0,
      volume: parseInt(quote["06. volume"]) || 0,
    };

    // Cache quotes for 5 minutes
    quoteCache.set(cacheKey, { data: result, expiry: Date.now() + 300000 });
    return result;
  } catch (error) {
    console.error(`[Alpha Vantage Quote] Error for ${symbol}:`, error);
    return null;
  }
}

/**
 * Get company fundamental profile details
 */
export async function getCompanyOverview(symbol: string): Promise<any> {
  const cacheKey = symbol.toUpperCase().trim();
  if (!cacheKey) return null;
  const cached = overviewCache.get(cacheKey);
  if (cached && cached.expiry > Date.now()) {
    console.log(`[Alpha Vantage Cache] HIT for getCompanyOverview: "${symbol}"`);
    return cached.data;
  }

  try {
    const data = await fetchFromAlphaVantage({
      function: "OVERVIEW",
      symbol: symbol,
    });

    if (!data || !data["Symbol"]) {
      return null;
    }

    const result = {
      symbol: data["Symbol"],
      name: data["Name"],
      sector: data["Sector"],
      industry: data["Industry"],
      marketCap: parseInt(data["MarketCapitalization"]) || undefined,
      peRatio: parseFloat(data["PERatio"]),
      dividendYield: parseFloat(data["DividendYield"]),
      description: data["Description"],
      exchange: data["Exchange"],
      currency: data["Currency"],
    };

    // Cache overview for 24 hours to maximize key life span
    overviewCache.set(cacheKey, { data: result, expiry: Date.now() + 86400000 });
    return result;
  } catch (error) {
    console.error(`[Alpha Vantage Overview] Error for ${symbol}:`, error);
    return null;
  }
}

/**
 * Get daily historical time series data
 */
export async function getTimeSeriesDaily(
  symbol: string,
  outputSize: "compact" | "full" = "full"
): Promise<AlphaVantageTimeSeries[]> {
  const cacheKey = `${symbol.toUpperCase().trim()}_${outputSize}`;
  const cached = timeSeriesCache.get(cacheKey);
  if (cached && cached.expiry > Date.now()) {
    console.log(`[Alpha Vantage Cache] HIT for getTimeSeriesDaily: "${symbol}"`);
    return cached.data;
  }

  try {
    const data = await fetchFromAlphaVantage({
      function: "TIME_SERIES_DAILY",
      symbol: symbol,
      outputsize: outputSize,
    });

    const timeSeries = data["Time Series (Daily)"];
    if (!timeSeries) {
      return [];
    }

    const results = Object.entries(timeSeries)
      .map(([dateStr, values]: [string, any]) => ({
        timestamp: new Date(dateStr),
        open: parseFloat(values["1. open"]),
        high: parseFloat(values["2. high"]),
        low: parseFloat(values["3. low"]),
        close: parseFloat(values["4. close"]),
        volume: parseInt(values["5. volume"]),
      }))
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());

    // Cache historical metrics for 1 hour
    timeSeriesCache.set(cacheKey, { data: results, expiry: Date.now() + 3600000 });
    return results;
  } catch (error) {
    console.error(`[Alpha Vantage Time Series] Error for ${symbol}:`, error);
    return [];
  }
}

/**
 * Get intraday historical price data
 */
export async function getTimeSeriesIntraday(
  symbol: string,
  interval: "1min" | "5min" | "15min" | "30min" | "60min" = "5min"
): Promise<AlphaVantageTimeSeries[]> {
  try {
    const data = await fetchFromAlphaVantage({
      function: "TIME_SERIES_INTRADAY",
      symbol: symbol,
      interval: interval,
      outputsize: "compact",
    });

    const key = `Time Series (${interval})`;
    const timeSeries = data[key];
    if (!timeSeries) {
      return [];
    }

    return Object.entries(timeSeries)
      .map(([dateStr, values]: [string, any]) => ({
        timestamp: new Date(dateStr),
        open: parseFloat(values["1. open"]),
        high: parseFloat(values["2. high"]),
        low: parseFloat(values["3. low"]),
        close: parseFloat(values["4. close"]),
        volume: parseInt(values["5. volume"]),
      }))
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  } catch (error) {
    console.error(`[Alpha Vantage Intraday] Error for ${symbol}:`, error);
    return [];
  }
}

/**
 * Get weekly historical time series data
 */
export async function getTimeSeriesWeekly(symbol: string): Promise<AlphaVantageTimeSeries[]> {
  try {
    const data = await fetchFromAlphaVantage({
      function: "TIME_SERIES_WEEKLY",
      symbol: symbol,
    });

    const timeSeries = data["Time Series (Weekly)"];
    if (!timeSeries) {
      return [];
    }

    return Object.entries(timeSeries)
      .map(([dateStr, values]: [string, any]) => ({
        timestamp: new Date(dateStr),
        open: parseFloat(values["1. open"]),
        high: parseFloat(values["2. high"]),
        low: parseFloat(values["3. low"]),
        close: parseFloat(values["4. close"]),
        volume: parseInt(values["5. volume"]),
      }))
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  } catch (error) {
    console.error(`[Alpha Vantage Weekly] Error for ${symbol}:`, error);
    return [];
  }
}

/**
 * Get monthly historical time series data
 */
export async function getTimeSeriesMonthly(symbol: string): Promise<AlphaVantageTimeSeries[]> {
  try {
    const data = await fetchFromAlphaVantage({
      function: "TIME_SERIES_MONTHLY",
      symbol: symbol,
    });

    const timeSeries = data["Time Series (Monthly)"];
    if (!timeSeries) {
      return [];
    }

    return Object.entries(timeSeries)
      .map(([dateStr, values]: [string, any]) => ({
        timestamp: new Date(dateStr),
        open: parseFloat(values["1. open"]),
        high: parseFloat(values["2. high"]),
        low: parseFloat(values["3. low"]),
        close: parseFloat(values["4. close"]),
        volume: parseInt(values["5. volume"]),
      }))
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  } catch (error) {
    console.error(`[Alpha Vantage Monthly] Error for ${symbol}:`, error);
    return [];
  }
}

/**
 * Get technical indicator sequences
 */
export async function getTechnicalIndicator(
  function_name: string,
  symbol: string,
  interval: string = "daily",
  timePeriod: number = 20,
  seriesType: string = "close"
): Promise<any> {
  const cacheKey = `${function_name}_${symbol.toUpperCase()}_${interval}_${timePeriod}_${seriesType}`;
  const cached = technicalCache.get(cacheKey);
  if (cached && cached.expiry > Date.now()) {
    return cached.data;
  }

  try {
    const data = await fetchFromAlphaVantage({
      function: function_name,
      symbol: symbol,
      interval: interval,
      time_period: timePeriod.toString(),
      series_type: seriesType,
    });

    // Cache indicators for 1 hour
    technicalCache.set(cacheKey, { data, expiry: Date.now() + 3600000 });
    return data;
  } catch (error) {
    console.error(`[Alpha Vantage Technical] Error for ${symbol}:`, error);
    return null;
  }
}
