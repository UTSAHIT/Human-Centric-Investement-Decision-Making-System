import Redis from "ioredis";
import { ENV } from "./env";

interface SessionData {
  userId: number;
  email: string;
  name: string;
  expiresAt: number;
}

class SessionStore {
  private redis: Redis | null = null;
  private inMemory: Map<string, SessionData> = new Map();
  private useRedis = false;

  async init(): Promise<void> {
    try {
      if (ENV.REDIS_URL) {
        this.redis = new Redis(ENV.REDIS_URL, {
          maxRetriesPerRequest: 3,
          retryStrategy: (times: number) => {
            if (times > 3) return null;
            return Math.min(times * 100, 3000);
          },
          lazyConnect: true,
        });

        await this.redis.connect();
        console.log("✅ Redis session store connected");
        this.useRedis = true;
      } else {
        console.log("⚠️  Using in-memory session store (not recommended for production)");
        console.log("   Set REDIS_URL env variable to use Redis");
      }
    } catch (error) {
      console.warn("⚠️  Redis connection failed, falling back to in-memory sessions");
      console.warn("   Sessions will be lost on server restart");
      this.useRedis = false;
    }
  }

  set(token: string, data: SessionData): void {
    if (this.useRedis && this.redis) {
      const expirySeconds = Math.max(1, Math.floor((data.expiresAt - Date.now()) / 1000));
      this.redis.setex(`session:${token}`, expirySeconds, JSON.stringify(data)).catch((err: Error) => {
        console.error("[Session] Redis set failed:", err);
      });
    } else {
      this.inMemory.set(token, data);
    }
  }

  async get(token: string): Promise<SessionData | null> {
    if (this.useRedis && this.redis) {
      try {
        const data = await this.redis.get(`session:${token}`);
        return data ? JSON.parse(data) : null;
      } catch {
        return null;
      }
    }
    return this.inMemory.get(token) || null;
  }

  delete(token: string): void {
    if (this.useRedis && this.redis) {
      this.redis.del(`session:${token}`).catch((err: Error) => {
        console.error("[Session] Redis delete failed:", err);
      });
    } else {
      this.inMemory.delete(token);
    }
  }

  cleanup(): void {
    if (this.redis) {
      this.redis.quit().catch(() => {});
    }
  }
}

export const sessionStore = new SessionStore();