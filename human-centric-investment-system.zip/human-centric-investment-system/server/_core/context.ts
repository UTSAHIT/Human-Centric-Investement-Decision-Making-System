import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import { sdk } from "./sdk";
import { sessionStore } from "./sessionStore";

type User = {
  id: number;
  openId: string;
  name: string | null;
  email: string | null;
  role: string;
};

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  // Try session-based auth first (for email/password login)
  const authHeader = opts.req.headers.authorization;
  if (authHeader) {
    const token = authHeader.replace("Bearer ", "");

    if (token) {
      const session = await sessionStore.get(token);
      if (session && session.expiresAt > Date.now()) {
        user = {
          id: session.userId,
          openId: `local_${session.email}`,
          name: session.name,
          email: session.email,
          role: "user",
        };
        return {
          req: opts.req,
          res: opts.res,
          user,
        };
      }
    }
  }

  // If no session-based auth, try OAuth authentication
  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Not OAuth authenticated - user will be null
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
