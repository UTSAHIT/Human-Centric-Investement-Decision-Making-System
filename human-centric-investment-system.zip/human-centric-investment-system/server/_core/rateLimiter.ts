import rateLimit, { RateLimitRequestHandler } from "express-rate-limit";
import { ENV } from "./env";
import type { Request, Response } from "express";

export const createRateLimiter = (): RateLimitRequestHandler => {
  return rateLimit({
    windowMs: Number(ENV.RATE_LIMIT_WINDOW_MS),
    limit: Number(ENV.RATE_LIMIT_MAX_REQUESTS),
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { error: "Too many requests, please try again later" },
    keyGenerator: (req: Request): string => {
      return req.ip || req.headers["x-forwarded-for"] as string || "unknown";
    },
    skip: (req: Request): boolean => {
      // Don't rate limit health checks
      return req.path === "/health" || req.path === "/";
    },
  });
};

export const createAuthRateLimiter = (): RateLimitRequestHandler => {
  // Stricter rate limit for auth endpoints (login/register)
  return rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    limit: 10, // 10 attempts
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { error: "Too many login attempts, please try again later" },
    keyGenerator: (req: Request): string => {
      return req.ip || req.headers["x-forwarded-for"] as string || "unknown";
    },
  });
};