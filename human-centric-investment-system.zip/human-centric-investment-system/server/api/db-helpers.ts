/**
 * Database Query Helpers
 * Reusable functions for common database operations
 */

import { eq, desc, and, gte, lte } from "drizzle-orm";
import {
  stocks,
  stockPrices,
  mutualFunds,
  mutualFundPrices,
  predictions,
  investmentProfiles,
  priceAlerts,
  watchlist,
  portfolioHoldings,
} from "../../drizzle/schema";
import { getDb } from "../db";

// ============ STOCKS ============

export async function getStockBySymbol(symbol: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(stocks).where(eq(stocks.symbol, symbol)).limit(1);
  return result[0] || null;
}

export async function getStockPrice(stockId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(stockPrices)
    .where(eq(stockPrices.stockId, stockId))
    .orderBy(desc(stockPrices.timestamp))
    .limit(1);
  return result[0] || null;
}

export async function upsertStock(stockData: any) {
  const db = await getDb();
  if (!db) return null;

  const existing = await getStockBySymbol(stockData.symbol);
  if (existing) {
    await db.update(stocks).set(stockData).where(eq(stocks.symbol, stockData.symbol));
    return existing;
  }

  const result = await db.insert(stocks).values(stockData);
  return { ...stockData, id: result[0].insertId };
}

export async function upsertStockPrice(priceData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(stockPrices).values(priceData);
  return { ...priceData, id: result[0].insertId };
}

export async function getStockPriceHistory(stockId: number, days: number = 365) {
  const db = await getDb();
  if (!db) return [];

  const fromDate = new Date();
  fromDate.setDate(fromDate.getDate() - days);

  const result = await db
    .select()
    .from(stockPrices)
    .where(and(eq(stockPrices.stockId, stockId), gte(stockPrices.timestamp, fromDate)))
    .orderBy(stockPrices.timestamp);

  return result;
}

export async function getLatestStockPriceTimestamp(stockId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select({ timestamp: stockPrices.timestamp })
    .from(stockPrices)
    .where(eq(stockPrices.stockId, stockId))
    .orderBy(desc(stockPrices.timestamp))
    .limit(1);

  return result[0]?.timestamp || null;
}

// ============ MUTUAL FUNDS ============

export async function getMutualFundBySymbol(symbol: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(mutualFunds).where(eq(mutualFunds.symbol, symbol)).limit(1);
  return result[0] || null;
}

export async function getMutualFundPrice(fundId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(mutualFundPrices)
    .where(eq(mutualFundPrices.fundId, fundId))
    .orderBy(desc(mutualFundPrices.timestamp))
    .limit(1);
  return result[0] || null;
}

export async function upsertMutualFund(fundData: any) {
  const db = await getDb();
  if (!db) return null;

  const existing = await getMutualFundBySymbol(fundData.symbol);
  if (existing) {
    await db.update(mutualFunds).set(fundData).where(eq(mutualFunds.symbol, fundData.symbol));
    return existing;
  }

  const result = await db.insert(mutualFunds).values(fundData);
  return { ...fundData, id: result[0].insertId };
}

export async function upsertMutualFundPrice(priceData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(mutualFundPrices).values(priceData);
  return { ...priceData, id: result[0].insertId };
}

export async function getMutualFundPriceHistory(fundId: number, days: number = 365) {
  const db = await getDb();
  if (!db) return [];

  const fromDate = new Date();
  fromDate.setDate(fromDate.getDate() - days);

  const result = await db
    .select()
    .from(mutualFundPrices)
    .where(and(eq(mutualFundPrices.fundId, fundId), gte(mutualFundPrices.timestamp, fromDate)))
    .orderBy(mutualFundPrices.timestamp);

  return result;
}

export async function getLatestMutualFundPriceTimestamp(fundId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select({ timestamp: mutualFundPrices.timestamp })
    .from(mutualFundPrices)
    .where(eq(mutualFundPrices.fundId, fundId))
    .orderBy(desc(mutualFundPrices.timestamp))
    .limit(1);

  return result[0]?.timestamp || null;
}

// ============ LISTING HELPERS ============

export async function getTopStocks(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(stocks).orderBy(desc(stocks.marketCap)).limit(limit);
}

export async function getTopMutualFunds(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(mutualFunds).orderBy(desc(mutualFunds.aum)).limit(limit);
}

// ============ PREDICTIONS ============

export async function getPredictions(
  assetType: "stock" | "mutual_fund",
  assetId: number,
  timeline?: "1_week" | "1_month" | "3_months" | "1_year"
) {
  const db = await getDb();
  if (!db) return [];

  let whereConditions: any[] = [eq(predictions.assetType, assetType), eq(predictions.assetId, assetId)];

  if (timeline) {
    whereConditions.push(eq(predictions.timeline, timeline));
  }

  const query = db
    .select()
    .from(predictions)
    .where(and(...whereConditions))
    .orderBy(desc(predictions.createdAt));

  return await query;
}

export async function createPrediction(predictionData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(predictions).values(predictionData);
  return { ...predictionData, id: result[0].insertId };
}

// ============ INVESTMENT PROFILES ============

export async function getInvestmentProfile(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(investmentProfiles)
    .where(eq(investmentProfiles.userId, userId))
    .orderBy(desc(investmentProfiles.updatedAt))
    .limit(1);
  return result[0] || null;
}

export async function createOrUpdateProfile(userId: number, profileData: any) {
  const db = await getDb();
  if (!db) return null;

  const existing = await getInvestmentProfile(userId);

  if (existing) {
    await db
      .update(investmentProfiles)
      .set(profileData)
      .where(eq(investmentProfiles.userId, userId));
    return { ...existing, ...profileData };
  }

  const result = await db.insert(investmentProfiles).values({ userId, ...profileData });
  return { id: result[0].insertId, userId, ...profileData };
}

// ============ PRICE ALERTS ============

export async function getUserAlerts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(priceAlerts).where(eq(priceAlerts.userId, userId));
}

export async function createPriceAlert(alertData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(priceAlerts).values(alertData);
  return { ...alertData, id: result[0].insertId };
}

export async function updatePriceAlert(alertId: number, updateData: any) {
  const db = await getDb();
  if (!db) return null;

  await db.update(priceAlerts).set(updateData).where(eq(priceAlerts.id, alertId));
  return updateData;
}

export async function deletePriceAlert(alertId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.delete(priceAlerts).where(eq(priceAlerts.id, alertId));
  return true;
}

// ============ WATCHLIST ============

export async function getUserWatchlist(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(watchlist).where(eq(watchlist.userId, userId));
}

export async function addToWatchlist(watchlistData: any) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(watchlist).values(watchlistData);
  return { ...watchlistData, id: result[0].insertId };
}

export async function removeFromWatchlist(userId: number, assetId: number, assetType: "stock" | "mutual_fund") {
  const db = await getDb();
  if (!db) return false;

  await db
    .delete(watchlist)
    .where(
      and(
        eq(watchlist.userId, userId),
        eq(watchlist.assetId, assetId),
        eq(watchlist.assetType, assetType)
      )
    );
  return true;
}

// ============ PORTFOLIO ============

export async function getPortfolioHoldings(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(portfolioHoldings)
    .where(eq(portfolioHoldings.userId, userId))
    .orderBy(desc(portfolioHoldings.createdAt));
}

export async function getPortfolioHolding(userId: number, symbol: string, assetType: "stock" | "mutual_fund") {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(portfolioHoldings)
    .where(
      and(
        eq(portfolioHoldings.userId, userId),
        eq(portfolioHoldings.symbol, symbol),
        eq(portfolioHoldings.assetType, assetType)
      )
    )
    .limit(1);
  return result[0] || null;
}

export async function addPortfolioHolding(userId: number, holdingData: {
  symbol: string;
  assetType: "stock" | "mutual_fund";
  shares: number;
  avgCost: number;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) return null;

  const existing = await getPortfolioHolding(userId, holdingData.symbol, holdingData.assetType);
  if (existing) {
    const totalShares = parseFloat(existing.shares.toString()) + holdingData.shares;
    const totalCost = parseFloat(existing.avgCost.toString()) * parseFloat(existing.shares.toString()) + holdingData.avgCost * holdingData.shares;
    const newAvgCost = totalCost / totalShares;

    await db
      .update(portfolioHoldings)
      .set({
        shares: totalShares.toString(),
        avgCost: newAvgCost.toString(),
        updatedAt: new Date(),
      })
      .where(eq(portfolioHoldings.id, existing.id));

    return { ...existing, shares: totalShares, avgCost: newAvgCost };
  }

  const result = await db.insert(portfolioHoldings).values({
    userId,
    symbol: holdingData.symbol,
    assetType: holdingData.assetType,
    shares: holdingData.shares.toString(),
    avgCost: holdingData.avgCost.toString(),
    notes: holdingData.notes || null,
  });
  return { ...holdingData, id: result[0].insertId };
}

export async function updatePortfolioHolding(holdingId: number, updateData: {
  shares?: number;
  avgCost?: number;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) return null;

  const setData: any = { updatedAt: new Date() };
  if (updateData.shares !== undefined) setData.shares = updateData.shares.toString();
  if (updateData.avgCost !== undefined) setData.avgCost = updateData.avgCost.toString();
  if (updateData.notes !== undefined) setData.notes = updateData.notes;

  await db.update(portfolioHoldings).set(setData).where(eq(portfolioHoldings.id, holdingId));
  return updateData;
}

export async function removePortfolioHolding(holdingId: number) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(portfolioHoldings).where(eq(portfolioHoldings.id, holdingId));
  return true;
}
