export type InvestorProfileLike = {
  riskTolerance: "conservative" | "moderate" | "aggressive";
  timeHorizon: "short_term" | "medium_term" | "long_term";
  investmentGoal?: string | null;
  experienceLevel?: "beginner" | "intermediate" | "advanced";
};

export type AssetScoreInput = {
  assetType: "stock" | "mutual_fund";
  volatilityPercent: number;
  expectedChangePercent?: number;
  peRatio?: number | null;
  dividendYield?: number | null;
  expenseRatio?: number | null;
};

export function clampPercent(value: number, floor = 0, ceiling = 100) {
  if (!Number.isFinite(value)) return floor;
  return Math.max(floor, Math.min(ceiling, Math.round(value)));
}

export function scoreAssetMatch(profile: InvestorProfileLike, asset: AssetScoreInput) {
  const volatility = Math.max(0, Math.min(80, asset.volatilityPercent || 0));
  const expectedChange = Math.max(-40, Math.min(40, asset.expectedChangePercent ?? 0));
  const isFund = asset.assetType === "mutual_fund";

  // 1. Expected Return Score (35%)
  // Profile-aware: reward good returns WITH low volatility for conservative
  let returnScore = 50;
  if (profile.riskTolerance === "conservative") {
    // Key: High returns + LOW volatility = GREAT for conservative
    // High returns + HIGH volatility = Suspicious
    const isLowVol = volatility <= 20;
    if (expectedChange >= 5 && expectedChange <= 25) {
      returnScore = isLowVol ? 85 + (expectedChange - 5) : 65 + (expectedChange - 5); // Sweet spot
    } else if (expectedChange > 25) {
      returnScore = isLowVol ? Math.min(100, 95 + (expectedChange - 25) * 0.5) : Math.max(45, 75 - (expectedChange - 25));
    } else if (expectedChange >= 0) {
      returnScore = 60 + (expectedChange * 2); // Steady is good
    } else {
      returnScore = Math.max(15, 50 + (expectedChange * 1.5)); // Negative
    }
  } else if (profile.riskTolerance === "aggressive") {
    // Aggressive: reward high expected returns
    if (expectedChange >= 10) {
      returnScore = 85 + Math.min(15, (expectedChange - 10));
    } else if (expectedChange >= 0) {
      returnScore = 50 + (expectedChange * 3);
    } else {
      returnScore = Math.max(20, 50 + (expectedChange * 2));
    }
  } else {
    // Moderate: balanced approach
    if (expectedChange >= 0) {
      returnScore = 50 + (expectedChange * 1.2);
    } else {
      returnScore = Math.max(20, 50 + (expectedChange * 1.5));
    }
  }

  // 2. User Risk Match Score (25%)
  // Conservative: heavily penalize high volatility, reward low volatility
  // Aggressive: reward moderate-high volatility for growth potential
  // Moderate: balance between stability and growth
  let riskMatchScore = 50;
  if (profile.riskTolerance === "conservative") {
    // Give decent scores to lowest vol stocks we have (20-25% is best available)
    if (volatility <= 15) {
      riskMatchScore = 90; // Best available - give high score
    } else if (volatility <= 22) {
      riskMatchScore = 80; // Acceptable low-end
    } else if (volatility <= 30) {
      riskMatchScore = 70; // Moderate
    } else if (volatility <= 40) {
      riskMatchScore = 60; // High
    } else {
      riskMatchScore = Math.max(25, 55 - (volatility - 40)); // Very high
    }
  } else if (profile.riskTolerance === "aggressive") {
    // Aggressive: prefer 20-35% volatility for momentum, penalty if too low (boring)
    if (volatility >= 20 && volatility <= 40) {
      riskMatchScore = 85 + Math.min(15, (40 - volatility)); // Optimal range
    } else if (volatility < 20) {
      riskMatchScore = 60 + (volatility); // Too stable - penalize
    } else {
      riskMatchScore = Math.max(25, 90 - (volatility - 40)); // Too volatile
    }
  } else {
    // Moderate: prefer 10-20% range
    const dev = Math.abs(volatility - 15);
    riskMatchScore = Math.max(15, 90 - (dev * 2.5));
  }

  // Time horizon adjustment to risk match
  if (profile.timeHorizon === "short_term") {
    riskMatchScore = Math.max(0, riskMatchScore - (volatility * 1.5)); // heavy extra penalty for short term + high vol
  } else if (profile.timeHorizon === "long_term") {
    riskMatchScore = Math.min(100, riskMatchScore + 10); // buffer for long term
  }

  // 3. Market Momentum Score (20%)
  // Based on current trend and expected change
  let momentumScore = 50;
  if (expectedChange > 1.5) {
    momentumScore = Math.min(100, 65 + (expectedChange * 1.0));
  } else if (expectedChange < -1.5) {
    momentumScore = Math.max(0, 35 + (expectedChange * 1.5));
  } else {
    momentumScore = 50;
  }

  // 4. Diversification Score (10%)
  // How well the asset type matches the profile's default strategic allocation
  let diversificationScore = 80;
  if (profile.riskTolerance === "conservative") {
    // Even for conservative, low-vol stocks should get decent score
    diversificationScore = isFund ? 95 : (volatility <= 25 ? 75 : 55);
  } else if (profile.riskTolerance === "aggressive") {
    diversificationScore = isFund ? 70 : 95; // aggressive prefers direct equities
  } else {
    diversificationScore = 85; // balanced is happy with both
  }
  if (profile.experienceLevel === "beginner" && isFund) {
    diversificationScore = Math.min(100, diversificationScore + 5);
  }

  // 5. Liquidity Score (10%)
  // Direct equities are highly liquid (T+1 trading), Mutual funds are slightly slower (T+2/daily NAV cutoffs)
  const liquidityScore = isFund ? 80 : 95;

  // Calculate weighted final score
  const weightedScore = (0.35 * returnScore) + 
                        (0.25 * riskMatchScore) + 
                        (0.20 * momentumScore) + 
                        (0.10 * diversificationScore) + 
                        (0.10 * liquidityScore);

  const matchScore = clampPercent(weightedScore, 5, 100);

  return {
    matchScore,
    components: {
      expectedReturn: Math.round(returnScore),
      userRiskMatch: Math.round(riskMatchScore),
      marketMomentum: Math.round(momentumScore),
      diversification: Math.round(diversificationScore),
      liquidity: Math.round(liquidityScore)
    }
  };
}

export function calculateVolatilityPercent(priceRows: any[]) {
  const prices = priceRows.map((p) => Number(p.currentPrice ?? p.nav ?? p.price ?? p.close ?? 0)).filter((v) => v > 0);
  if (prices.length <= 1) return 10;
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
  }
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((sum, value) => sum + Math.pow(value - mean, 2), 0) / returns.length;
  return Math.round(Math.min(80, Math.sqrt(variance) * Math.sqrt(252) * 100) * 10) / 10;
}
