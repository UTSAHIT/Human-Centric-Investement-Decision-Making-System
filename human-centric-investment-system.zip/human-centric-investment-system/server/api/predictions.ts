/**
 * Price Prediction Engine
 * 
 * IMPORTANT DISCLAIMERS:
 * - This is TECHNICAL ANALYSIS only - based on historical price patterns
 * - Does NOT consider: earnings, news, market sentiment, fundamentals, macro events
 * - Model Fit Score (formerly "Confidence") measures how well the model fit PAST data
 * - HIGH Model Fit does NOT guarantee accurate future predictions
 * - Stock prices move on INFORMATION, not just patterns
 * - Past performance does not guarantee future results
 * 
 * Uses:
 * 1. Weighted Exponential Moving Average (EMA) with Damped Trend for short-term
 * 2. Holt-Winters Double Exponential Smoothing for medium-term  
 * 3. Regularized Ridge Linear Regression with Sinusoidal Seasonality for long-term
 */

export interface PredictionResult {
  predictedPrice: number;
  confidence: number; // Model fit score - renamed to be clearer
  rmse: number;
  mape: number;
  rSquared: number;
  modelType: string;
  historicalData: Array<{ date: string; price: number }>;
  predictionData: Array<{ date: string; price: number }>;
}

// ==========================================
// ACCURACY & STATISTICAL METRICS HELPERS
// ==========================================

function calculateVolatility(prices: number[]): number {
  const n = prices.length;
  if (n <= 1) return 0;
  const mean = prices.reduce((sum, val) => sum + val, 0) / n;
  if (mean === 0) return 0;
  const variance = prices.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / n;
  const stdDev = Math.sqrt(variance);
  return stdDev / mean; // Coefficient of variation (CV)
}

function calculateRMSE(actual: number[], fitted: number[]): number {
  const n = actual.length;
  if (n === 0) return 0;
  const sse = actual.reduce((sum, act, i) => sum + Math.pow(act - fitted[i], 2), 0);
  return Math.sqrt(sse / n);
}

function calculateMAPE(actual: number[], fitted: number[]): number {
  const n = actual.length;
  if (n === 0) return 0;
  let sumPercentError = 0;
  let validCount = 0;
  for (let i = 0; i < n; i++) {
    if (actual[i] !== 0) {
      sumPercentError += Math.abs((actual[i] - fitted[i]) / actual[i]);
      validCount++;
    }
  }
  return validCount > 0 ? (sumPercentError / validCount) * 100 : 0;
}

function calculateRSquared(actual: number[], fitted: number[]): number {
  const n = actual.length;
  if (n <= 1) return 1;
  const mean = actual.reduce((sum, val) => sum + val, 0) / n;
  const ssRes = actual.reduce((sum, act, i) => sum + Math.pow(act - fitted[i], 2), 0);
  const ssTot = actual.reduce((sum, act) => sum + Math.pow(act - mean, 2), 0);
  if (ssTot === 0) return ssRes === 0 ? 1 : 0;
  return Math.max(0, 1 - ssRes / ssTot);
}

// Generates a prediction path between start and end prices using geometric Brownian motion
// NOTE: This is a visualization aid, NOT a true prediction. Real markets don't follow smooth paths.
// External events (earnings, news, Fed decisions) can cause sudden price movements this cannot predict.
export function generatePredictionPath(
  startPrice: number,
  endPrice: number,
  days: number,
  volatility: number
): Array<{ date: string; price: number }> {
  if (!startPrice || startPrice <= 0 || !Number.isFinite(startPrice)) {
    startPrice = 100;
  }
  if (!endPrice || endPrice <= 0 || !Number.isFinite(endPrice)) {
    endPrice = startPrice;
  }
  
  const path: Array<{ date: string; price: number }> = [];
  const steps = Math.min(days, 30);
  
  // Ensure endPrice is reasonable - within 50% of startPrice
  const maxChange = startPrice * 0.5;
  endPrice = Math.max(startPrice - maxChange, Math.min(startPrice + maxChange, endPrice));
  
  const drift = (endPrice - startPrice) / steps;
  let currentPrice = startPrice;
  const noiseScale = startPrice * Math.max(0.01, Math.min(0.3, volatility || 0.1));

  for (let i = 1; i <= steps; i++) {
    const date = new Date(Date.now() + i * 24 * 60 * 60 * 1000);
    const u1 = Math.random() || 0.0001;
    const u2 = Math.random() || 0.0001;
    const randNormal = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    
    const shock = randNormal * noiseScale * Math.sqrt(1 / steps);
    currentPrice = currentPrice + drift + shock;
    currentPrice = Math.max(startPrice * 0.5, Math.min(startPrice * 1.5, currentPrice));

    path.push({
      date: date.toISOString().split("T")[0],
      price: Math.round(currentPrice * 100) / 100,
    });
  }

  // Ensure final price is reasonable
  if (path.length > 0) {
    path[path.length - 1].price = Math.round(endPrice * 100) / 100;
  }

  return path;
}

// ==========================================
// MODEL 1: WEIGHTED MOVING AVERAGE (EMA) W/ DAMPED TREND
// Short-term prediction (1 week)
// ==========================================

export function predictWithMovingAverage(
  historicalPrices: number[],
  daysAhead: number
): PredictionResult {
  if (historicalPrices.length < 10) {
    throw new Error("Insufficient historical data for Moving Average model");
  }

  const n = historicalPrices.length;
  // Calculate EMA 5 (recent momentum) and EMA 20 (medium-term support)
  const calculateEMA = (span: number): number[] => {
    const ema: number[] = [];
    const k = 2 / (span + 1);
    let current = historicalPrices[0];
    ema.push(current);
    for (let i = 1; i < n; i++) {
      current = historicalPrices[i] * k + current * (1 - k);
      ema.push(current);
    }
    return ema;
  };

  const ema5 = calculateEMA(5);
  const ema20 = calculateEMA(20);

  // Recent trend is the gradient of EMA5 relative to EMA20
  const lastEma5 = ema5[n - 1];
  const lastEma20 = ema20[n - 1];
  const rawTrend = lastEma20 ? (lastEma5 - lastEma20) / lastEma20 : 0;
  
  // Damped trend factor (reduces extrapolation growth/loss exponentially over time)
  const dampingFactor = 0.85;
  const totalTrend = rawTrend * Math.pow(dampingFactor, daysAhead);

  const lastPrice = historicalPrices[n - 1];
  let predictedPrice = lastPrice * (1 + totalTrend);
  predictedPrice = Math.max(0.01, predictedPrice);

  // Volatility coefficient of variation over recent 20 days
  const volatility = calculateVolatility(historicalPrices.slice(-20));
  
  // Model Confidence score (higher volatility -> lower confidence, clamped 45% to 92%)
  const confidence = Math.max(45, Math.min(92, 100 - volatility * 120));

  // Compute fitted values for metrics
  const fitted = ema5; // EMA5 serves as the fitted path for the moving average model
  const rmse = calculateRMSE(historicalPrices, fitted);
  const mape = calculateMAPE(historicalPrices, fitted);
  const rSquared = calculateRSquared(historicalPrices, fitted);

  return {
    predictedPrice: Math.round(predictedPrice * 100) / 100,
    confidence: Math.round(confidence),
    rmse: Math.round(rmse * 100) / 100,
    mape: Math.round(mape * 100) / 100,
    rSquared: Math.round(rSquared * 10000) / 10000,
    modelType: "WeightedMovingAverage",
    historicalData: historicalPrices.slice(-90).map((price, idx) => ({
      date: new Date(Date.now() - (90 - idx) * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      price,
    })),
    predictionData: generatePredictionPath(lastPrice, predictedPrice, daysAhead, volatility),
  };
}

// ==========================================
// MODEL 2: HOLT-WINTERS DOUBLE EXPONENTIAL SMOOTHING
// Medium-term prediction (1 month)
// ==========================================

export function predictWithExponentialSmoothing(
  historicalPrices: number[],
  daysAhead: number
): PredictionResult {
  if (historicalPrices.length < 20) {
    throw new Error("Insufficient historical data for Exponential Smoothing model");
  }

  const n = historicalPrices.length;
  const alpha = 0.25; // level smoothing factor
  const beta = 0.15;  // trend smoothing factor
  const phi = 0.90;   // trend damping parameter

  let level = historicalPrices[0];
  let trend = historicalPrices[1] - historicalPrices[0];
  
  const fitted: number[] = [level];

  // Fit Double Exponential Smoothing (Holt's Linear Trend)
  for (let i = 1; i < n; i++) {
    const lastLevel = level;
    level = alpha * historicalPrices[i] + (1 - alpha) * (level + trend);
    trend = beta * (level - lastLevel) + (1 - beta) * trend;
    fitted.push(level + trend);
  }

  // Forecast out using Damped Holt Trend projection
  const lastPrice = historicalPrices[n - 1];
  let forecastTrendAccumulated = 0;
  for (let step = 1; step <= daysAhead; step++) {
    forecastTrendAccumulated += Math.pow(phi, step) * trend;
  }
  let predictedPrice = level + forecastTrendAccumulated;
  predictedPrice = Math.max(0.01, predictedPrice);

  const volatility = calculateVolatility(historicalPrices.slice(-30));
  const confidence = Math.max(40, Math.min(88, 95 - volatility * 110));

  const rmse = calculateRMSE(historicalPrices, fitted);
  const mape = calculateMAPE(historicalPrices, fitted);
  const rSquared = calculateRSquared(historicalPrices, fitted);

  return {
    predictedPrice: Math.round(predictedPrice * 100) / 100,
    confidence: Math.round(confidence),
    rmse: Math.round(rmse * 100) / 100,
    mape: Math.round(mape * 100) / 100,
    rSquared: Math.round(rSquared * 10000) / 10000,
    modelType: "HoltWintersSmoothing",
    historicalData: historicalPrices.slice(-90).map((price, idx) => ({
      date: new Date(Date.now() - (90 - idx) * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      price,
    })),
    predictionData: generatePredictionPath(lastPrice, predictedPrice, daysAhead, volatility),
  };
}

// ==========================================
// MODEL 3: REGULARIZED RIDGE LINEAR REGRESSION W/ CYCLICAL SEASONALITY
// Long-term prediction (3 months - 1 year)
// ==========================================

export function predictWithLinearRegression(
  historicalPrices: number[],
  daysAhead: number
): PredictionResult {
  const n = historicalPrices.length;
  if (n < 30) {
    throw new Error("Insufficient historical data for Linear Regression model");
  }

  // Feature formulation: time-index + seasonal sine/cosine components (based on standard 90-day market cycles)
  const xMatrix: number[][] = [];
  const yVector: number[] = [];
  
  const cycleLength = 90; // Typical quarter cycles

  for (let i = 0; i < n; i++) {
    const t = i;
    const sinComponent = Math.sin((2 * Math.PI * t) / cycleLength);
    const cosComponent = Math.cos((2 * Math.PI * t) / cycleLength);
    xMatrix.push([1, t, sinComponent, cosComponent]); // Bias, Trend, Sine, Cosine
    yVector.push(historicalPrices[i]);
  }

  // Linear regression solving using Ridge regularization (L2 penalty) to avoid extreme coefficients
  const solveRidgeRegression = (X: number[][], Y: number[], lambda = 0.1): number[] => {
    const m = X[0].length; // number of features (4)
    
    // XT * X
    const XTX: number[][] = Array.from({ length: m }, () => Array(m).fill(0));
    for (let r = 0; r < m; r++) {
      for (let c = 0; c < m; c++) {
        let sum = 0;
        for (let i = 0; i < n; i++) {
          sum += X[i][r] * X[i][c];
        }
        // Add Ridge penalty to diagonal elements (except bias column 0)
        XTX[r][c] = sum + (r === c && r > 0 ? lambda : 0);
      }
    }

    // XT * Y
    const XTY = Array(m).fill(0);
    for (let r = 0; r < m; r++) {
      let sum = 0;
      for (let i = 0; i < n; i++) {
        sum += X[i][r] * Y[i];
      }
      XTY[r] = sum;
    }

    // Matrix inversion solver (Gaussian elimination for 4x4 matrix)
    const solveMatrix = (A: number[][], B: number[]): number[] => {
      const size = B.length;
      for (let i = 0; i < size; i++) {
        // Pivot selection
        let maxRow = i;
        for (let k = i + 1; k < size; k++) {
          if (Math.abs(A[k][i]) > Math.abs(A[maxRow][i])) {
            maxRow = k;
          }
        }
        // Swap rows
        const tempRow = A[i]; A[i] = A[maxRow]; A[maxRow] = tempRow;
        const tempVal = B[i]; B[i] = B[maxRow]; B[maxRow] = tempVal;

        // Make pivot 1
        const pivot = A[i][i];
        if (pivot === 0) continue;
        for (let j = i; j < size; j++) {
          A[i][j] /= pivot;
        }
        B[i] /= pivot;

        // Eliminate columns
        for (let k = 0; k < size; k++) {
          if (k !== i) {
            const factor = A[k][i];
            for (let j = i; j < size; j++) {
              A[k][j] -= factor * A[i][j];
            }
            B[k] -= factor * B[i];
          }
        }
      }
      return B;
    };

    return solveMatrix(XTX, XTY);
  };

  const coefficients = solveRidgeRegression(xMatrix, yVector, 0.5);
  const [beta0, beta1, beta2, beta3] = coefficients;

  // Compute fitted values for metrics
  const fitted = xMatrix.map((row) => beta0 + beta1 * row[1] + beta2 * row[2] + beta3 * row[3]);

  // Predict future price
  const futureT = n + daysAhead;
  const futureSin = Math.sin((2 * Math.PI * futureT) / cycleLength);
  const futureCos = Math.cos((2 * Math.PI * futureT) / cycleLength);
  
  let predictedPrice = beta0 + beta1 * futureT + beta2 * futureSin + beta3 * futureCos;
  
  // Dynamic stabilization: prevent negative price bounds or wild divergence
  const lastPrice = historicalPrices[n - 1];
  const maxPriceDivergence = lastPrice * 0.40; // Clamps predicted price within +/- 40% change for extreme time horizons
  predictedPrice = Math.max(lastPrice - maxPriceDivergence, Math.min(lastPrice + maxPriceDivergence, predictedPrice));
  predictedPrice = Math.max(0.01, predictedPrice);

  const volatility = calculateVolatility(historicalPrices);
  const confidence = Math.max(35, Math.min(80, 85 - volatility * 100 - (daysAhead / 365) * 10));

  const rmse = calculateRMSE(historicalPrices, fitted);
  const mape = calculateMAPE(historicalPrices, fitted);
  const rSquared = calculateRSquared(historicalPrices, fitted);

  return {
    predictedPrice: Math.round(predictedPrice * 100) / 100,
    confidence: Math.round(confidence),
    rmse: Math.round(rmse * 100) / 100,
    mape: Math.round(mape * 100) / 100,
    rSquared: Math.round(rSquared * 10000) / 10000,
    modelType: "SeasonalRidgeRegression",
    historicalData: historicalPrices.slice(-90).map((price, idx) => ({
      date: new Date(Date.now() - (90 - idx) * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      price,
    })),
    predictionData: generatePredictionPath(lastPrice, predictedPrice, daysAhead, volatility),
  };
}

// ==========================================
// CORE SELECTION DISPATCHER BY TIMELINE
// ==========================================

export function getPredictionByTimeline(
  historicalPrices: number[],
  timeline: "1_week" | "1_month" | "3_months" | "1_year"
): PredictionResult {
  const daysMap = {
    "1_week": 7,
    "1_month": 30,
    "3_months": 90,
    "1_year": 365,
  };

  const daysAhead = daysMap[timeline];

  switch (timeline) {
    case "1_week":
      return predictWithMovingAverage(historicalPrices, daysAhead);
    case "1_month":
      return predictWithExponentialSmoothing(historicalPrices, daysAhead);
    case "3_months":
    case "1_year":
      return predictWithLinearRegression(historicalPrices, daysAhead);
    default:
      throw new Error(`Unknown timeline: ${timeline}`);
  }
}
