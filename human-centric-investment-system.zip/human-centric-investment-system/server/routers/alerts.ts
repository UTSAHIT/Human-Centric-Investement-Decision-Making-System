/**
 * Alerts Router
 * Handles price alerts and notifications
 */

import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import * as dbHelpers from "../api/db-helpers";

// Global in-memory alerts fallback store for offline operations
const inMemoryAlerts = new Map<number, Array<{
  id: number;
  userId: number;
  assetType: "stock" | "mutual_fund";
  assetId: number;
  symbol: string;
  targetPrice: number;
  alertType: "above" | "below";
  notificationType: "in_app" | "email" | "both";
  isActive: boolean;
  createdAt: Date;
}>>();

export const alertsRouter = router({
  /**
   * Get all alerts for the user
   */
  getAlerts: protectedProcedure.query(async ({ ctx }) => {
    try {
      const alerts = await dbHelpers.getUserAlerts(ctx.user.id);
      return alerts.map((alert) => ({
        id: alert.id,
        symbol: alert.symbol,
        assetType: alert.assetType,
        targetPrice: parseFloat(alert.targetPrice.toString()),
        alertType: alert.alertType,
        isActive: alert.isActive,
        notificationType: alert.notificationType,
        triggeredAt: alert.triggeredAt,
        createdAt: alert.createdAt,
      }));
    } catch (err) {
      console.warn(`[getAlerts] DB connection failed, using in-memory store:`, (err as any).message);
      const list = inMemoryAlerts.get(ctx.user.id) || [];
      return list.map(a => ({
        id: a.id,
        symbol: a.symbol,
        assetType: a.assetType,
        targetPrice: a.targetPrice,
        alertType: a.alertType,
        isActive: a.isActive,
        notificationType: a.notificationType,
        triggeredAt: null as Date | null,
        createdAt: a.createdAt,
      }));
    }
  }),

  /**
   * Create a new price alert
   */
  createAlert: protectedProcedure
    .input(
      z.object({
        assetType: z.enum(["stock", "mutual_fund"]),
        assetId: z.number(),
        symbol: z.string(),
        targetPrice: z.number().positive(),
        alertType: z.enum(["above", "below"]),
        notificationType: z.enum(["in_app", "email", "both"]).default("in_app"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const alert = await dbHelpers.createPriceAlert({
          userId: ctx.user.id,
          assetType: input.assetType,
          assetId: input.assetId,
          symbol: input.symbol,
          targetPrice: input.targetPrice,
          alertType: input.alertType,
          notificationType: input.notificationType,
          isActive: true,
        });

        return {
          success: true,
          alert,
        };
      } catch (err) {
        console.warn(`[createAlert] DB connection failed, using in-memory store fallback:`, (err as any).message);
        
        if (!inMemoryAlerts.has(ctx.user.id)) {
          inMemoryAlerts.set(ctx.user.id, []);
        }
        
        const alert = {
          id: Math.floor(Math.random() * 100000),
          userId: ctx.user.id,
          assetType: input.assetType,
          assetId: input.assetId,
          symbol: input.symbol,
          targetPrice: input.targetPrice,
          alertType: input.alertType,
          notificationType: input.notificationType,
          isActive: true,
          createdAt: new Date(),
        };
        
        inMemoryAlerts.get(ctx.user.id)!.push(alert);
        
        return {
          success: true,
          alert,
        };
      }
    }),

  /**
   * Update an alert
   */
  updateAlert: protectedProcedure
    .input(
      z.object({
        alertId: z.number(),
        targetPrice: z.number().positive().optional(),
        alertType: z.enum(["above", "below"]).optional(),
        notificationType: z.enum(["in_app", "email", "both"]).optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const updateData: any = {};

      if (input.targetPrice !== undefined) updateData.targetPrice = input.targetPrice;
      if (input.alertType !== undefined) updateData.alertType = input.alertType;
      if (input.notificationType !== undefined) updateData.notificationType = input.notificationType;
      if (input.isActive !== undefined) updateData.isActive = input.isActive;

      await dbHelpers.updatePriceAlert(input.alertId, updateData);

      return {
        success: true,
      };
    }),

  /**
   * Delete an alert
   */
  deleteAlert: protectedProcedure
    .input(z.object({ alertId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const success = await dbHelpers.deletePriceAlert(input.alertId);
      return { success };
    }),

  /**
   * Check if any alerts have been triggered
   * (This would typically be called by a background job)
   */
  checkTriggeredAlerts: protectedProcedure.query(async ({ ctx }) => {
    const alerts = await dbHelpers.getUserAlerts(ctx.user.id);
    const triggeredAlerts = [];

    for (const alert of alerts) {
      if (!alert.isActive) continue;

      // Get current price
      let currentPrice: number | null = null;

      if (alert.assetType === "stock") {
        const stock = await dbHelpers.getStockBySymbol(alert.symbol);
        if (stock) {
          const price = await dbHelpers.getStockPrice(stock.id);
          currentPrice = price ? parseFloat(price.currentPrice.toString()) : null;
        }
      } else {
        const fund = await dbHelpers.getMutualFundBySymbol(alert.symbol);
        if (fund) {
          const price = await dbHelpers.getMutualFundPrice(fund.id);
          currentPrice = price ? parseFloat(price.nav.toString()) : null;
        }
      }

      if (currentPrice === null) continue;

      const targetPrice = parseFloat(alert.targetPrice.toString());
      let isTriggered = false;

      if (alert.alertType === "above" && currentPrice >= targetPrice) {
        isTriggered = true;
      } else if (alert.alertType === "below" && currentPrice <= targetPrice) {
        isTriggered = true;
      }

      if (isTriggered && !alert.triggeredAt) {
        await dbHelpers.updatePriceAlert(alert.id, {
          triggeredAt: new Date(),
          isActive: false,
        });

        triggeredAlerts.push({
          id: alert.id,
          symbol: alert.symbol,
          targetPrice,
          currentPrice,
          alertType: alert.alertType,
          message: `${alert.symbol} has reached your target price of $${targetPrice}`,
        });
      }
    }

    return triggeredAlerts;
  }),

  /**
   * Get alert suggestions based on current price
   */
  getAlertSuggestions: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        currentPrice: z.number(),
      })
    )
    .query(async ({ input }) => {
      const suggestions = [
        {
          type: "above",
          price: Math.round(input.currentPrice * 1.1 * 100) / 100,
          label: `Alert when ${input.symbol} rises 10% to $${Math.round(input.currentPrice * 1.1 * 100) / 100}`,
        },
        {
          type: "above",
          price: Math.round(input.currentPrice * 1.2 * 100) / 100,
          label: `Alert when ${input.symbol} rises 20% to $${Math.round(input.currentPrice * 1.2 * 100) / 100}`,
        },
        {
          type: "below",
          price: Math.round(input.currentPrice * 0.9 * 100) / 100,
          label: `Alert when ${input.symbol} falls 10% to $${Math.round(input.currentPrice * 0.9 * 100) / 100}`,
        },
        {
          type: "below",
          price: Math.round(input.currentPrice * 0.8 * 100) / 100,
          label: `Alert when ${input.symbol} falls 20% to $${Math.round(input.currentPrice * 0.8 * 100) / 100}`,
        },
      ];

      return suggestions;
    }),
});
