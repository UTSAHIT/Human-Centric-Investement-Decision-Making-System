// UI styles moved to client side CSS – no server code here

import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import * as dbHelpers from "../api/db-helpers";
import { calculateVolatilityPercent, scoreAssetMatch } from "../api/investment-scoring";
import { fetchStockPrices, fetchFinnhubQuote, fetchTwelveDataQuote, fetchFinnhubCandles, fetchYahooFundNAV, fetchYahooFundChart, yahooCache } from "../_core/yahooApi";
import { ENV } from "../_core/env";
import { userStore } from "../_core/userStore";
import { getPredictionByTimeline } from "../api/predictions";

const QuizResponseSchema = z.object({
  riskTolerance: z.enum(["conservative", "moderate", "aggressive"]),
  investmentGoal: z.string().min(1),
  timeHorizon: z.enum(["short_term", "medium_term", "long_term"]),
  experienceLevel: z.enum(["beginner", "intermediate", "advanced"]),
  monthlyInvestment: z.number().positive().optional(),
  quizResponses: z.record(z.string(), z.any()).optional(),
});

// Fallback in-memory storage for profiles when database is not available
declare global {
  var profilesStore: Map<number, any>;
}
if (!global.profilesStore) {
  global.profilesStore = new Map();
}

import * as alphaVantage from "../_core/alphaVantageApi";

const CURATED_STOCKS = [
  { symbol: "AAPL", name: "Apple Inc.", quoteType: "EQUITY" },
  { symbol: "MSFT", name: "Microsoft Corporation", quoteType: "EQUITY" },
  { symbol: "NVDA", name: "NVIDIA Corporation", quoteType: "EQUITY" },
  { symbol: "TSLA", name: "Tesla Inc.", quoteType: "EQUITY" },
  { symbol: "GOOGL", name: "Alphabet Inc.", quoteType: "EQUITY" },
  { symbol: "AMZN", name: "Amazon.com Inc.", quoteType: "EQUITY" },
  { symbol: "META", name: "Meta Platforms Inc.", quoteType: "EQUITY" },
  { symbol: "NFLX", name: "Netflix Inc.", quoteType: "EQUITY" },
  { symbol: "AMD", name: "Advanced Micro Devices Inc.", quoteType: "EQUITY" },
  { symbol: "INTC", name: "Intel Corporation", quoteType: "EQUITY" },
  { symbol: "DIS", name: "Walt Disney Company", quoteType: "EQUITY" },
  { symbol: "V", name: "Visa Inc.", quoteType: "EQUITY" },
  { symbol: "JPM", name: "JPMorgan Chase & Co.", quoteType: "EQUITY" },
  { symbol: "WMT", name: "Walmart Inc.", quoteType: "EQUITY" },
  { symbol: "JNJ", name: "Johnson & Johnson", quoteType: "EQUITY" },
  { symbol: "PG", name: "Procter & Gamble Co.", quoteType: "EQUITY" },
  { symbol: "MA", name: "Mastercard Inc.", quoteType: "EQUITY" },
  { symbol: "UNH", name: "UnitedHealth Group Inc.", quoteType: "EQUITY" },
  { symbol: "HD", name: "Home Depot Inc.", quoteType: "EQUITY" },
  { symbol: "BAC", name: "Bank of America Corp", quoteType: "EQUITY" },
  { symbol: "XOM", name: "Exxon Mobil Corporation", quoteType: "EQUITY" },
  { symbol: "PFE", name: "Pfizer Inc.", quoteType: "EQUITY" },
  { symbol: "CSCO", name: "Cisco Systems Inc.", quoteType: "EQUITY" },
  { symbol: "KO", name: "Coca-Cola Company", quoteType: "EQUITY" },
  { symbol: "PEP", name: "PepsiCo Inc.", quoteType: "EQUITY" },
  { symbol: "COST", name: "Costco Wholesale Corp", quoteType: "EQUITY" },
  { symbol: "ABBV", name: "AbbVie Inc.", quoteType: "EQUITY" },
  { symbol: "MRK", name: "Merck & Co. Inc.", quoteType: "EQUITY" },
  { symbol: "CVX", name: "Chevron Corporation", quoteType: "EQUITY" },
  { symbol: "LLY", name: "Eli Lilly and Company", quoteType: "EQUITY" },
  { symbol: "TMO", name: "Thermo Fisher Scientific", quoteType: "EQUITY" },
  { symbol: "NKE", name: "Nike Inc.", quoteType: "EQUITY" },
  { symbol: "ORCL", name: "Oracle Corporation", quoteType: "EQUITY" },
  { symbol: "CRM", name: "Salesforce Inc.", quoteType: "EQUITY" },
  { symbol: "ACN", name: "Accenture plc", quoteType: "EQUITY" },
  { symbol: "ADBE", name: "Adobe Inc.", quoteType: "EQUITY" },
  { symbol: "TXN", name: "Texas Instruments Inc.", quoteType: "EQUITY" },
  { symbol: "QCOM", name: "Qualcomm Inc.", quoteType: "EQUITY" },
  { symbol: "AVGO", name: "Broadcom Inc.", quoteType: "EQUITY" },
  { symbol: "IBM", name: "IBM Corporation", quoteType: "EQUITY" },
  { symbol: "NOW", name: "ServiceNow Inc.", quoteType: "EQUITY" },
  { symbol: "INTU", name: "Intuit Inc.", quoteType: "EQUITY" },
  { symbol: "AMAT", name: "Applied Materials Inc.", quoteType: "EQUITY" },
  { symbol: "UBER", name: "Uber Technologies Inc.", quoteType: "EQUITY" },
  { symbol: "ABNB", name: "Airbnb Inc.", quoteType: "EQUITY" },
  { symbol: "SPOT", name: "Spotify Technology S.A.", quoteType: "EQUITY" },
  { symbol: "SQ", name: "Block Inc.", quoteType: "EQUITY" },
  { symbol: "PYPL", name: "PayPal Holdings Inc.", quoteType: "EQUITY" },
  { symbol: "SHOP", name: "Shopify Inc.", quoteType: "EQUITY" },
  { symbol: "COIN", name: "Coinbase Global Inc.", quoteType: "EQUITY" },
  { symbol: "RELIANCE.BSE", name: "Reliance Industries Ltd.", quoteType: "EQUITY" },
  { symbol: "TCS.BSE", name: "Tata Consultancy Services Ltd.", quoteType: "EQUITY" },
  { symbol: "INFY.BSE", name: "Infosys Ltd.", quoteType: "EQUITY" },
  { symbol: "HDFCBANK.BSE", name: "HDFC Bank Ltd.", quoteType: "EQUITY" },
  { symbol: "ICICIBANK.BSE", name: "ICICI Bank Ltd.", quoteType: "EQUITY" },
  { symbol: "SBIN.BSE", name: "State Bank of India", quoteType: "EQUITY" },
  { symbol: "BHARTIARTL.BSE", name: "Bharti Airtel Ltd.", quoteType: "EQUITY" },
  { symbol: "ITC.BSE", name: "ITC Ltd.", quoteType: "EQUITY" },
  { symbol: "LICI.BSE", name: "Life Insurance Corporation of India", quoteType: "EQUITY" },
  { symbol: "LT.BSE", name: "Larsen & Toubro Ltd.", quoteType: "EQUITY" },
  { symbol: "HINDUNILVR.BSE", name: "Hindustan Unilever Ltd.", quoteType: "EQUITY" },
  { symbol: "KOTAKBANK.BSE", name: "Kotak Mahindra Bank Ltd.", quoteType: "EQUITY" },
  { symbol: "ASIANPAINT.BSE", name: "Asian Paints Ltd.", quoteType: "EQUITY" },
  { symbol: "MARUTI.BSE", name: "Maruti Suzuki India Ltd.", quoteType: "EQUITY" },
  { symbol: "SUNPHARMA.BSE", name: "Sun Pharmaceutical Industries", quoteType: "EQUITY" },
  { symbol: "WIPRO.BSE", name: "Wipro Ltd.", quoteType: "EQUITY" },
  { symbol: "BAJFINANCE.BSE", name: "Bajaj Finance Ltd.", quoteType: "EQUITY" },
  { symbol: "TITAN.BSE", name: "Titan Company Ltd.", quoteType: "EQUITY" },
  { symbol: "ULTRACEMCO.BSE", name: "UltraTech Cement Ltd.", quoteType: "EQUITY" },
  { symbol: "NTPC.BSE", name: "NTPC Ltd.", quoteType: "EQUITY" },
  { symbol: "TECHM.BSE", name: "Tech Mahindra Ltd.", quoteType: "EQUITY" },
  { symbol: "AXISBANK.BSE", name: "Axis Bank Ltd.", quoteType: "EQUITY" },
  { symbol: "INDUSINDBK.BSE", name: "IndusInd Bank Ltd.", quoteType: "EQUITY" },
  { symbol: "M&M.BSE", name: "Mahindra & Mahindra Ltd.", quoteType: "EQUITY" },
  { symbol: "TATASTEEL.BSE", name: "Tata Steel Ltd.", quoteType: "EQUITY" },
  { symbol: "HCLTECH.BSE", name: "HCL Technologies Ltd.", quoteType: "EQUITY" },
  { symbol: "CIPLA.BSE", name: "Cipla Ltd.", quoteType: "EQUITY" },
  { symbol: "DRREDDY.BSE", name: "Dr. Reddy's Laboratories", quoteType: "EQUITY" },
  { symbol: "BAJAJFINSV.BSE", name: "Bajaj Finserv Ltd.", quoteType: "EQUITY" },
  { symbol: "DMART.BSE", name: "Avenue Supermarts Ltd.", quoteType: "EQUITY" },
  { symbol: "DABUR.BSE", name: "Dabur India Ltd.", quoteType: "EQUITY" },
  { symbol: "NESTLEIND.BSE", name: "Nestle India Ltd.", quoteType: "EQUITY" }
];

const CURATED_FUNDS = [
  { symbol: "VFIAX", name: "Vanguard 500 Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "FCNTX", name: "Fidelity Contrafund", quoteType: "MUTUALFUND" },
  { symbol: "VTSAX", name: "Vanguard Total Stock Market Index", quoteType: "MUTUALFUND" },
  { symbol: "VGTSX", name: "Vanguard Total International Stock", quoteType: "MUTUALFUND" },
  { symbol: "VBINX", name: "Vanguard Balanced Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "VWNDX", name: "Vanguard Windsor II Fund", quoteType: "MUTUALFUND" },
  { symbol: "FBALX", name: "Fidelity Balanced Fund", quoteType: "MUTUALFUND" },
  { symbol: "FBGRX", name: "Fidelity Blue Chip Growth Fund", quoteType: "MUTUALFUND" },
  { symbol: "AGTHX", name: "American Funds Growth Fund of America", quoteType: "MUTUALFUND" },
  { symbol: "AIVSX", name: "American Funds Investment Co of America", quoteType: "MUTUALFUND" },
  { symbol: "AWSHX", name: "American Funds Washington Mutual", quoteType: "MUTUALFUND" },
  { symbol: "AMECX", name: "American Funds Income Fund of America", quoteType: "MUTUALFUND" },
  { symbol: "VIGRX", name: "Vanguard Growth Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "VIVAX", name: "Vanguard Value Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "VSMVX", name: "Vanguard Small-Cap Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "VMGRX", name: "Vanguard Mid-Cap Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "VBTLX", name: "Vanguard Total Bond Market Index", quoteType: "MUTUALFUND" },
  { symbol: "FFTYX", name: "Fidelity 500 Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "FXAIX", name: "Fidelity 500 Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "FSKAX", name: "Fidelity Total Market Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "FSPSX", name: "Fidelity International Index Fund", quoteType: "MUTUALFUND" },
  { symbol: "FLCSX", name: "Fidelity Large-Cap Stock Fund", quoteType: "MUTUALFUND" },
  { symbol: "FMAGX", name: "Fidelity Magellan Fund", quoteType: "MUTUALFUND" },
  { symbol: "FDEUX", name: "Fidelity Diversified International", quoteType: "MUTUALFUND" },
  { symbol: "FRELX", name: "Fidelity Real Estate Investment Fund", quoteType: "MUTUALFUND" },
  { symbol: "FSPHX", name: "Fidelity Select Health Care Portfolio", quoteType: "MUTUALFUND" },
  { symbol: "FSUTX", name: "Fidelity Select Utilities Portfolio", quoteType: "MUTUALFUND" },
  { symbol: "FIDSX", name: "Fidelity Select Financial Services", quoteType: "MUTUALFUND" },
  { symbol: "FSELX", name: "Fidelity Select Energy Portfolio", quoteType: "MUTUALFUND" },
  { symbol: "FSEMX", name: "Fidelity Select Semiconductors", quoteType: "MUTUALFUND" },
  { symbol: "FSPTX", name: "Fidelity Select Software & IT", quoteType: "MUTUALFUND" },
  { symbol: "FEMKX", name: "Fidelity Emerging Markets Fund", quoteType: "MUTUALFUND" },
  { symbol: "FTRPX", name: "Fidelity Total Equity Income Fund", quoteType: "MUTUALFUND" },
  { symbol: "FPURX", name: "Fidelity Puritan Fund", quoteType: "MUTUALFUND" },
  { symbol: "FSYAX", name: "Fidelity Strategic Income Fund", quoteType: "MUTUALFUND" }
];

async function fetchLiveStockCandidates() {
  const topStocks = CURATED_STOCKS.slice(0, 30);
  const fetchedWithPrices = [];
  const cacheKey = "quiz:liveStocks";
  
  // Check cache first
  const cached = yahooCache.get<any[]>(cacheKey);
  if (cached && cached.length > 0) {
    console.log(`[Quiz] Using cached stocks (${cached.length} items)`);
    return cached;
  }

  // Fetch prices in parallel with timeout
  const fetchPromises = topStocks.map(async (stock) => {
    try {
      const priceData = await Promise.race([
        fetchStockPrices(stock.symbol) as Promise<{price: number; change: number; changePercent: number} | null>,
        new Promise<null>((_, reject) => setTimeout(() => reject(new Error("Timeout")), 5000))
      ]);
      if (priceData?.price && priceData.price > 0) {
        return {
          symbol: stock.symbol,
          name: stock.name,
          quoteType: stock.quoteType,
          currentPrice: priceData.price,
          change: priceData.change,
          changePercent: priceData.changePercent
        };
      }
    } catch (err) {
      // Silently fail for individual stocks
    }
    return null;
  });

  const results = await Promise.allSettled(fetchPromises);
  
  for (const result of results) {
    if (result.status === "fulfilled" && result.value) {
      fetchedWithPrices.push(result.value);
    }
  }

  // Use fetched prices if available, otherwise use curated list
  const finalList = fetchedWithPrices.length >= 1 ? fetchedWithPrices : topStocks.map(s => ({
    symbol: s.symbol,
    name: s.name,
    quoteType: s.quoteType,
    currentPrice: 100, // Default price if API fails
    change: 0,
    changePercent: 0
  }));

  // Cache for 5 minutes
  yahooCache.set(cacheKey, finalList, 300000);
  console.log(`[Quiz] Live stocks: ${fetchedWithPrices.length}/${topStocks.length} with prices`);
  
  return finalList;
}

async function fetchLiveFundCandidates() {
  const topFunds = CURATED_FUNDS.slice(0, 20);
  const fetchedWithPrices = [];
  const cacheKey = "quiz:liveFunds";
  
  // Check cache first
  const cached = yahooCache.get<any[]>(cacheKey);
  if (cached && cached.length > 0) {
    console.log(`[Quiz] Using cached funds (${cached.length} items)`);
    return cached;
  }

  // Fetch prices in parallel with timeout
  const fetchPromises = topFunds.map(async (fund) => {
    try {
      const priceData = await Promise.race([
        fetchStockPrices(fund.symbol) as Promise<{price: number; change: number; changePercent: number} | null>,
        new Promise<null>((_, reject) => setTimeout(() => reject(new Error("Timeout")), 5000))
      ]);
      if (priceData?.price && priceData.price > 0) {
        return {
          symbol: fund.symbol,
          name: fund.name,
          quoteType: fund.quoteType,
          currentPrice: priceData.price,
          change: priceData.change,
          changePercent: priceData.changePercent
        };
      }
    } catch (err) {
      // Silently fail for individual funds
    }
    return null;
  });

  const results = await Promise.allSettled(fetchPromises);
  
  for (const result of results) {
    if (result.status === "fulfilled" && result.value) {
      fetchedWithPrices.push(result.value);
    }
  }

  // Use fetched prices if available, otherwise use curated list
  const finalList = fetchedWithPrices.length >= 1 ? fetchedWithPrices : topFunds.map(f => ({
    symbol: f.symbol,
    name: f.name,
    quoteType: f.quoteType,
    currentPrice: 50, // Default price if API fails
    change: 0,
    changePercent: 0
  }));

  // Cache for 5 minutes
  yahooCache.set(cacheKey, finalList, 300000);
  console.log(`[Quiz] Live funds: ${fetchedWithPrices.length}/${topFunds.length} with prices`);
  
  return finalList;
}

async function fetchChartRows(symbol: string, assetType: "stock" | "mutual_fund") {
  const cacheKey = `chart2:${symbol}:${assetType}`;
  const cached = yahooCache.get<any[]>(cacheKey);
  if (cached && cached.length >= 30) {
    console.log(`[Quiz] Cache hit for chart ${symbol}`);
    return cached;
  }

  let closes: number[] = [];

  // For mutual funds, try Yahoo fund chart first (most reliable for fund NAVs)
  if (assetType === "mutual_fund") {
    try {
      const fundCloses = await fetchYahooFundChart(symbol.toUpperCase(), "3mo");
      if (fundCloses.length >= 30) {
        closes = fundCloses;
        const result = closes.map((c: number) => ({ nav: c }));
        yahooCache.set(cacheKey, result, 300000);
        return result;
      }
    } catch (err) {
      console.warn(`[Quiz] Yahoo fund chart failed for ${symbol}`);
    }
  }

  // Try Yahoo chart first for stocks (fastest, covers ~90-100 days of recent data)
  if (assetType === "stock") {
    try {
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol.toUpperCase())}?range=3mo&interval=1d`;
      const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
      if (response.ok) {
        const json = await response.json();
        const prices = json?.chart?.result?.[0]?.indicators?.quote?.[0]?.close as (number | null)[] | undefined;
        const valid = (prices || []).filter((p): p is number => typeof p === "number" && p > 0);
        if (valid.length >= 30) {
          closes = valid;
          const result = closes.map((c: number) => ({ currentPrice: c }));
          yahooCache.set(cacheKey, result, 300000);
          return result;
        }
      }
    } catch (err) {
      console.warn(`[Quiz] Yahoo chart failed for ${symbol}`);
    }
  }

  // Try Alpha Vantage compact (100 data points of daily data)
  try {
    const timeSeries = await alphaVantage.getTimeSeriesDaily(symbol, "compact");
    if (timeSeries && timeSeries.length >= 30) {
      closes = timeSeries.map((ts: any) => ts.close);
      const result = closes.map((c: number) =>
        assetType === "stock" ? { currentPrice: c } : { nav: c }
      );
      yahooCache.set(cacheKey, result, 300000);
      return result;
    }
  } catch (err) {
    console.warn(`[Quiz] Alpha Vantage chart failed for ${symbol}`);
  }

  // Try Finnhub candles as fallback
  try {
    const candles = await Promise.race([
      fetchFinnhubCandles(symbol.toUpperCase(), "D"),
      new Promise<number[]>((_, reject) =>
        setTimeout(() => reject(new Error("Finnhub timeout")), 5000)
      )
    ]);
    if (candles && candles.length >= 30) {
      closes = candles;
      const result = closes.map((c: number) =>
        assetType === "stock" ? { currentPrice: c } : { nav: c }
      );
      yahooCache.set(cacheKey, result, 300000);
      return result;
    }
  } catch (err) {
    console.warn(`[Quiz] Finnhub chart failed for ${symbol}`);
  }

  return [];
}

export const quizRouter = router({
/**
   * Get user's current investment profile
   * Returns null if user hasn't taken the quiz yet
   */
  getProfile: publicProcedure.query(async ({ ctx }) => {
    const userId = ctx.user?.id;
    if (!userId) return null;

    try {
const profile = await dbHelpers.getInvestmentProfile(userId);
      if (profile) return profile;
    } catch (err) {
      console.log("[Quiz] Database unavailable");
    }

    return userStore.getProfile(userId) || global.profilesStore.get(userId) || null;
  }),

  /**
   * Submit quiz responses and create/update profile - requires authentication
   */
  submitQuiz: protectedProcedure
    .input(QuizResponseSchema)
    .mutation(async ({ ctx, input }) => {
    const profileData = {
      riskTolerance: input.riskTolerance,
      investmentGoal: input.investmentGoal,
      timeHorizon: input.timeHorizon,
      experienceLevel: input.experienceLevel,
      monthlyInvestment: input.monthlyInvestment || null,
      quizResponses: input.quizResponses || {},
    };

    let profile: any = null;

    try {
      profile = await dbHelpers.createOrUpdateProfile(ctx.user.id, profileData);
      console.log("[Quiz] Profile saved to database");
    } catch (err) {
      console.log("[Quiz] Database unavailable, using file storage");
      profile = {
        id: ctx.user.id,
        userId: ctx.user.id,
        ...profileData,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      userStore.setProfile(ctx.user.id, profile);
      global.profilesStore.set(ctx.user.id, profile);
    }

    return {
      success: true,
      profile,
    };
  }),

  /**
   * Get personalized recommendations based on profile - requires authentication
   */
  getRecommendations: protectedProcedure.query(async ({ ctx }) => {
    let profile: any = null;

    try {
      profile = await dbHelpers.getInvestmentProfile(ctx.user.id);
    } catch (err) {
      console.log("[Quiz] Database unavailable, checking memory");
    }

    if (!profile) {
      profile = userStore.getProfile(ctx.user.id);
    }
    if (!profile) {
      profile = global.profilesStore.get(ctx.user.id);
    }

    if (!profile) {
      return {
        error: "No profile found. Please complete the quiz first.",
      };
    }

    try {
      const liveStocks = await fetchLiveStockCandidates();
      const liveFunds = await fetchLiveFundCandidates();

      const computeScoreForAsset = (profile: any, asset: any, priceHistory: any[], assetType: "stock" | "mutual_fund") => {
        if (priceHistory.length === 0) {
          const { matchScore } = scoreAssetMatch(profile, {
            assetType,
            volatilityPercent: 20,
            expectedChangePercent: 0,
          });
          return { score: matchScore, volatility: 20 };
        }

        const volatility = calculateVolatilityPercent(priceHistory);
        const expectedChange =
          priceHistory.length > 5
            ? ((Number(priceHistory[priceHistory.length - 1].currentPrice ?? priceHistory[priceHistory.length - 1].nav) -
                Number(priceHistory[0].currentPrice ?? priceHistory[0].nav)) /
                Number(priceHistory[0].currentPrice ?? priceHistory[0].nav)) *
              100
            : 0;
        const { matchScore } = scoreAssetMatch(profile, {
          assetType,
          volatilityPercent: volatility,
          expectedChangePercent: expectedChange,
          peRatio: asset.peRatio || 0,
          dividendYield: asset.dividendYield || 0,
          expenseRatio: asset.expenseRatio || 0,
        });

        return { score: matchScore, volatility };
      };

      // Process stocks and funds in smaller batches to avoid timeouts and rate limiting
      const topStocks = liveStocks.slice(0, 15);
      const topFunds = liveFunds.slice(0, 10);

      // Process stocks using AI predictions for accurate expected change
      const scoredStocks: any[] = [];
      for (const s of topStocks) {
        try {
          let history: any[] = [];
          try {
            const fetchPromise = fetchChartRows(s.symbol, "stock");
            const timeoutPromise = new Promise<any[]>((_, reject) =>
              setTimeout(() => reject(new Error("Chart fetch timeout")), 8000)
            );
            history = await Promise.race([fetchPromise, timeoutPromise]);
          } catch {
            console.warn(`[Quiz] Chart fetch failed for ${s.symbol}, using default values`);
          }

          let scoreResult: { score: number; volatility: number };
          if (history.length >= 30) {
            const prices = history.map((h: any) => Number(h.currentPrice ?? h.nav ?? h.price ?? 0)).filter((p: number) => p > 0);
            if (prices.length >= 30) {
              try {
                const prediction = getPredictionByTimeline(prices, "1_month");
                const currentPrice = prices[prices.length - 1];
                const predictedPrice = prediction.predictedPrice;
                const expectedChangePercent = currentPrice > 0
                  ? ((predictedPrice - currentPrice) / currentPrice) * 100
                  : 0;
                const volFromPrices = calculateVolatilityPercent(history);
                const { matchScore } = scoreAssetMatch(profile, {
                  assetType: "stock",
                  volatilityPercent: volFromPrices,
                  expectedChangePercent,
                  peRatio: s.peRatio || 0,
                  dividendYield: s.dividendYield || 0,
                });
                scoreResult = { score: matchScore, volatility: volFromPrices };
              } catch {
                scoreResult = computeScoreForAsset(profile, s, history, "stock");
              }
            } else {
              scoreResult = computeScoreForAsset(profile, s, history, "stock");
            }
          } else {
            scoreResult = computeScoreForAsset(profile, s, history, "stock");
          }
          scoredStocks.push({
            symbol: s.symbol,
            name: s.name || s.shortName || s.longName || s.symbol,
            assetType: "stock" as const,
            matchScore: scoreResult.score,
            volatility: scoreResult.volatility,
            price: s.currentPrice
          });
        } catch (err) {
          console.warn(`[Quiz] Failed to process stock ${s.symbol}:`, (err as any).message);
          const { matchScore } = scoreAssetMatch(profile, { assetType: "stock", volatilityPercent: 20, expectedChangePercent: 0 });
          scoredStocks.push({
            symbol: s.symbol,
            name: s.name || s.shortName || s.longName || s.symbol,
            assetType: "stock" as const,
            matchScore,
            volatility: 20,
            price: s.currentPrice
          });
        }
      }

      // Process funds using AI predictions for accurate expected change
      const scoredFunds: any[] = [];
      for (const f of topFunds) {
        try {
          let history: any[] = [];
          try {
            const fetchPromise = fetchChartRows(f.symbol, "mutual_fund");
            const timeoutPromise = new Promise<any[]>((_, reject) =>
              setTimeout(() => reject(new Error("Chart fetch timeout")), 8000)
            );
            history = await Promise.race([fetchPromise, timeoutPromise]);
          } catch {
            console.warn(`[Quiz] Chart fetch failed for ${f.symbol}, using default values`);
          }

          let scoreResult: { score: number; volatility: number };
          if (history.length >= 30) {
            const prices = history.map((h: any) => Number(h.nav ?? h.currentPrice ?? h.price ?? 0)).filter((p: number) => p > 0);
            if (prices.length >= 30) {
              try {
                const prediction = getPredictionByTimeline(prices, "1_month");
                const currentPrice = prices[prices.length - 1];
                const predictedPrice = prediction.predictedPrice;
                const expectedChangePercent = currentPrice > 0
                  ? ((predictedPrice - currentPrice) / currentPrice) * 100
                  : 0;
                const volFromPrices = calculateVolatilityPercent(history);
                const { matchScore } = scoreAssetMatch(profile, {
                  assetType: "mutual_fund",
                  volatilityPercent: volFromPrices,
                  expectedChangePercent,
                  expenseRatio: f.expenseRatio || 0,
                });
                scoreResult = { score: matchScore, volatility: volFromPrices };
              } catch {
                scoreResult = computeScoreForAsset(profile, f, history, "mutual_fund");
              }
            } else {
              scoreResult = computeScoreForAsset(profile, f, history, "mutual_fund");
            }
          } else {
            scoreResult = computeScoreForAsset(profile, f, history, "mutual_fund");
          }
          scoredFunds.push({
            symbol: f.symbol,
            name: f.name || f.shortName || f.longName || f.symbol,
            assetType: "mutual_fund" as const,
            matchScore: scoreResult.score,
            volatility: scoreResult.volatility,
            price: f.currentPrice
          });
        } catch (err) {
          console.warn(`[Quiz] Failed to process fund ${f.symbol}:`, (err as any).message);
          const { matchScore } = scoreAssetMatch(profile, { assetType: "mutual_fund", volatilityPercent: 12, expectedChangePercent: 0 });
          scoredFunds.push({
            symbol: f.symbol,
            name: f.name || f.shortName || f.longName || f.symbol,
            assetType: "mutual_fund" as const,
            matchScore,
            volatility: 12,
            price: f.currentPrice
          });
        }
      }

      scoredStocks.sort((a: any, b: any) => b.matchScore - a.matchScore || a.symbol.localeCompare(b.symbol));
      scoredFunds.sort((a: any, b: any) => b.matchScore - a.matchScore || a.symbol.localeCompare(b.symbol));

      // Always return top 10 for each
      return {
        profile,
        recommendations: {
          stocks: scoredStocks.slice(0, 10),
          mutualFunds: scoredFunds.slice(0, 10),
          topStocks: scoredStocks.slice(0, 10),
          topMutualFunds: scoredFunds.slice(0, 10),
        },
      };
    } catch (error) {
      console.error(`[Quiz] getRecommendations error:`, error);
      return {
        error: "Failed to fetch recommendations. Please try again.",
        recommendations: {
          stocks: [],
          mutualFunds: [],
          topStocks: [],
          topMutualFunds: [],
        }
      };
    }
  }),

  /**
   * Get quiz questions
   */
  getQuizQuestions: publicProcedure.query(async () => {
    return [
      {
        id: "risk_tolerance",
        question: "What is your investment risk tolerance?",
        type: "single_choice",
        options: [
          {
            value: "conservative",
            label: "Conservative - I prefer stable, low-risk investments",
          },
          {
            value: "moderate",
            label: "Moderate - I'm comfortable with some risk for potential growth",
          },
          {
            value: "aggressive",
            label: "Aggressive - I'm willing to take significant risk for higher returns",
          },
        ],
      },
      {
        id: "investment_goal",
        question: "What is your primary investment goal?",
        type: "single_choice",
        options: [
          { value: "wealth_preservation", label: "Wealth Preservation" },
          { value: "income_generation", label: "Income Generation" },
          { value: "capital_growth", label: "Capital Growth" },
          { value: "retirement", label: "Retirement Planning" },
          { value: "education", label: "Education Fund" },
        ],
      },
      {
        id: "time_horizon",
        question: "What is your investment time horizon?",
        type: "single_choice",
        options: [
          {
            value: "short_term",
            label: "Short Term (Less than 3 years)",
          },
          {
            value: "medium_term",
            label: "Medium Term (3-10 years)",
          },
          {
            value: "long_term",
            label: "Long Term (More than 10 years)",
          },
        ],
      },
      {
        id: "experience_level",
        question: "What is your investment experience level?",
        type: "single_choice",
        options: [
          {
            value: "beginner",
            label: "Beginner - New to investing",
          },
          {
            value: "intermediate",
            label: "Intermediate - Some experience",
          },
          {
            value: "advanced",
            label: "Advanced - Experienced investor",
          },
        ],
      },
      {
        id: "monthly_investment",
        question: "How much can you invest monthly?",
        type: "text_input",
        placeholder: "Enter amount in your local currency",
      },
    ];
  }),
});

// Helper function to generate recommendations
function generateRecommendations(profile: any) {
  const recommendations: any[] = [];

  // Based on risk tolerance
  if (profile.riskTolerance === "conservative") {
    recommendations.push({
      category: "Asset Allocation",
      suggestion: "Focus on bonds, dividend stocks, and stable mutual funds",
      allocation: { stocks: 30, bonds: 60, cash: 10 },
    });
  } else if (profile.riskTolerance === "moderate") {
    recommendations.push({
      category: "Asset Allocation",
      suggestion: "Balanced mix of growth and income investments",
      allocation: { stocks: 60, bonds: 30, cash: 10 },
    });
  } else {
    recommendations.push({
      category: "Asset Allocation",
      suggestion: "Growth-focused portfolio with higher equity exposure",
      allocation: { stocks: 80, bonds: 15, cash: 5 },
    });
  }

  // Based on time horizon
  if (profile.timeHorizon === "short_term") {
    recommendations.push({
      category: "Investment Strategy",
      suggestion: "Focus on capital preservation and liquidity",
      tips: ["Avoid highly volatile stocks", "Consider short-term bonds", "Keep emergency fund"],
    });
  } else if (profile.timeHorizon === "medium_term") {
    recommendations.push({
      category: "Investment Strategy",
      suggestion: "Balanced growth with periodic rebalancing",
      tips: ["Diversify across sectors", "Review quarterly", "Dollar-cost averaging"],
    });
  } else {
    recommendations.push({
      category: "Investment Strategy",
      suggestion: "Long-term growth strategy with compound interest focus",
      tips: ["Invest consistently", "Reinvest dividends", "Avoid market timing"],
    });
  }

  // Based on experience level
  if (profile.experienceLevel === "beginner") {
    recommendations.push({
      category: "Learning Resources",
      suggestion: "Start with index funds and ETFs for diversification",
      tips: [
        "Learn investment basics",
        "Start small",
        "Avoid individual stock picking initially",
        "Use our AI assistant for guidance",
      ],
    });
  }

  // General recommendations
  recommendations.push({
    category: "Best Practices",
    suggestion: "Follow these principles for successful investing",
    tips: [
      "Diversify your portfolio",
      "Invest regularly (dollar-cost averaging)",
      "Review and rebalance periodically",
      "Keep emotions in check",
      "Monitor your progress",
    ],
  });

  return recommendations;
}
