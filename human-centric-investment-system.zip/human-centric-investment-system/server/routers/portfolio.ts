/**
 * Portfolio Router
 * Live portfolio tracking with real-time prices and buy/sell alerts
 */

import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import * as dbHelpers from "../api/db-helpers";
import { fetchStockPrices, fetchYahooFundNAV } from "../_core/yahooApi";

// Global in-memory watchlist fallback store
const inMemoryWatchlist = new Map<number, Array<{ id: number; userId: number; assetId: number; assetType: "stock" | "mutual_fund"; symbol: string }>>();

export const portfolioRouter = router({
  /**
   * Get portfolio with live prices and P/L
   */
  getPortfolio: protectedProcedure.query(async ({ ctx }) => {
    const holdings = await dbHelpers.getPortfolioHoldings(ctx.user.id);
    if (holdings.length === 0) return { holdings: [], totalValue: 0, totalCost: 0, totalPnL: 0 };

    const enriched = await Promise.all(
      holdings.map(async (h) => {
        let currentPrice = 0;
        let change = 0;
        let changePercent = 0;
        let priceError = false;

        try {
          if (h.assetType === "stock") {
            const live = await fetchStockPrices(h.symbol);
            if (live) {
              currentPrice = live.price;
              change = live.change;
              changePercent = live.changePercent;
            } else {
              priceError = true;
            }
          } else {
            const live = await fetchYahooFundNAV(h.symbol);
            if (live) {
              currentPrice = live.nav;
              change = live.change;
              changePercent = live.changePercent;
            } else {
              priceError = true;
            }
          }
        } catch {
          priceError = true;
        }

        const shares = parseFloat(h.shares.toString());
        const avgCost = parseFloat(h.avgCost.toString());
        const currentValue = currentPrice * shares;
        const costBasis = avgCost * shares;
        const pnl = currentValue - costBasis;
        const pnlPercent = costBasis > 0 ? (pnl / costBasis) * 100 : 0;

        return {
          id: h.id,
          symbol: h.symbol,
          assetType: h.assetType,
          name: h.assetType === "stock" ? h.symbol : h.symbol,
          shares,
          avgCost,
          currentPrice,
          change,
          changePercent,
          currentValue,
          costBasis,
          pnl,
          pnlPercent,
          priceError,
          purchaseDate: h.purchaseDate,
          notes: h.notes,
        };
      })
    );

    const totalValue = enriched.reduce((s, h) => s + h.currentValue, 0);
    const totalCost = enriched.reduce((s, h) => s + h.costBasis, 0);
    const totalPnL = totalValue - totalCost;
    const totalPnLPercent = totalCost > 0 ? (totalPnL / totalCost) * 100 : 0;

    return {
      holdings: enriched,
      totalValue,
      totalCost,
      totalPnL,
      totalPnLPercent,
    };
  }),

  /**
   * Add or update a portfolio holding
   */
  addHolding: protectedProcedure
    .input(
      z.object({
        symbol: z.string().min(1),
        assetType: z.enum(["stock", "mutual_fund"]),
        shares: z.number().positive(),
        avgCost: z.number().positive(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const result = await dbHelpers.addPortfolioHolding(ctx.user.id, input);
      return { success: true, holding: result };
    }),

  /**
   * Update a holding (adjust shares/cost)
   */
  updateHolding: protectedProcedure
    .input(
      z.object({
        holdingId: z.number(),
        shares: z.number().positive().optional(),
        avgCost: z.number().positive().optional(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await dbHelpers.updatePortfolioHolding(input.holdingId, {
        shares: input.shares,
        avgCost: input.avgCost,
        notes: input.notes,
      });
      return { success: true };
    }),

  /**
   * Remove a holding from portfolio
   */
  removeHolding: protectedProcedure
    .input(z.object({ holdingId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await dbHelpers.removePortfolioHolding(input.holdingId);
      return { success: true };
    }),

  /**
   * Get buy/sell alerts based on portfolio holdings and live prices
   */
  getPortfolioAlerts: protectedProcedure.query(async ({ ctx }) => {
    const portfolio = await dbHelpers.getPortfolioHoldings(ctx.user.id);
    if (portfolio.length === 0) return { alerts: [], portfolioSummary: null };

    const enriched = await Promise.all(
      portfolio.map(async (h) => {
        let currentPrice = 0;
        let change = 0;
        let changePercent = 0;

        try {
          if (h.assetType === "stock") {
            const live = await fetchStockPrices(h.symbol);
            if (live) {
              currentPrice = live.price;
              change = live.change;
              changePercent = live.changePercent;
            }
          } else {
            const live = await fetchYahooFundNAV(h.symbol);
            if (live) {
              currentPrice = live.nav;
              change = live.change;
              changePercent = live.changePercent;
            }
          }
        } catch {}

        const shares = parseFloat(h.shares.toString());
        const avgCost = parseFloat(h.avgCost.toString());
        const currentValue = currentPrice * shares;
        const costBasis = avgCost * shares;
        const pnl = currentValue - costBasis;
        const pnlPercent = costBasis > 0 ? (pnl / costBasis) * 100 : 0;

        const alerts: Array<{ type: string; message: string; severity: "info" | "warning" | "danger" | "success" }> = [];

        if (pnlPercent >= 15) {
          alerts.push({ type: "take_profit", message: `${h.symbol} is up ${pnlPercent.toFixed(1)}% — consider taking profit`, severity: "warning" });
        } else if (pnlPercent >= 25) {
          alerts.push({ type: "strong_take_profit", message: `${h.symbol} is up ${pnlPercent.toFixed(1)}% — strong gain, evaluate position`, severity: "danger" });
        }

        if (pnlPercent <= -10) {
          alerts.push({ type: "stop_loss", message: `${h.symbol} is down ${pnlPercent.toFixed(1)}% — review stop-loss strategy`, severity: "danger" });
        } else if (pnlPercent <= -5) {
          alerts.push({ type: "watch_loss", message: `${h.symbol} is down ${pnlPercent.toFixed(1)}% — monitor closely`, severity: "warning" });
        }

        if (changePercent <= -3) {
          alerts.push({ type: "daily_drop", message: `${h.symbol} dropped ${changePercent.toFixed(1)}% today`, severity: "info" });
        } else if (changePercent >= 3) {
          alerts.push({ type: "daily_gain", message: `${h.symbol} surged ${changePercent.toFixed(1)}% today`, severity: "success" });
        }

        return { symbol: h.symbol, assetType: h.assetType, shares, avgCost, currentPrice, currentValue, pnl, pnlPercent, changePercent, alerts };
      })
    );

    const totalValue = enriched.reduce((s, h) => s + h.currentValue, 0);
    const totalCost = enriched.reduce((s, h) => s + (h.avgCost * h.shares), 0);
    const totalPnL = totalValue - totalCost;
    const totalPnLPercent = totalCost > 0 ? (totalPnL / totalCost) * 100 : 0;

    const flatAlerts = enriched.flatMap((h) =>
      h.alerts.map((a) => ({ ...a, symbol: h.symbol }))
    );

    return {
      alerts: flatAlerts,
      portfolioSummary: {
        totalValue,
        totalCost,
        totalPnL,
        totalPnLPercent,
        holdingsCount: enriched.length,
      },
    };
  }),

  /**
   * Get user's active watchlist
   */
  getWatchlist: protectedProcedure.query(async ({ ctx }) => {
    try {
      return await dbHelpers.getUserWatchlist(ctx.user.id);
    } catch (err) {
      console.warn(`[getWatchlist] DB connection failed, using in-memory store for user ${ctx.user.id}:`, (err as any).message);
      if (!inMemoryWatchlist.has(ctx.user.id)) {
        inMemoryWatchlist.set(ctx.user.id, []);
      }
      return inMemoryWatchlist.get(ctx.user.id) || [];
    }
  }),

  /**
   * Toggle asset in user's watchlist
   */
  toggleWatchlist: protectedProcedure
    .input(
      z.object({
        assetId: z.number(),
        assetType: z.enum(["stock", "mutual_fund"]),
        symbol: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const list = await dbHelpers.getUserWatchlist(ctx.user.id);
        const existing = list.find(
          (item) => item.assetId === input.assetId && item.assetType === input.assetType
        );
        
        if (existing) {
          await dbHelpers.removeFromWatchlist(ctx.user.id, input.assetId, input.assetType);
          return { success: true, added: false };
        } else {
          await dbHelpers.addToWatchlist({
            userId: ctx.user.id,
            assetId: input.assetId,
            assetType: input.assetType,
            symbol: input.symbol,
          });
          return { success: true, added: true };
        }
      } catch (err) {
        console.warn(`[toggleWatchlist] DB connection failed, using in-memory store fallback:`, (err as any).message);
        
        // In-memory toggle
        if (!inMemoryWatchlist.has(ctx.user.id)) {
          inMemoryWatchlist.set(ctx.user.id, []);
        }
        const userList = inMemoryWatchlist.get(ctx.user.id)!;
        const existingIndex = userList.findIndex(
          (item) => item.assetId === input.assetId && item.assetType === input.assetType
        );
        
        if (existingIndex > -1) {
          userList.splice(existingIndex, 1);
          return { success: true, added: false };
        } else {
          userList.push({
            id: Math.floor(Math.random() * 100000),
            userId: ctx.user.id,
            assetId: input.assetId,
            assetType: input.assetType,
            symbol: input.symbol,
          });
          return { success: true, added: true };
        }
      }
    }),
});