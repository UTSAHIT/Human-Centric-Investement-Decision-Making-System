import fetch from "node-fetch";

const YAHOO_CHART_URL = "https://query1.finance.yahoo.com/v8/finance/chart";
const symbol = "AAPL";

async function test() {
  try {
    const url = `${YAHOO_CHART_URL}/${encodeURIComponent(symbol)}?range=1y&interval=1d`;
    console.log("Fetching url:", url);
    const response = await fetch(url, { headers: { Accept: "application/json", "User-Agent": "Mozilla/5.0" } });
    console.log("Status:", response.status);
    const text = await response.text();
    console.log("Response starts with:", text.substring(0, 500));
  } catch (err) {
    console.error("Error:", err);
  }
}

test();
