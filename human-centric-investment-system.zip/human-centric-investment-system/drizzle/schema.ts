import { decimal, int, json, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User Investment Profile - stores quiz results and risk assessment
 */
export const investmentProfiles = mysqlTable("investment_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  riskTolerance: mysqlEnum("riskTolerance", ["conservative", "moderate", "aggressive"]).notNull(),
  investmentGoal: text("investmentGoal"),
  timeHorizon: mysqlEnum("timeHorizon", ["short_term", "medium_term", "long_term"]).notNull(),
  experienceLevel: mysqlEnum("experienceLevel", ["beginner", "intermediate", "advanced"]).notNull(),
  monthlyInvestment: decimal("monthlyInvestment", { precision: 12, scale: 2 }),
  quizResponses: json("quizResponses"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InvestmentProfile = typeof investmentProfiles.$inferSelect;
export type InsertInvestmentProfile = typeof investmentProfiles.$inferInsert;

/**
 * Stock data - stores stock information and real-time prices
 */
export const stocks = mysqlTable("stocks", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 20 }).notNull().unique(),
  name: text("name").notNull(),
  exchange: varchar("exchange", { length: 50 }),
  country: varchar("country", { length: 100 }),
  sector: varchar("sector", { length: 100 }),
  industry: varchar("industry", { length: 100 }),
  marketCap: decimal("marketCap", { precision: 20, scale: 2 }),
  peRatio: decimal("peRatio", { precision: 10, scale: 2 }),
  dividendYield: decimal("dividendYield", { precision: 8, scale: 4 }),
  description: text("description"),
  logoUrl: text("logoUrl"),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Stock = typeof stocks.$inferSelect;
export type InsertStock = typeof stocks.$inferInsert;

/**
 * Real-time stock prices - stores latest price data
 */
export const stockPrices = mysqlTable("stock_prices", {
  id: int("id").autoincrement().primaryKey(),
  stockId: int("stockId").notNull(),
  symbol: varchar("symbol", { length: 20 }).notNull(),
  currentPrice: decimal("currentPrice", { precision: 12, scale: 2 }).notNull(),
  openPrice: decimal("openPrice", { precision: 12, scale: 2 }),
  highPrice: decimal("highPrice", { precision: 12, scale: 2 }),
  lowPrice: decimal("lowPrice", { precision: 12, scale: 2 }),
  previousClose: decimal("previousClose", { precision: 12, scale: 2 }),
  change: decimal("change", { precision: 10, scale: 2 }),
  changePercent: decimal("changePercent", { precision: 8, scale: 4 }),
  volume: decimal("volume", { precision: 20, scale: 0 }),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type StockPrice = typeof stockPrices.$inferSelect;
export type InsertStockPrice = typeof stockPrices.$inferInsert;

/**
 * Mutual funds data - stores mutual fund information
 */
export const mutualFunds = mysqlTable("mutual_funds", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 50 }).notNull().unique(),
  name: text("name").notNull(),
  fundType: varchar("fundType", { length: 50 }),
  assetClass: varchar("assetClass", { length: 50 }),
  expenseRatio: decimal("expenseRatio", { precision: 8, scale: 4 }),
  aum: decimal("aum", { precision: 20, scale: 2 }),
  fundManager: text("fundManager"),
  description: text("description"),
  logoUrl: text("logoUrl"),
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MutualFund = typeof mutualFunds.$inferSelect;
export type InsertMutualFund = typeof mutualFunds.$inferInsert;

/**
 * Mutual fund prices - stores latest NAV data
 */
export const mutualFundPrices = mysqlTable("mutual_fund_prices", {
  id: int("id").autoincrement().primaryKey(),
  fundId: int("fundId").notNull(),
  symbol: varchar("symbol", { length: 50 }).notNull(),
  nav: decimal("nav", { precision: 12, scale: 4 }).notNull(),
  change: decimal("change", { precision: 10, scale: 4 }),
  changePercent: decimal("changePercent", { precision: 8, scale: 4 }),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type MutualFundPrice = typeof mutualFundPrices.$inferSelect;
export type InsertMutualFundPrice = typeof mutualFundPrices.$inferInsert;

/**
 * AI predictions - stores ML model predictions for stocks and funds
 */
export const predictions = mysqlTable("predictions", {
  id: int("id").autoincrement().primaryKey(),
  assetType: mysqlEnum("assetType", ["stock", "mutual_fund"]).notNull(),
  assetId: int("assetId").notNull(),
  symbol: varchar("symbol", { length: 50 }).notNull(),
  timeline: mysqlEnum("timeline", ["1_week", "1_month", "3_months", "1_year"]).notNull(),
  predictedPrice: decimal("predictedPrice", { precision: 12, scale: 2 }).notNull(),
  confidence: decimal("confidence", { precision: 5, scale: 2 }).notNull(),
  rmse: decimal("rmse", { precision: 12, scale: 4 }),
  mape: decimal("mape", { precision: 8, scale: 4 }),
  rSquared: decimal("rSquared", { precision: 8, scale: 4 }),
  modelType: varchar("modelType", { length: 50 }),
  historicalData: json("historicalData"),
  predictionData: json("predictionData"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt"),
});

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = typeof predictions.$inferInsert;

/**
 * Price alerts - stores user-set price thresholds
 */
export const priceAlerts = mysqlTable("price_alerts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  assetType: mysqlEnum("assetType", ["stock", "mutual_fund"]).notNull(),
  assetId: int("assetId").notNull(),
  symbol: varchar("symbol", { length: 50 }).notNull(),
  targetPrice: decimal("targetPrice", { precision: 12, scale: 2 }).notNull(),
  alertType: mysqlEnum("alertType", ["above", "below"]).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  notificationType: mysqlEnum("notificationType", ["in_app", "email", "both"]).default("in_app").notNull(),
  triggeredAt: timestamp("triggeredAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PriceAlert = typeof priceAlerts.$inferSelect;
export type InsertPriceAlert = typeof priceAlerts.$inferInsert;

/**
 * Watchlist - stores user's favorite stocks and funds
 */
export const watchlist = mysqlTable("watchlist", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  assetType: mysqlEnum("assetType", ["stock", "mutual_fund"]).notNull(),
  assetId: int("assetId").notNull(),
  symbol: varchar("symbol", { length: 50 }).notNull(),
  addedAt: timestamp("addedAt").defaultNow().notNull(),
});

export type WatchlistItem = typeof watchlist.$inferSelect;
export type InsertWatchlistItem = typeof watchlist.$inferInsert;

/**
 * Chat history - stores user interactions with AI assistant
 */
export const chatHistory = mysqlTable("chat_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  message: text("message").notNull(),
  context: json("context"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatHistory.$inferSelect;
export type InsertChatMessage = typeof chatHistory.$inferInsert;

/**
 * Portfolio holdings - stores user's purchased assets
 */
export const portfolioHoldings = mysqlTable("portfolio_holdings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  symbol: varchar("symbol", { length: 50 }).notNull(),
  assetType: mysqlEnum("assetType", ["stock", "mutual_fund"]).notNull(),
  shares: decimal("shares", { precision: 16, scale: 6 }).notNull(),
  avgCost: decimal("avgCost", { precision: 12, scale: 2 }).notNull(),
  purchaseDate: timestamp("purchaseDate").defaultNow().notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PortfolioHolding = typeof portfolioHoldings.$inferSelect;
export type InsertPortfolioHolding = typeof portfolioHoldings.$inferInsert;