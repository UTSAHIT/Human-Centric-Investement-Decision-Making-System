CREATE TABLE `chat_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`message` text NOT NULL,
	`context` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `investment_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`riskTolerance` enum('conservative','moderate','aggressive') NOT NULL,
	`investmentGoal` text,
	`timeHorizon` enum('short_term','medium_term','long_term') NOT NULL,
	`experienceLevel` enum('beginner','intermediate','advanced') NOT NULL,
	`monthlyInvestment` decimal(12,2),
	`quizResponses` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `investment_profiles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mutual_fund_prices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fundId` int NOT NULL,
	`symbol` varchar(50) NOT NULL,
	`nav` decimal(12,4) NOT NULL,
	`change` decimal(10,4),
	`changePercent` decimal(8,4),
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mutual_fund_prices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mutual_funds` (
	`id` int AUTO_INCREMENT NOT NULL,
	`symbol` varchar(50) NOT NULL,
	`name` text NOT NULL,
	`fundType` varchar(50),
	`assetClass` varchar(50),
	`expenseRatio` decimal(8,4),
	`aum` decimal(20,2),
	`fundManager` text,
	`description` text,
	`logoUrl` text,
	`lastUpdated` timestamp DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mutual_funds_id` PRIMARY KEY(`id`),
	CONSTRAINT `mutual_funds_symbol_unique` UNIQUE(`symbol`)
);
--> statement-breakpoint
CREATE TABLE `predictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assetType` enum('stock','mutual_fund') NOT NULL,
	`assetId` int NOT NULL,
	`symbol` varchar(50) NOT NULL,
	`timeline` enum('1_week','1_month','3_months','1_year') NOT NULL,
	`predictedPrice` decimal(12,2) NOT NULL,
	`confidence` decimal(5,2) NOT NULL,
	`rmse` decimal(12,4),
	`mape` decimal(8,4),
	`rSquared` decimal(8,4),
	`modelType` varchar(50),
	`historicalData` json,
	`predictionData` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp,
	CONSTRAINT `predictions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `price_alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`assetType` enum('stock','mutual_fund') NOT NULL,
	`assetId` int NOT NULL,
	`symbol` varchar(50) NOT NULL,
	`targetPrice` decimal(12,2) NOT NULL,
	`alertType` enum('above','below') NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`notificationType` enum('in_app','email','both') NOT NULL DEFAULT 'in_app',
	`triggeredAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `price_alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stock_prices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`stockId` int NOT NULL,
	`symbol` varchar(20) NOT NULL,
	`currentPrice` decimal(12,2) NOT NULL,
	`openPrice` decimal(12,2),
	`highPrice` decimal(12,2),
	`lowPrice` decimal(12,2),
	`previousClose` decimal(12,2),
	`change` decimal(10,2),
	`changePercent` decimal(8,4),
	`volume` decimal(20,0),
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stock_prices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`symbol` varchar(20) NOT NULL,
	`name` text NOT NULL,
	`exchange` varchar(50),
	`country` varchar(100),
	`sector` varchar(100),
	`industry` varchar(100),
	`marketCap` decimal(20,2),
	`peRatio` decimal(10,2),
	`dividendYield` decimal(8,4),
	`description` text,
	`logoUrl` text,
	`lastUpdated` timestamp DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stocks_id` PRIMARY KEY(`id`),
	CONSTRAINT `stocks_symbol_unique` UNIQUE(`symbol`)
);
--> statement-breakpoint
CREATE TABLE `watchlist` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`assetType` enum('stock','mutual_fund') NOT NULL,
	`assetId` int NOT NULL,
	`symbol` varchar(50) NOT NULL,
	`addedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `watchlist_id` PRIMARY KEY(`id`)
);
