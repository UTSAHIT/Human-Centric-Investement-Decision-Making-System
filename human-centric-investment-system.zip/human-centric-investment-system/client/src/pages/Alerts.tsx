import { useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Bell, Trash2, Plus } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Alerts() {
  const [, setLocation] = useLocation();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState({
    symbol: "",
    targetPrice: "",
    alertType: "above" as "above" | "below",
    notificationType: "in_app" as "in_app" | "email" | "both",
  });

  const { data: alerts, isLoading, refetch } = trpc.alerts.getAlerts.useQuery();
  const createAlertMutation = trpc.alerts.createAlert.useMutation();
  const deleteAlertMutation = trpc.alerts.deleteAlert.useMutation();

  const handleCreateAlert = async () => {
    if (!formData.symbol || !formData.targetPrice) {
      toast.error("Please fill in all fields");
      return;
    }

    try {
      await createAlertMutation.mutateAsync({
        assetType: "stock",
        assetId: 0,
        symbol: formData.symbol.toUpperCase(),
        targetPrice: parseFloat(formData.targetPrice),
        alertType: formData.alertType,
        notificationType: formData.notificationType,
      });

      toast.success("Alert created successfully!");
      setFormData({ symbol: "", targetPrice: "", alertType: "above", notificationType: "in_app" });
      setShowCreateForm(false);
      refetch();
    } catch (error) {
      toast.error("Failed to create alert");
    }
  };

  const handleDeleteAlert = async (alertId: number) => {
    try {
      await deleteAlertMutation.mutateAsync({ alertId });
      toast.success("Alert deleted");
      refetch();
    } catch (error) {
      toast.error("Failed to delete alert");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Button variant="ghost" onClick={() => setLocation("/")} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Price Alerts</h1>
            <p className="text-slate-600 mt-1">Monitor stocks and get notified when prices reach your targets</p>
          </div>
          <Button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="bg-emerald-500 hover:bg-emerald-600"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Alert
          </Button>
        </div>

        {/* Create Alert Form */}
        {showCreateForm && (
          <Card className="p-6 mb-6 bg-white border border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-4">Create New Alert</h3>
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium text-slate-600">Stock Symbol</label>
                <Input
                  placeholder="e.g., AAPL"
                  value={formData.symbol}
                  onChange={(e) => setFormData({ ...formData, symbol: e.target.value.toUpperCase() })}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600">Target Price</label>
                <Input
                  type="number"
                  placeholder="e.g., 150.00"
                  value={formData.targetPrice}
                  onChange={(e) => setFormData({ ...formData, targetPrice: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium text-slate-600">Alert Type</label>
                <select
                  value={formData.alertType}
                  onChange={(e) => setFormData({ ...formData, alertType: e.target.value as any })}
                  className="w-full mt-1 px-3 py-2 border border-slate-300 rounded-md text-sm"
                >
                  <option value="above">Alert when price goes ABOVE</option>
                  <option value="below">Alert when price goes BELOW</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-600">Notification Type</label>
                <select
                  value={formData.notificationType}
                  onChange={(e) => setFormData({ ...formData, notificationType: e.target.value as any })}
                  className="w-full mt-1 px-3 py-2 border border-slate-300 rounded-md text-sm"
                >
                  <option value="in_app">In-App Only</option>
                  <option value="email">Email Only</option>
                  <option value="both">Both</option>
                </select>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleCreateAlert}
                disabled={createAlertMutation.isPending}
                className="bg-emerald-500 hover:bg-emerald-600"
              >
                Create Alert
              </Button>
              <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                Cancel
              </Button>
            </div>
          </Card>
        )}

        {/* Alerts List */}
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        ) : alerts && alerts.length > 0 ? (
          <div className="space-y-3">
            {alerts.map((alert: any) => (
              <Card key={alert.id} className="p-4 bg-white border border-slate-200 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-slate-900">{alert.symbol}</h3>
                      <Badge variant={alert.alertType === "above" ? "default" : "secondary"}>
                        {alert.alertType === "above" ? "↑ Above" : "↓ Below"} ${alert.targetPrice.toFixed(2)}
                      </Badge>
                      <Badge variant="outline">{alert.notificationType}</Badge>
                      {alert.triggeredAt && (
                        <Badge className="bg-emerald-100 text-emerald-800">Triggered</Badge>
                      )}
                    </div>
                    <p className="text-sm text-slate-600">
                      {alert.assetType === "stock" ? "Stock" : "Mutual Fund"} • Created{" "}
                      {new Date(alert.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteAlert(alert.id)}
                    disabled={deleteAlertMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-8 bg-white border border-slate-200 text-center">
            <Bell className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="font-semibold text-slate-900 mb-2">No Alerts Yet</h3>
            <p className="text-slate-600 mb-4">Create your first price alert to get started</p>
            <Button onClick={() => setShowCreateForm(true)} className="bg-emerald-500 hover:bg-emerald-600">
              Create Alert
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
