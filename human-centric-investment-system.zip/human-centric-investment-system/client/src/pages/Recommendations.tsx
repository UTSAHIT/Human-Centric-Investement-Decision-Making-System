import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, TrendingUp, Shield, Zap, Sparkles, ArrowLeft, ArrowUpRight, Search, Activity, BookOpen } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Recommendations() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, loading: authLoading } = useAuth({ redirectOnUnauthenticated: false });

  const { data: recommendationsData, isLoading, error } = trpc.quiz.getRecommendations.useQuery(undefined, {
    enabled: isAuthenticated,
    retry: 2,
    retryDelay: 1000,
  });

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex flex-col justify-center p-8">
        <div className="max-w-6xl mx-auto w-full">
          <Skeleton className="h-12 w-48 bg-slate-800 mb-8" />
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-40 w-full bg-slate-800 rounded-2xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-8">
        <div className="max-w-xl w-full">
          <Button variant="ghost" onClick={() => setLocation("/")} className="text-slate-400 hover:text-white mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <Card className="p-8 bg-slate-800 border-slate-700 text-center relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl" />
            <AlertCircle className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">Sign In Required</h3>
            <p className="text-slate-300 text-sm leading-relaxed mb-6">
              Please sign in to view personalized investment recommendations.
            </p>
            <Button
              onClick={() => setLocation("/login")}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold"
            >
              Go to Sign In
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-8">
        <div className="max-w-xl w-full">
          <Button variant="ghost" onClick={() => setLocation("/")} className="text-slate-400 hover:text-white mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <Card className="p-8 bg-slate-800 border-slate-700 text-center relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-24 h-24 bg-red-500/10 rounded-full blur-2xl" />
            <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">Failed to Load Recommendations</h3>
            <p className="text-slate-300 text-sm leading-relaxed mb-6">
              We encountered an error while fetching your investment recommendations. This might be a temporary network issue.
            </p>
            <div className="space-y-3">
              <Button
                onClick={() => window.location.reload()}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold"
              >
                Try Again
              </Button>
              <Button
                onClick={() => setLocation("/quiz")}
                variant="outline"
                className="w-full text-white border-slate-600 hover:bg-slate-800"
              >
                Retake Quiz
              </Button>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  if (!recommendationsData || recommendationsData.error || !recommendationsData.profile) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-8">
        <div className="max-w-xl w-full">
          <Button variant="ghost" onClick={() => setLocation("/")} className="text-slate-400 hover:text-white mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <Card className="p-8 bg-slate-800 border-slate-700 text-center relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl" />
            <AlertCircle className="w-16 h-16 text-amber-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-2">No Investment Profile Found</h3>
            <p className="text-slate-300 text-sm leading-relaxed mb-6">
              To provide mathematically optimized Recommendations, we need to assess your risk tolerance, financial goals, and asset preferences.
            </p>
            <Button onClick={() => setLocation("/quiz")} className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold px-8 py-2">
              Start Profiling Quiz
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  const { profile, recommendations } = recommendationsData;

  const getProfileBadge = (tolerance: string) => {
    switch (tolerance?.toLowerCase()) {
      case "conservative":
        return { label: "Conservative Investor", color: "text-emerald-400 bg-emerald-400/10 border-emerald-500/30", icon: Shield };
      case "aggressive":
        return { label: "Aggressive Investor", color: "text-purple-400 bg-purple-400/10 border-purple-500/30", icon: Zap };
      default:
        return { label: "Balanced Investor", color: "text-blue-400 bg-blue-400/10 border-blue-500/30", icon: TrendingUp };
    }
  };

  const badge = getProfileBadge(profile?.riskTolerance || "moderate");
  const BadgeIcon = badge.icon;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between relative overflow-hidden">
      {/* Decorative Orbs */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto w-full px-4 py-8 relative z-10">
        {/* Navigation */}
        <Button variant="ghost" onClick={() => setLocation("/")} className="text-slate-400 hover:text-white mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Dashboard
        </Button>

        {/* Header Block */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10 pb-8 border-b border-slate-800/80">
          <div>
            <h1 className="text-4xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <Sparkles className="w-8 h-8 text-emerald-400" />
              Investment Recommendations
            </h1>
            <p className="text-slate-400 mt-1">Mathematically modeled allocations and matching stock portfolios.</p>
          </div>
          <div className={`flex items-center gap-3 px-5 py-3 border rounded-2xl ${badge.color} shadow-lg`}>
            <BadgeIcon className="w-6 h-6" />
            <div>
              <p className="text-[10px] uppercase tracking-wider text-slate-400">Determined Risk Class</p>
              <p className="font-bold text-base">{badge.label}</p>
            </div>
          </div>
        </div>

        {/* Profile Metric Highlights */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <div className="p-5 bg-slate-800/50 border border-slate-700/60 rounded-2xl shadow-xl">
            <span className="text-xs text-slate-400">Risk Profile</span>
            <p className="text-lg font-extrabold text-white mt-1 capitalize">{profile?.riskTolerance === "moderate" ? "balanced" : profile?.riskTolerance}</p>
          </div>
          <div className="p-5 bg-slate-800/50 border border-slate-700/60 rounded-2xl shadow-xl">
            <span className="text-xs text-slate-400">Time Horizon</span>
            <p className="text-lg font-extrabold text-white mt-1 capitalize">{profile?.timeHorizon?.replace("_", " ")}</p>
          </div>
          <div className="p-5 bg-slate-800/50 border border-slate-700/60 rounded-2xl shadow-xl">
            <span className="text-xs text-slate-400">Understanding</span>
            <p className="text-lg font-extrabold text-white mt-1 capitalize">{profile?.experienceLevel}</p>
          </div>
          <div className="p-5 bg-slate-800/50 border border-slate-700/60 rounded-2xl shadow-xl">
            <span className="text-xs text-slate-400">Investment Goal</span>
            <p className="text-lg font-extrabold text-white mt-1 capitalize">{profile?.investmentGoal?.replace("_", " ")}</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Matches Column (Left/Center) */}
          <div className="lg:col-span-2 space-y-10">
            {/* Stocks */}
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
                  <Activity className="w-6 h-6 text-emerald-400" />
                  Top Equities Matches
                </h2>
                <span className="text-xs text-slate-400">{recommendations?.topStocks?.length || 0} Assets Found</span>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {recommendations?.topStocks?.map((s: any) => (
                  <Card
                    key={s.symbol}
                    onClick={() => setLocation(`/stock/${s.symbol}`)}
                    className="p-5 bg-slate-800/40 border border-slate-700/80 hover:border-emerald-500/60 hover:bg-slate-800/70 cursor-pointer shadow-lg rounded-2xl relative overflow-hidden transition-all duration-300 group"
                  >
                    <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/[0.03] rounded-full blur-2xl group-hover:bg-emerald-500/10 transition-all duration-300" />
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <span className="text-xs font-semibold px-2 py-0.5 bg-slate-700/80 border border-slate-600 rounded text-emerald-300 uppercase">Equity</span>
                        <h3 className="text-xl font-bold text-white mt-2 group-hover:text-emerald-400 transition-colors">{s.symbol}</h3>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block uppercase">Match Score</span>
                        <span className="text-2xl font-black text-emerald-400">{s.matchScore}%</span>
                      </div>
                    </div>
                    <p className="text-sm text-slate-300 font-medium truncate mb-4">{s.name}</p>
                    <div className="flex justify-between items-center text-xs text-slate-400 pt-3 border-t border-slate-700/40">
                      <span>CV Volatility: <strong className="text-white">{s.volatility}%</strong></span>
                      <span className="flex items-center gap-1 text-emerald-400 group-hover:translate-x-1 transition-transform">
                        Explore <ArrowUpRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Mutual Funds */}
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
                  <BookOpen className="w-6 h-6 text-blue-400" />
                  Top Mutual Fund Matches
                </h2>
                <span className="text-xs text-slate-400">{recommendations?.topMutualFunds?.length || 0} Assets Found</span>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {recommendations?.topMutualFunds?.map((f: any) => (
                  <Card
                    key={f.symbol}
                    onClick={() => setLocation(`/stock/${f.symbol}`)}
                    className="p-5 bg-slate-800/40 border border-slate-700/80 hover:border-blue-500/60 hover:bg-slate-800/70 cursor-pointer shadow-lg rounded-2xl relative overflow-hidden transition-all duration-300 group"
                  >
                    <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/[0.03] rounded-full blur-2xl group-hover:bg-blue-500/10 transition-all duration-300" />
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <span className="text-xs font-semibold px-2 py-0.5 bg-slate-700/80 border border-slate-600 rounded text-blue-300 uppercase">Fund</span>
                        <h3 className="text-xl font-bold text-white mt-2 group-hover:text-blue-400 transition-colors">{f.symbol}</h3>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block uppercase">Match Score</span>
                        <span className="text-2xl font-black text-blue-400">{f.matchScore}%</span>
                      </div>
                    </div>
                    <p className="text-sm text-slate-300 font-medium truncate mb-4">{f.name}</p>
                    <div className="flex justify-between items-center text-xs text-slate-400 pt-3 border-t border-slate-700/40">
                      <span>Volatility: <strong className="text-white">{f.volatility}%</strong></span>
                      <span className="flex items-center gap-1 text-blue-400 group-hover:translate-x-1 transition-transform">
                        Explore <ArrowUpRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Allocation & Strategy (Right) */}
          <div className="space-y-6">
            <Card className="p-6 bg-slate-800/40 border border-slate-700/80 rounded-3xl shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/[0.02] rounded-full blur-3xl" />
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                Asset Allocation Plan
              </h3>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Equities / Stocks</span>
                    <span className="font-bold text-white">{profile?.riskTolerance === "conservative" ? "30%" : profile?.riskTolerance === "aggressive" ? "80%" : "60%"}</span>
                  </div>
                  <div className="h-2 bg-slate-900 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-400 rounded-full"
                      style={{ width: profile?.riskTolerance === "conservative" ? "30%" : profile?.riskTolerance === "aggressive" ? "80%" : "60%" }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Mutual Funds / Balanced</span>
                    <span className="font-bold text-white">{profile?.riskTolerance === "conservative" ? "60%" : profile?.riskTolerance === "aggressive" ? "15%" : "30%"}</span>
                  </div>
                  <div className="h-2 bg-slate-900 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-400 rounded-full"
                      style={{ width: profile?.riskTolerance === "conservative" ? "60%" : profile?.riskTolerance === "aggressive" ? "15%" : "30%" }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Fixed-Income / Cash</span>
                    <span className="font-bold text-white">{profile?.riskTolerance === "conservative" ? "10%" : profile?.riskTolerance === "aggressive" ? "5%" : "10%"}</span>
                  </div>
                  <div className="h-2 bg-slate-900 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-purple-400 rounded-full"
                      style={{ width: profile?.riskTolerance === "conservative" ? "10%" : profile?.riskTolerance === "aggressive" ? "5%" : "10%" }}
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-slate-950/40 border border-slate-700/60 rounded-2xl">
                <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Recommended Strategy</p>
                <p className="text-sm text-slate-300 mt-2 leading-relaxed">
                  {profile?.riskTolerance === "conservative"
                    ? "Focus extensively on regular dividends, diversified mutual funds, and large cap value plays. Limit exposure to extreme growth trends."
                    : profile?.riskTolerance === "aggressive"
                      ? "Aggressively target disruptive technology, clean energy growth plays, and sectoral mutual funds. Accept volatile index swings for high compounding gains."
                      : "Blend active high-quality large-cap stock picks with balanced, broad-market equity index funds. Maintain quarterly rebalancing."}
                </p>
              </div>
            </Card>

            {/* Bottom Explore Button */}
            <Card className="p-6 bg-gradient-to-r from-emerald-500/10 to-blue-500/10 border border-emerald-500/20 rounded-3xl shadow-xl text-center">
              <h3 className="font-bold text-white mb-2">Want to Search Custom Assets?</h3>
              <p className="text-slate-400 text-xs leading-relaxed mb-4">
                Use our real-time search engine to look up any stock or mutual fund and calculate dynamic matching percentages.
              </p>
              <div className="flex gap-3">
                <Button onClick={() => setLocation("/search")} className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold">
                  <Search className="w-4 h-4 mr-2" /> Search Market
                </Button>
                <Button variant="outline" onClick={() => setLocation("/quiz")} className="flex-1 border-slate-700 hover:bg-slate-800 text-slate-200">
                  Retake Quiz
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
      <div />
    </div>
  );
}
