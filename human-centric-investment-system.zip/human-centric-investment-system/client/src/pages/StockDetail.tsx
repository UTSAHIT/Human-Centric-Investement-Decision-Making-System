import { useMemo, useState } from "react";
import { useParams, useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, TrendingUp, TrendingDown, Bell, Heart } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { calculateVolatilityPercent, scoreAssetMatch } from "@/lib/investmentScoring";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function StockDetail() {
  const { symbol } = useParams<{ symbol: string }>();
  const [, setLocation] = useLocation();
  const [selectedTimeline, setSelectedTimeline] = useState<"1_week" | "1_month" | "3_months" | "1_year">("1_week");

  // What-If Simulation State Variables
  const [simReturn, setSimReturn] = useState<number | null>(null);
  const [simVol, setSimVol] = useState<number | null>(null);
  const [simHorizon, setSimHorizon] = useState<"short_term" | "medium_term" | "long_term" | null>(null);
  const [simRisk, setSimRisk] = useState<"conservative" | "moderate" | "aggressive" | null>(null);

  const { isAuthenticated } = useAuth({ redirectOnUnauthenticated: false });

  const { data: stock, isLoading: stockLoading } = trpc.market.getStock.useQuery({
    symbol: symbol || "",
  });

  const { data: profile, isLoading: profileLoading } = trpc.quiz.getProfile.useQuery(undefined, {
    retry: false,
    staleTime: 30000, // Cache for 30 seconds
  });
  
  // Only use the actual profile from server - no demo fallback
  const activeProfile = profile;

  const assetType = stock?.assetType === "mutual_fund" ? "mutual_fund" : "stock";

  // Watchlist & Alerts state and queries
  const [alertTargetPrice, setAlertTargetPrice] = useState<string>("");
  const [alertType, setAlertType] = useState<"above" | "below">("above");
  const [isAlertOpen, setIsAlertOpen] = useState(false);

  const utils = trpc.useUtils();
  const { data: watchlist } = trpc.portfolio.getWatchlist.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const toggleWatchlistMutation = trpc.portfolio.toggleWatchlist.useMutation({
    onSuccess: (data) => {
      utils.portfolio.getWatchlist.invalidate();
      toast.success(
        data.added 
          ? `${symbol?.toUpperCase()} added to Watchlist!` 
          : `${symbol?.toUpperCase()} removed from Watchlist!`
      );
    },
    onError: () => {
      toast.error("Failed to update watchlist");
    }
  });

  const isWatchlisted = useMemo(() => {
    if (!watchlist || !stock) return false;
    return watchlist.some((item) => item.symbol === stock.symbol);
  }, [watchlist, stock]);

  const createAlertMutation = trpc.alerts.createAlert.useMutation({
    onSuccess: () => {
      setIsAlertOpen(false);
      toast.success(`Price alert created for ${symbol?.toUpperCase()} at $${parseFloat(alertTargetPrice).toFixed(2)}!`);
    },
    onError: (err) => {
      toast.error(err.message || "Failed to create price alert");
    }
  });

  const handleCreateAlert = () => {
    if (!stock) return;
    const price = parseFloat(alertTargetPrice);
    if (isNaN(price) || price <= 0) {
      toast.error("Please enter a valid target price");
      return;
    }
    createAlertMutation.mutate({
      assetType,
      assetId: stock.id,
      symbol: stock.symbol,
      targetPrice: price,
      alertType,
    });
  };

  const { data: prediction, isLoading: predictionLoading } = trpc.predictions.getPrediction.useQuery(
    {
      assetType,
      symbol: symbol || "",
      timeline: selectedTimeline,
    },
    { enabled: !!stock?.symbol }
  );

  const recommendation = useMemo(() => {
    if (!stock) {
      return {
        action: "Review",
        badgeVariant: "secondary",
        matchScore: 0,
        reasoning: "Stock information loading...",
      };
    }

    // Default return if no prediction or profile
    if (!prediction || prediction.error || !stock.price || !prediction.predictedPrice) {
      return {
        action: "Hold",
        badgeVariant: "secondary",
        matchScore: profile ? 50 : 0,
        reasoning: profile
          ? `The forecasting engine is analyzing historical trend walk vectors for ${stock.symbol}. The latest live price is $${stock.price?.toFixed(2)}. Complete details will hydrate shortly.`
          : `The forecasting engine is analyzing historical trend walk vectors for ${stock.symbol}. Complete the risk profiling quiz to unlock custom Buy/Hold/Sell guidance tailored to your financial goals.`,
      };
    }

const priceHistory = prediction.historicalData || [];
    // Calculate expected change from PREDICTED price vs CURRENT price
    const currentPrice = stock.price || 0;
    const predictedPrice = prediction.predictedPrice || 0;
    const expectedChange = currentPrice > 0 && predictedPrice > 0
      ? ((predictedPrice - currentPrice) / currentPrice) * 100
      : 0;
    
    console.log("[StockDetail] Current price:", currentPrice);
    console.log("[StockDetail] Predicted price:", predictedPrice);
    console.log("[StockDetail] Expected change:", expectedChange.toFixed(2) + "%");

    // Determine action based on expected price change
    let action: "Buy" | "Hold" | "Sell" = "Hold";
    let badgeVariant = "secondary";

    if (expectedChange >= 3.0) {
      action = "Buy";
      badgeVariant = "default";
    } else if (expectedChange <= -2.0) {
      action = "Sell";
      badgeVariant = "destructive";
    }

    const volatility = calculateVolatilityPercent(prediction.historicalData || []);
    console.log("[StockDetail] Volatility:", volatility);
    console.log("[StockDetail] ExpectedChange:", expectedChange);
    console.log("[StockDetail] Current price:", stock.price, "Predicted:", prediction.predictedPrice);
    
    let matchScore = 50;
    let scoreComponents = {
      expectedReturn: 50,
      userRiskMatch: 50,
      marketMomentum: 50,
      diversification: 80,
      liquidity: 90
    };

    if (activeProfile) {
      const result = scoreAssetMatch(activeProfile, {
        assetType,
        volatilityPercent: volatility || 18, // Default volatility if calculation fails
        expectedChangePercent: expectedChange || 0,
        peRatio: stock.peRatio,
        dividendYield: stock.dividendYield,
      });
      console.log("[StockDetail] Score result:", result);
      matchScore = result.matchScore;
      scoreComponents = result.components;
    } else {
      console.log("[StockDetail] No profile found, using default score 50");
    }

    const direction = expectedChange >= 0 ? "rise" : "decline";
    const strength = Math.abs(expectedChange).toFixed(1);
    const baseReason = `The ${prediction.modelType} model estimates a ${direction} of ${strength}% over the next ${selectedTimeline.replace("_", " ")} with ${volatility.toFixed(1)}% annualized volatility.`;

    const profileReason = activeProfile
      ? `As a ${activeProfile.riskTolerance === "moderate" ? "balanced" : activeProfile.riskTolerance} investor with a ${activeProfile.timeHorizon.replace("_", " ")} horizon, this asset aligns with your profile by ${matchScore}%. We recommend ${action === "Buy"
        ? "adding exposure to this asset for capital growth"
        : action === "Sell"
          ? "reducing holding exposure to preserve asset capital"
          : "holding through short-term market cycles"
      }.`
      : "Complete the profiling quiz to receive personalized portfolio matching.";

    const caveat = "This is decision support, not a guaranteed market outcome.";

    return {
      action,
      badgeVariant,
      matchScore,
      scoreComponents,
      reasoning: `${baseReason} ${profileReason} Model confidence is ${prediction.confidence?.toFixed(0)}%. ${caveat}`,
    };
  }, [stock, prediction, activeProfile, selectedTimeline]);

  // 1. Resolve Actual Baseline Values
  const actualExpectedChange = useMemo(() => {
    if (!prediction || prediction.error || !stock || !stock.price || !prediction.predictedPrice) {
      return 5.5; // fallback
    }
    return ((prediction.predictedPrice - stock.price) / stock.price) * 100;
  }, [stock, prediction]);

  const actualVolatility = useMemo(() => {
    if (!prediction || !prediction.historicalData) return 18.2;
    return calculateVolatilityPercent(prediction.historicalData || []);
  }, [prediction]);

  const actualHorizon = profile?.timeHorizon || "medium_term";
  const actualRisk = profile?.riskTolerance || "moderate";

  const predictionQualityWarning = useMemo(() => {
    if (!prediction || prediction.error) return null;

    const lowConfidence = prediction.confidence !== undefined && prediction.confidence < 55;
    const lowR2 = prediction.rSquared !== undefined && prediction.rSquared < 0.5;
    const highError = prediction.mape !== undefined && prediction.mape > 25;

    if (lowConfidence || lowR2 || highError) {
      return "Prediction reliability is moderate-to-low for this asset; treat the signal as guidance, not certainty.";
    }

    return "Prediction metrics show reasonable model fit, but forecasts are still probabilistic and should be used with caution.";
  }, [prediction]);

  // 2. Resolve Active Simulated Values
  const currentExpectedChange = simReturn !== null ? simReturn : actualExpectedChange;
  const currentVolatility = simVol !== null ? simVol : actualVolatility;
  const currentHorizon = simHorizon !== null ? simHorizon : actualHorizon;
  const currentRisk = simRisk !== null ? simRisk : actualRisk;

  // 3. Compute Simulated Match Score & Components
  const simResult = useMemo(() => {
    const mockProfile = {
      riskTolerance: currentRisk,
      timeHorizon: currentHorizon,
      investmentGoal: profile?.investmentGoal || "capital_growth",
      experienceLevel: profile?.experienceLevel || "intermediate",
    };
    const mockAsset = {
      assetType: assetType as "mutual_fund" | "stock",
      volatilityPercent: currentVolatility,
      expectedChangePercent: currentExpectedChange,
      peRatio: stock?.peRatio || null,
      dividendYield: stock?.dividendYield || null,
    };
    return scoreAssetMatch(mockProfile, mockAsset);
  }, [currentRisk, currentHorizon, currentVolatility, currentExpectedChange, assetType, stock, profile]);

  if (stockLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <Skeleton className="h-12 w-48 mb-8" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!stock) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <Button variant="ghost" onClick={() => setLocation("/")} className="mb-4 text-slate-700 hover:text-slate-900 hover:bg-slate-200">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <p className="text-slate-600">Stock not found</p>
        </div>
      </div>
    );
  }

  const priceChange = stock.change || 0;
  const percentChange = stock.changePercent || 0;
  const isPositive = priceChange >= 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-6 text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-2xl px-4 py-2 border border-slate-700/30 transition-all"
        >
          <ArrowLeft className="w-4 h-4 mr-2 text-emerald-400" />
          Back to Command Center
        </Button>

        <div className="glass-panel rounded-[2rem] p-8 mb-8 border-slate-700/50 shadow-2xl relative overflow-hidden bg-slate-950/40 backdrop-blur-xl">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl" />
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 mb-6 relative z-10">
            <div>
              <h1 className="text-5xl font-black text-white tracking-tight">{stock.symbol}</h1>
              <p className="text-slate-300 mt-1.5 text-base">{stock.name}</p>
            </div>
            <div className="flex gap-3">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => {
                  if (!isAuthenticated) {
                    toast.error("Please sign in to manage your watchlist");
                    return;
                  }
                  if (stock) {
                    toggleWatchlistMutation.mutate({
                      assetId: stock.id,
                      assetType,
                      symbol: stock.symbol,
                    });
                  }
                }}
                disabled={toggleWatchlistMutation.isPending}
                className={`border-slate-700 font-semibold rounded-2xl h-10 px-4 transition-all ${
                  isWatchlisted 
                    ? "bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20 shadow-lg shadow-rose-950/20" 
                    : "text-slate-300 hover:bg-slate-800 hover:text-white bg-slate-900/60 shadow-xs"
                }`}
              >
                <Heart className={`w-4 h-4 mr-2 ${isWatchlisted ? "fill-rose-500 stroke-rose-500" : ""}`} />
                {isWatchlisted ? "Watchlisted" : "Watchlist"}
              </Button>
              
              <Dialog open={isAlertOpen} onOpenChange={setIsAlertOpen}>
                <DialogTrigger asChild>
                  <Button 
                    size="sm" 
                    onClick={() => {
                      if (!isAuthenticated) {
                        toast.error("Please sign in to set price alerts");
                        return;
                      }
                      if (stock) {
                        setAlertTargetPrice(stock.price ? (stock.price * 1.1).toFixed(2) : "100");
                        setIsAlertOpen(true);
                      }
                    }}
                    className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-2xl h-10 px-4 shadow-lg shadow-emerald-950/25 transition-all"
                  >
                    <Bell className="w-4 h-4 mr-2" />
                    Set Alert
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-950/95 border border-slate-700/80 backdrop-blur-2xl max-w-sm rounded-[2rem] p-6 text-white shadow-2xl">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-bold text-white">Set Price Alert</DialogTitle>
                    <DialogDescription className="text-slate-400 text-sm mt-1">
                      Get notified when {stock?.symbol} crosses your target price.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 my-4">
                    <div>
                      <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">Target Price ($)</label>
                      <input 
                        type="number"
                        step="0.01"
                        value={alertTargetPrice}
                        onChange={(e) => setAlertTargetPrice(e.target.value)}
                        className="w-full px-4 py-2.5 border border-slate-750 rounded-xl bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">Alert Condition</label>
                      <select 
                        value={alertType}
                        onChange={(e) => setAlertType(e.target.value as "above" | "below")}
                        className="w-full px-4 py-2.5 border border-slate-750 rounded-xl bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                      >
                        <option value="above" className="bg-slate-950">Price rises above ($)</option>
                        <option value="below" className="bg-slate-950">Price falls below ($)</option>
                      </select>
                    </div>
                  </div>
                  <DialogFooter className="flex justify-end gap-2 mt-4">
                    <Button variant="outline" size="sm" onClick={() => setIsAlertOpen(false)} className="border-slate-700 text-slate-300 hover:bg-slate-800 bg-slate-900/60 rounded-xl">
                      Cancel
                    </Button>
                    <Button 
                      size="sm" 
                      onClick={handleCreateAlert} 
                      disabled={createAlertMutation.isPending}
                      className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl"
                    >
                      {createAlertMutation.isPending ? "Creating..." : "Save Alert"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6 border-t border-slate-800/80 relative z-10">
            <div>
              <p className="text-slate-400 text-xs uppercase tracking-wider">Current Price</p>
              <p className="text-4xl font-extrabold text-white mt-1.5 tracking-tight">
                ${stock.price?.toFixed(2) || "N/A"}
              </p>
            </div>
            <div>
              <p className="text-slate-400 text-xs uppercase tracking-wider">Change</p>
              <div className="flex items-center gap-2 mt-1.5">
                {isPositive ? (
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-rose-400" />
                )}
                <span className={`text-2xl font-bold ${isPositive ? "text-emerald-400" : "text-rose-400"}`}>
                  {isPositive ? "+" : ""}
                  {priceChange.toFixed(2)}
                </span>
                <span className={`text-base ${isPositive ? "text-emerald-500" : "text-rose-500"}`}>
                  ({isPositive ? "+" : ""}
                  {percentChange.toFixed(2)}%)
                </span>
              </div>
            </div>
            <div>
              <p className="text-slate-400 text-xs uppercase tracking-wider">Exchange</p>
              <p className="text-lg font-semibold text-white mt-1.5">{stock.exchange || "N/A"}</p>
            </div>
            <div>
              <p className="text-slate-400 text-xs uppercase tracking-wider">Sector</p>
              <p className="text-lg font-semibold text-white mt-1.5">{stock.sector || "N/A"}</p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="predictions" className="bg-slate-950/40 backdrop-blur-xl rounded-[2.5rem] border border-slate-700/50 overflow-hidden shadow-2xl">
          <TabsList className="flex bg-slate-950/80 border-b border-slate-800/80 w-full justify-start p-2 gap-2 rounded-t-[2.5rem] rounded-b-none h-auto">
            <TabsTrigger 
              value="predictions" 
              className="px-5 py-2.5 text-slate-400 hover:text-white data-[state=active]:text-emerald-300 data-[state=active]:bg-emerald-500/10 rounded-2xl transition-all font-semibold"
            >
              AI Predictions
            </TabsTrigger>
            <TabsTrigger 
              value="chart" 
              className="px-5 py-2.5 text-slate-400 hover:text-white data-[state=active]:text-emerald-300 data-[state=active]:bg-emerald-500/10 rounded-2xl transition-all font-semibold"
            >
              Chart
            </TabsTrigger>
            <TabsTrigger 
              value="info" 
              className="px-5 py-2.5 text-slate-400 hover:text-white data-[state=active]:text-emerald-300 data-[state=active]:bg-emerald-500/10 rounded-2xl transition-all font-semibold"
            >
              Information
            </TabsTrigger>
            <TabsTrigger 
              value="xai" 
              className="px-5 py-2.5 text-slate-400 hover:text-white data-[state=active]:text-emerald-300 data-[state=active]:bg-emerald-500/10 rounded-2xl transition-all font-semibold"
            >
              XAI & Simulation
            </TabsTrigger>
          </TabsList>

          <TabsContent value="predictions" className="p-8">
            <div className="mb-6">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3">Select Timeline</p>
              <div className="flex gap-2 flex-wrap">
                {(["1_week", "1_month", "3_months", "1_year"] as const).map((timeline) => (
                  <Button
                    key={timeline}
                    variant={selectedTimeline === timeline ? "default" : "outline"}
                    onClick={() => setSelectedTimeline(timeline)}
                    className={
                      selectedTimeline === timeline
                        ? "bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold px-4 py-2 rounded-xl transition-all"
                        : "border-slate-700 text-slate-300 hover:bg-slate-800 bg-slate-900/60 font-semibold px-4 py-2 rounded-xl transition-all"
                    }
                  >
                    {timeline === "1_week"
                      ? "1 Week"
                      : timeline === "1_month"
                        ? "1 Month"
                        : timeline === "3_months"
                          ? "3 Months"
                          : "1 Year"}
                  </Button>
                ))}
              </div>
            </div>

            <div className="p-6 mb-8 bg-slate-900/40 border border-slate-800 rounded-2xl">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <h3 className="text-lg font-semibold text-white">AI Investment Insight</h3>
                  <p className="text-sm text-slate-400 mt-1">Personalized reasoning based on your allocation profile and the latest price forecast.</p>
                  {predictionQualityWarning ? (
                    <p className={`text-sm mt-2 ${predictionQualityWarning.includes("low") ? "text-amber-400" : "text-slate-400"}`}>
                      {predictionQualityWarning}
                    </p>
                  ) : null}
                </div>
                <Badge
                  variant={
                    recommendation.badgeVariant === "destructive"
                      ? "destructive"
                      : "secondary"
                  }
                  className="uppercase tracking-wide px-3 py-1 text-xs font-bold rounded-lg"
                >
                  {recommendation.action}
                </Badge>
              </div>
              <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-slate-200 text-base leading-relaxed flex-1">{recommendation.reasoning}</p>
                <div className="rounded-2xl border border-slate-850 bg-slate-950/60 p-4 text-center min-w-[120px] shadow-lg">
                  <p className="text-[10px] uppercase tracking-[0.24em] text-slate-400 font-semibold">Profile Match</p>
                  <p className="text-3xl font-black text-white mt-1">{recommendation.matchScore}%</p>
                </div>
              </div>
            </div>

            {predictionLoading ? (
              <Skeleton className="h-64 w-full rounded-2xl bg-slate-800/40" />
            ) : prediction && !prediction.error ? (
              <div className="space-y-8">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-5 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl">
                    <p className="text-slate-400 text-xs uppercase tracking-wider">Predicted Price</p>
                    <p className="text-2xl font-bold text-emerald-400 mt-2">
                      ${prediction.predictedPrice?.toFixed(2) || "N/A"}
                    </p>
                  </div>

                  <div className="p-5 bg-blue-500/5 border border-blue-500/20 rounded-2xl">
                    <p className="text-slate-400 text-xs uppercase tracking-wider">Confidence</p>
                    <p className="text-2xl font-bold text-blue-400 mt-2">
                      {prediction.confidence?.toFixed(0) || "N/A"}%
                    </p>
                  </div>

                  <div className="p-5 bg-purple-500/5 border border-purple-500/20 rounded-2xl">
                    <p className="text-slate-400 text-xs uppercase tracking-wider">Model Type</p>
                    <p className="text-lg font-bold text-purple-400 mt-2 truncate">{prediction.modelType || "N/A"}</p>
                  </div>

                  <div className="p-5 bg-amber-500/5 border border-amber-500/20 rounded-2xl">
                    <p className="text-slate-400 text-xs uppercase tracking-wider">R² Score</p>
                    <p className="text-2xl font-bold text-amber-400 mt-2">
                      {prediction.rSquared ? (prediction.rSquared * 100).toFixed(1) : "N/A"}%
                    </p>
                  </div>
                </div>

                <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-2xl">
                  <h3 className="font-semibold text-white mb-4">Accuracy Metrics</h3>
                  <div className="grid grid-cols-3 gap-6">
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-wider">RMSE</p>
                      <p className="text-lg font-bold text-white mt-1">
                        ${prediction.rmse?.toFixed(2) || "N/A"}
                      </p>
                      <p className="text-[10px] text-slate-500 mt-1">Average error</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-wider">MAPE</p>
                      <p className="text-lg font-bold text-white mt-1">
                        {prediction.mape?.toFixed(2) || "N/A"}%
                      </p>
                      <p className="text-[10px] text-slate-500 mt-1">% Error</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 uppercase tracking-wider">R² (Variance)</p>
                      <p className="text-lg font-bold text-white mt-1">
                        {prediction.rSquared ? (prediction.rSquared * 100).toFixed(1) : "N/A"}%
                      </p>
                      <p className="text-[10px] text-slate-500 mt-1">Model variance</p>
                    </div>
                  </div>
                </div>

                {prediction.predictionData ? (
                  <div className="p-6 border border-slate-800 rounded-2xl bg-slate-950/20">
                    <h3 className="font-semibold text-white mb-4">Price Forecast</h3>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={(prediction.predictionData as any) || []}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                        <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                        <YAxis stroke="#64748b" fontSize={11} />
                        <Tooltip 
                          contentStyle={{ background: "#0f172a", border: "1px solid #334155", borderRadius: "12px" }}
                          labelStyle={{ color: "#94a3b8" }}
                          itemStyle={{ color: "#10b981" }}
                        />
                         <Legend />
                        <Line
                          type="monotone"
                          dataKey="price"
                          stroke="#10b981"
                          strokeWidth={2.5}
                          dot={false}
                          name="Predicted Price"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : null}
              </div>
            ) : (
              <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-2xl text-slate-300">
                <h4 className="font-semibold text-white">Historical Prediction Processing</h4>
                <p className="text-sm mt-1.5 text-slate-400 leading-relaxed">
                  {prediction?.error || "Historical pricing models are being synchronized. Complete the profiling quiz or query a seeded asset like AAPL, TSLA, or MSFT to preview live multi-model simulations."}
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="chart" className="p-8">
            {prediction && prediction.historicalData && prediction.historicalData.length > 0 ? (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white mb-4">Historical Price Trend</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={prediction.historicalData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                    <YAxis
                      domain={["auto", "auto"]}
                      stroke="#64748b"
                      fontSize={11}
                      tickLine={false}
                      tickFormatter={(value) => `$${value}`}
                    />
                    <Tooltip
                      contentStyle={{ background: "#0f172a", border: "1px solid #334155", borderRadius: "12px" }}
                      labelStyle={{ color: "#94a3b8" }}
                      itemStyle={{ color: "#38bdf8" }}
                      formatter={(value: any) => [`$${parseFloat(value).toFixed(2)}`, "Price"]}
                    />
                    <Line
                      type="monotone"
                      dataKey="price"
                      stroke="#3b82f6"
                      strokeWidth={2.5}
                      dot={false}
                      name="Price ($)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-slate-400 text-center py-8">Historical price data is loading or currently unavailable.</p>
            )}
          </TabsContent>

          <TabsContent value="info" className="p-8">
            <div className="space-y-6">
              {stock.description && (
                <div>
                  <h3 className="font-semibold text-white mb-2">
                    {stock.assetType === "mutual_fund" ? "About This Fund" : "About"}
                  </h3>
                  <p className="text-slate-300 leading-relaxed">{stock.description}</p>
                </div>
              )}
              {stock.industry && stock.assetType === "mutual_fund" && (
                <div>
                  <h3 className="font-semibold text-white mb-2">Fund Type</h3>
                  <p className="text-slate-300">{stock.industry}</p>
                </div>
              )}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6 border-t border-slate-800/80">
                {stock.marketCap && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider">AUM / Market Cap</p>
                    <p className="font-semibold text-white mt-1 text-lg">
                      ${(Number(stock.marketCap) / 1e9).toFixed(2)}B
                    </p>
                  </div>
                )}
                {stock.peRatio && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider">P/E Ratio</p>
                    <p className="font-semibold text-white mt-1 text-lg">{Number(stock.peRatio).toFixed(2)}</p>
                  </div>
                )}
                {stock.dividendYield && stock.dividendYield > 0 && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider">Dividend Yield</p>
                    <p className="font-semibold text-white mt-1 text-lg">{(stock.dividendYield * 100).toFixed(2)}%</p>
                  </div>
                )}
                {stock.exchange && stock.exchange !== "N/A" && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider">Exchange</p>
                    <p className="font-semibold text-white mt-1 text-lg">{stock.exchange}</p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="xai" className="p-8">
            <div className="grid lg:grid-cols-5 gap-8">
              {/* Left Side: XAI SHAP Panel */}
              <div className="lg:col-span-3 space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-white">Explainable AI (XAI) Alignment Breakdown</h3>
                  <p className="text-sm text-slate-400 mt-1">
                    How your personalized matching score is calculated. Based on the five core criteria weights of the Human-Centric DSS model.
                  </p>
                </div>

                <div className="space-y-6 bg-slate-900/40 p-6 rounded-[2rem] border border-slate-800">
                  {/* Factor 1: Expected Return */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="font-semibold text-slate-200">1. Return Projection (35% Weight)</span>
                      <span className="font-bold text-white">
                        {recommendation.scoreComponents?.expectedReturn || 50}/100
                        <span className="text-slate-500 font-normal ml-1">
                          (Contribution: {((recommendation.scoreComponents?.expectedReturn || 50) * 0.35).toFixed(1)}%)
                        </span>
                      </span>
                    </div>
                    <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full"
                        style={{ width: `${recommendation.scoreComponents?.expectedReturn || 50}%` }}
                      />
                    </div>
                    <p className="text-xs text-slate-400 mt-2">
                      Based on AI forecasting. A {actualExpectedChange >= 0 ? "gain" : "loss"} of {Math.abs(actualExpectedChange).toFixed(1)}% is projected over the next {selectedTimeline.replace("_", " ")}.
                    </p>
                  </div>

                  {/* Factor 2: User Risk Match */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="font-semibold text-slate-200">2. Risk Profile Alignment (25% Weight)</span>
                      <span className="font-bold text-white">
                        {recommendation.scoreComponents?.userRiskMatch || 50}/100
                        <span className="text-slate-500 font-normal ml-1">
                          (Contribution: {((recommendation.scoreComponents?.userRiskMatch || 50) * 0.25).toFixed(1)}%)
                        </span>
                      </span>
                    </div>
                    <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-500 rounded-full"
                        style={{ width: `${recommendation.scoreComponents?.userRiskMatch || 50}%` }}
                      />
                    </div>
                    <p className="text-xs text-slate-400 mt-2">
                      Matches your <strong className="capitalize">{actualRisk}</strong> profile (time horizon: <strong className="capitalize">{actualHorizon.replace("_", " ")}</strong>) against the asset's {actualVolatility.toFixed(1)}% volatility.
                    </p>
                  </div>

                  {/* Factor 3: Market Momentum */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="font-semibold text-slate-200">3. Market Momentum (20% Weight)</span>
                      <span className="font-bold text-white">
                        {recommendation.scoreComponents?.marketMomentum || 50}/100
                        <span className="text-slate-500 font-normal ml-1">
                          (Contribution: {((recommendation.scoreComponents?.marketMomentum || 50) * 0.20).toFixed(1)}%)
                        </span>
                      </span>
                    </div>
                    <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-purple-500 rounded-full"
                        style={{ width: `${recommendation.scoreComponents?.marketMomentum || 50}%` }}
                      />
                    </div>
                    <p className="text-xs text-slate-400 mt-2">
                      Measures direction strength. AI classifies the current sentiment and price action for {symbol} as {actualExpectedChange > 1.5 ? "Bullish" : actualExpectedChange < -1.5 ? "Bearish" : "Stable"}.
                    </p>
                  </div>

                  {/* Factor 4: Strategic Diversification */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="font-semibold text-slate-200">4. Strategic Allocation Fit (10% Weight)</span>
                      <span className="font-bold text-white">
                        {recommendation.scoreComponents?.diversification || 80}/100
                        <span className="text-slate-500 font-normal ml-1">
                          (Contribution: {((recommendation.scoreComponents?.diversification || 80) * 0.10).toFixed(1)}%)
                        </span>
                      </span>
                    </div>
                    <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full"
                        style={{ width: `${recommendation.scoreComponents?.diversification || 80}%` }}
                      />
                    </div>
                    <p className="text-xs text-slate-400 mt-2">
                      How this asset class ({assetType === "mutual_fund" ? "Mutual Fund" : "Equity Stock"}) fits within the target asset mix for a {actualRisk} portfolio.
                    </p>
                  </div>

                  {/* Factor 5: Asset Liquidity */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="font-semibold text-slate-200">5. Liquidity Buffer (10% Weight)</span>
                      <span className="font-bold text-white">
                        {recommendation.scoreComponents?.liquidity || 90}/100
                        <span className="text-slate-500 font-normal ml-1">
                          (Contribution: {((recommendation.scoreComponents?.liquidity || 90) * 0.10).toFixed(1)}%)
                        </span>
                      </span>
                    </div>
                    <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-cyan-500 rounded-full"
                        style={{ width: `${recommendation.scoreComponents?.liquidity || 90}%` }}
                      />
                    </div>
                    <p className="text-xs text-slate-400 mt-2">
                      Direct equities trade instantly on market hours (T+1), while mutual funds execute at daily end-of-day NAV cutoffs (T+2 settlement).
                    </p>
                  </div>
                </div>

                <div className="p-5 bg-emerald-500/5 border border-emerald-500/15 rounded-2xl text-xs text-slate-300 leading-relaxed">
                  <h4 className="font-bold text-emerald-300 flex items-center gap-1.5 mb-1.5">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    How DSS Human-Centric AI Tailored This Asset For You:
                  </h4>
                  {profile ? (
                    <span>
                      Since your profile is set to <strong className="capitalize">{profile.riskTolerance}</strong> and your objective is <strong className="capitalize">{profile.investmentGoal?.replace("_", " ")}</strong>, our decision engine weighs downside protection. This asset achieves a <strong>{recommendation.matchScore}%</strong> alignment score. The primary driver is your risk score ({recommendation.scoreComponents?.userRiskMatch || 50}/100), reflecting your comfort level with {symbol}'s {actualVolatility.toFixed(1)}% volatility.
                    </span>
                  ) : (
                    <span>
                      You have not completed the investor profiling quiz. This score uses balanced moderate weights as default benchmarks. Finish the risk profiling quiz to customize these factors and maximize target compounding!
                    </span>
                  )}
                </div>
              </div>

              {/* Right Side: What-If Simulator Panel */}
              <div className="lg:col-span-2 space-y-6 lg:border-l lg:border-slate-800 lg:pl-8">
                <div>
                  <h3 className="text-xl font-bold text-white">What-If Simulator</h3>
                  <p className="text-sm text-slate-400 mt-1">
                    Test how changes in the market environment or your personal risk profile impact your investment alignment score in real-time.
                  </p>
                </div>

                {/* Score Comparison Display */}
                <div className="p-5 bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-850 text-white rounded-3xl text-center shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-500/10 rounded-full blur-2xl" />

                  <p className="text-xs uppercase tracking-widest text-slate-400 font-semibold font-bold">Simulated Match Score</p>
                  <div className="flex items-center justify-center gap-3 mt-2">
                    <span className="text-5xl font-black text-emerald-400">{simResult.matchScore}%</span>
                    <div className="text-left leading-none border-l border-slate-700 pl-3">
                      <span className="text-[10px] text-slate-500 block font-medium">Original baseline</span>
                      <span className="text-base font-bold text-slate-400">{recommendation.matchScore}%</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-slate-800 flex justify-between text-xs text-slate-400">
                    <span>Expected: <strong>{currentExpectedChange.toFixed(1)}%</strong></span>
                    <span>Volatility: <strong>{currentVolatility.toFixed(1)}%</strong></span>
                    <span className="capitalize font-semibold">Risk: <strong>{currentRisk === "moderate" ? "balanced" : currentRisk}</strong></span>
                  </div>
                </div>

                {/* Preset Controls */}
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-400 block">Scenario Presets</span>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSimReturn(25.0);
                        setSimVol(14.0);
                      }}
                      className="text-xs border-slate-800 hover:bg-slate-800 text-slate-200 bg-slate-900/60 rounded-xl py-4 h-9"
                    >
                      🚀 Hyper Bull Run
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSimReturn(-30.0);
                        setSimVol(40.0);
                      }}
                      className="text-xs border-slate-800 hover:bg-slate-800 text-slate-200 bg-slate-900/60 rounded-xl py-4 h-9"
                    >
                      📉 Market Crash
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSimReturn(2.0);
                        setSimVol(38.0);
                      }}
                      className="text-xs border-slate-800 hover:bg-slate-800 text-slate-200 bg-slate-900/60 rounded-xl py-4 h-9"
                    >
                      ⚡ High-Vol Chop
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSimReturn(null);
                        setSimVol(null);
                        setSimHorizon(null);
                        setSimRisk(null);
                      }}
                      className="text-xs text-slate-500 hover:bg-slate-800 hover:text-slate-300"
                    >
                      🔄 Reset Baseline
                    </Button>
                  </div>
                </div>

                {/* Sliders and Selector Inputs */}
                <div className="space-y-5 pt-4 border-t border-slate-800">
                  {/* Slider 1: Expected Return */}
                  <div>
                    <div className="flex justify-between text-xs text-slate-400 mb-1.5">
                      <span>Simulated Return: <strong className={currentExpectedChange >= 0 ? "text-emerald-400" : "text-rose-400"}>
                        {currentExpectedChange >= 0 ? "+" : ""}{currentExpectedChange.toFixed(1)}%
                      </strong></span>
                      <span className="text-[10px] text-slate-500">Range: -45% to +45%</span>
                    </div>
                    <input
                      type="range"
                      min="-45"
                      max="45"
                      step="0.5"
                      value={currentExpectedChange}
                      onChange={(e) => setSimReturn(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                    />
                  </div>

                  {/* Slider 2: Volatility */}
                  <div>
                    <div className="flex justify-between text-xs text-slate-400 mb-1.5">
                      <span>Simulated Volatility: <strong className="text-white">{currentVolatility.toFixed(1)}%</strong></span>
                      <span className="text-[10px] text-slate-500">Range: 5% to 65%</span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="65"
                      step="0.5"
                      value={currentVolatility}
                      onChange={(e) => setSimVol(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                  </div>

                  {/* Selector 1: Risk Tolerance */}
                  <div>
                    <span className="text-xs font-semibold text-slate-400 block mb-2">Simulated Investor Risk Tolerance</span>
                    <div className="grid grid-cols-3 gap-2">
                      {(["conservative", "moderate", "aggressive"] as const).map((r) => (
                        <Button
                          key={r}
                          variant={currentRisk === r ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSimRisk(r)}
                          className={`text-xs uppercase h-9 tracking-wider rounded-xl ${currentRisk === r
                            ? "bg-emerald-500/20 text-emerald-300 font-bold border-emerald-500/55 hover:bg-emerald-500/30"
                            : "border-slate-800 text-slate-400 hover:bg-slate-800 bg-slate-900/40"
                            }`}
                        >
                          {r === "moderate" ? "balanced" : r}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Selector 2: Time Horizon */}
                  <div>
                    <span className="text-xs font-semibold text-slate-400 block mb-2">Simulated Holding Horizon</span>
                    <div className="grid grid-cols-3 gap-2">
                      {(["short_term", "medium_term", "long_term"] as const).map((h) => (
                        <Button
                          key={h}
                          variant={currentHorizon === h ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSimHorizon(h)}
                          className={`text-xs h-9 rounded-xl ${currentHorizon === h
                            ? "bg-emerald-500/20 text-emerald-300 font-bold border-emerald-500/55 hover:bg-emerald-500/30"
                            : "border-slate-800 text-slate-400 hover:bg-slate-800 bg-slate-900/40"
                            }`}
                        >
                          {h === "short_term" ? "Short" : h === "medium_term" ? "Medium" : "Long"}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-955/40 rounded-xl text-xs text-slate-400 border border-slate-850 leading-relaxed">
                  <strong className="text-slate-200 block mb-1">💡 Scenario Insight:</strong>
                  {simResult.matchScore < 45 ? (
                    <span>
                      This configuration yields a <strong>Weak Match ({simResult.matchScore}%)</strong>. Under high-volatility panic or deep losses, capital preservation parameters penalize alignment to protect your portfolio.
                    </span>
                  ) : simResult.matchScore < 70 ? (
                    <span>
                      This configuration yields a <strong>Balanced Match ({simResult.matchScore}%)</strong>. The return expectations offer a fair reward for the simulated risk class.
                    </span>
                  ) : (
                    <span>
                      This configuration yields a <strong>High-Compatibility Match ({simResult.matchScore}%)</strong>! The returns are strongly optimized against your profile, offering high compounding efficiency.
                    </span>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
