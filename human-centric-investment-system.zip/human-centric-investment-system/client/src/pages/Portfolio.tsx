import { useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown, ArrowLeft, Plus, Trash2, AlertTriangle, CheckCircle, Info } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Portfolio() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, loading: authLoading } = useAuth({ redirectOnUnauthenticated: false });

  const { data, isLoading, refetch } = trpc.portfolio.getPortfolio.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 60000,
  });

  const addMutation = trpc.portfolio.addHolding.useMutation({
    onSuccess: () => refetch(),
  });

  const removeMutation = trpc.portfolio.removeHolding.useMutation({
    onSuccess: () => refetch(),
  });

  const { data: alertsData, refetch: refetchAlerts } = trpc.portfolio.getPortfolioAlerts.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 60000,
  });

  const [showAdd, setShowAdd] = useState(false);
  const [addSymbol, setAddSymbol] = useState("");
  const [addType, setAddType] = useState<"stock" | "mutual_fund">("stock");
  const [addShares, setAddShares] = useState("");
  const [addCost, setAddCost] = useState("");

  const handleAdd = () => {
    if (!addSymbol || !addShares || !addCost) return;
    addMutation.mutate({
      symbol: addSymbol.toUpperCase(),
      assetType: addType,
      shares: parseFloat(addShares),
      avgCost: parseFloat(addCost),
    });
    setAddSymbol("");
    setAddShares("");
    setAddCost("");
    setShowAdd(false);
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "danger": return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case "warning": return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case "success": return <CheckCircle className="w-4 h-4 text-emerald-500" />;
      default: return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="max-w-4xl w-full p-8">
          <Skeleton className="h-12 w-48 mb-8" />
          <div className="space-y-4">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full" />)}
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-8">
        <Card className="p-8 max-w-md w-full text-center">
          <h3 className="text-xl font-bold mb-2">Sign In Required</h3>
          <p className="text-slate-600 mb-4">Please sign in to view your portfolio.</p>
          <Button onClick={() => setLocation("/login")}>Go to Sign In</Button>
        </Card>
      </div>
    );
  }

  const isPositive = (data?.totalPnL ?? 0) >= 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <Button variant="ghost" onClick={() => setLocation("/")} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" /> Dashboard
        </Button>

        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">My Portfolio</h1>
            <p className="text-slate-500 text-sm mt-1">Live tracking with real-time prices</p>
          </div>
          <Button onClick={() => setShowAdd(!showAdd)} className="bg-emerald-500 hover:bg-emerald-600">
            <Plus className="w-4 h-4 mr-2" /> Add Holding
          </Button>
        </div>

        {showAdd && (
          <Card className="p-6 mb-6 bg-white border border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-4">Add New Holding</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <Input
                placeholder="Symbol (e.g. AAPL)"
                value={addSymbol}
                onChange={(e) => setAddSymbol(e.target.value)}
                className="uppercase"
              />
              <select
                value={addType}
                onChange={(e) => setAddType(e.target.value as "stock" | "mutual_fund")}
                className="border border-slate-200 rounded-md px-3 py-2 text-sm bg-white"
              >
                <option value="stock">Stock</option>
                <option value="mutual_fund">Mutual Fund</option>
              </select>
              <Input
                placeholder="Shares"
                type="number"
                value={addShares}
                onChange={(e) => setAddShares(e.target.value)}
              />
              <Input
                placeholder="Avg Cost ($)"
                type="number"
                value={addCost}
                onChange={(e) => setAddCost(e.target.value)}
              />
              <Button onClick={handleAdd} className="bg-emerald-500 hover:bg-emerald-600">Add</Button>
            </div>
          </Card>
        )}

        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="p-5 bg-white border border-slate-200">
            <p className="text-sm text-slate-500">Total Value</p>
            <p className="text-2xl font-bold text-slate-900 mt-1">${(data?.totalValue ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </Card>
          <Card className="p-5 bg-white border border-slate-200">
            <p className="text-sm text-slate-500">Cost Basis</p>
            <p className="text-2xl font-bold text-slate-700 mt-1">${(data?.totalCost ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </Card>
          <Card className="p-5 bg-white border border-slate-200">
            <p className="text-sm text-slate-500">Total P/L</p>
            <div className="flex items-center gap-2 mt-1">
              {isPositive ? <TrendingUp className="w-5 h-5 text-emerald-600" /> : <TrendingDown className="w-5 h-5 text-red-500" />}
              <p className={`text-2xl font-bold ${isPositive ? "text-emerald-600" : "text-red-500"}`}>
                {isPositive ? "+" : ""}{data?.totalPnL?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ({data?.totalPnLPercent?.toFixed(2) ?? "0.00"}%)
              </p>
            </div>
          </Card>
        </div>

        {alertsData?.alerts && alertsData.alerts.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              Portfolio Alerts
            </h2>
            <div className="space-y-2">
              {alertsData.alerts.map((alert, i) => (
                <div
                  key={i}
                  className={`flex items-center gap-3 p-3 rounded-xl border ${
                    alert.severity === "danger" ? "bg-red-50 border-red-200" :
                    alert.severity === "warning" ? "bg-amber-50 border-amber-200" :
                    alert.severity === "success" ? "bg-emerald-50 border-emerald-200" :
                    "bg-blue-50 border-blue-200"
                  }`}
                >
                  {getSeverityIcon(alert.severity)}
                  <span className="text-sm font-semibold text-slate-800">{alert.symbol}:</span>
                  <span className="text-sm text-slate-600">{alert.message}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div>
          <h2 className="text-lg font-bold text-slate-900 mb-4">Holdings</h2>
          {data?.holdings && data.holdings.length > 0 ? (
            <div className="space-y-3">
              {data.holdings.map((h: any) => {
                const pos = h.pnl >= 0;
                return (
                  <Card key={h.id} className="p-5 bg-white border border-slate-200 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-bold text-slate-900">{h.symbol}</h3>
                          <Badge variant="outline" className="text-xs capitalize">{h.assetType}</Badge>
                        </div>
                        <p className="text-sm text-slate-500">{h.shares} shares @ ${h.avgCost.toFixed(2)} avg</p>
                        <p className="text-xs text-slate-400 mt-1">
                          Live: ${h.currentPrice.toFixed(2)} {h.priceError ? "(price unavailable)" : ""}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-slate-900">${h.currentValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                      <div className="flex items-center gap-2 justify-end">
                        {pos ? <TrendingUp className="w-4 h-4 text-emerald-500" /> : <TrendingDown className="w-4 h-4 text-red-500" />}
                        <span className={`text-sm font-bold ${pos ? "text-emerald-600" : "text-red-500"}`}>
                          {pos ? "+" : ""}${h.pnl.toFixed(2)} ({h.pnlPercent.toFixed(2)}%)
                        </span>
                      </div>
                      <button
                        onClick={() => removeMutation.mutate({ holdingId: h.id })}
                        className="text-xs text-slate-400 hover:text-red-500 mt-1 flex items-center gap-1 ml-auto"
                      >
                        <Trash2 className="w-3 h-3" /> Remove
                      </button>
                    </div>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="p-8 bg-white border border-slate-200 text-center">
              <p className="text-slate-500 mb-4">No holdings yet. Add your first asset to start tracking.</p>
              <Button onClick={() => setShowAdd(true)} className="bg-emerald-500 hover:bg-emerald-600">
                <Plus className="w-4 h-4 mr-2" /> Add First Holding
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}