import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Search, Target, Brain, AlertCircle, BarChart3, RefreshCw, ArrowRight, TrendingDown, LogOut, Heart } from "lucide-react";

import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: profile, isLoading: profileLoading } = trpc.quiz.getProfile.useQuery(undefined, {
    retry: false,
    enabled: isAuthenticated,
  });

  const { data: recommendations, isLoading: recLoading, error: recError } = trpc.quiz.getRecommendations.useQuery(undefined, {
    retry: false,
    enabled: isAuthenticated && !!profile,
  });

  const { data: watchlist, isLoading: watchlistLoading } = trpc.portfolio.getWatchlist.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      toast.success("Logged out successfully");
      setLocation("/login");
    } catch (error) {
      toast.error("Failed to logout");
    }
  };

  const heroTitle = isAuthenticated
    ? `Welcome back, ${user?.name || "investor"}!`
    : "Invest Smarter with AI-Powered Insights";

  const heroSubtitle = isAuthenticated
    ? "Track your investments and discover new opportunities"
    : "Take our quiz to get personalized stock and fund recommendations matching your risk profile";

  const topStocks = recommendations?.recommendations?.topStocks?.slice(0, 10) || [];
  const topFunds = recommendations?.recommendations?.topMutualFunds?.slice(0, 10) || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="border-b border-slate-700/50 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => setLocation("/")}
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-300 shadow-inner shadow-slate-950/20">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-base font-semibold text-white">Human Centric</p>
              <p className="text-xs text-slate-400/90 truncate">Investor-focused financial command center</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3 justify-end">
            {isAuthenticated ? (
              <>
                {!profile && !profileLoading && (
                  <Button
                    onClick={() => setLocation("/quiz")}
                    className="bg-emerald-500/95 hover:bg-emerald-600"
                  >
                    <Brain className="w-4 h-4 mr-2" />
                    Take Quiz
                  </Button>
                )}
                {profile && (
                  <Button
                    onClick={() => setLocation("/recommendations")}
                    variant="outline"
                    className="border-slate-700 text-slate-200 hover:bg-slate-800"
                  >
                    My Portfolio
                  </Button>
                )}
                <Button
                  onClick={() => setLocation("/quiz")}
                  variant="outline"
                  className="border-emerald-500 text-emerald-300 hover:bg-emerald-500/10"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Retake Quiz
                </Button>
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  className="border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </>
            ) : (
              <Button onClick={() => setLocation("/login")} className="bg-emerald-500/95 hover:bg-emerald-600">Sign In</Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        {/* Line 1: Header / Hero Info */}
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/15 bg-slate-900/70 px-4 py-2 text-sm text-emerald-300 shadow-sm shadow-slate-950/20">
            <TrendingUp className="w-4 h-4 text-emerald-300" />
            Market intelligence that adapts to your investing style
          </div>
          <div className="space-y-4">
            <h1 className="text-4xl sm:text-5xl font-semibold tracking-tight text-white">
              Human Centric Investment System
            </h1>
            <p className="max-w-3xl text-slate-300 text-lg leading-8">
              Personalized portfolio analytics, refined asset recommendations, and investor-grade insights in a modern financial workspace.
            </p>
          </div>
        </div>

        {/* Line 2: Stats (Portfolio signal and Coverage) */}
        <div className="grid gap-6 sm:grid-cols-2">
          <div className="glass-panel rounded-3xl p-6 border-slate-700/50">
            <p className="text-sm uppercase tracking-[0.24em] text-slate-400">Portfolio signal</p>
            <p className="mt-3 text-4xl font-semibold text-white">+8.3%</p>
            <p className="mt-2 text-slate-400 text-sm">Active recommendations outperforming the benchmark</p>
          </div>
          <div className="glass-panel rounded-3xl p-6 border-slate-700/50">
            <p className="text-sm uppercase tracking-[0.24em] text-slate-400">Coverage</p>
            <p className="mt-3 text-4xl font-semibold text-white">Global markets</p>
            <p className="mt-2 text-slate-400 text-sm">Stocks, funds, and macro-driven insights across asset classes</p>
          </div>
        </div>

        {!isAuthenticated && (
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-start">
            <Button 
              size="lg" 
              onClick={() => setLocation("/login")} 
              className="bg-emerald-500/95 hover:bg-emerald-600 text-slate-950"
            >
              Sign In / Register
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => setLocation("/login")}
              className="border-slate-700 text-slate-200 hover:bg-slate-800"
            >
              Take Quiz
            </Button>
          </div>
        )}

        {/* Line 3: Live Search */}
        <div className="glass-panel rounded-[2rem] p-6 border-slate-700/50 shadow-xl">
          <div className="flex items-center justify-between gap-4 mb-6">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Quick access</p>
              <h2 className="mt-3 text-2xl font-semibold text-white">Live search</h2>
            </div>
            <div className="h-11 w-11 rounded-2xl bg-slate-900/80 flex items-center justify-center text-slate-300">
              <Search className="w-5 h-5" />
            </div>
          </div>
          <div className="flex gap-3 max-w-3xl">
            <Input
              placeholder="Search AAPL, funds, sectors"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1 bg-slate-950/80 border-slate-700 text-white placeholder:text-slate-500 h-12 text-base"
            />
            <Button onClick={handleSearch} className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 h-12 px-6 font-semibold">
              Go
            </Button>
          </div>
          <p className="mt-4 text-sm text-slate-400">
            Search live market symbols, funds, or company names with fast AI matching.
          </p>
        </div>

        {/* Line 4: Watchlist */}
        {isAuthenticated && (
          <div className="glass-panel rounded-[2rem] p-6 border-slate-700/50 shadow-xl">
            <div className="flex items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-rose-500 fill-rose-500/20" />
                <h2 className="text-2xl font-semibold text-white">My Watchlist</h2>
              </div>
              <Badge variant="outline" className="border-rose-500/20 text-rose-400 bg-rose-500/5 text-xs font-semibold px-2 py-0.5 rounded-full">
                {watchlist?.length || 0} Assets
              </Badge>
            </div>

            {watchlistLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <Skeleton className="h-16 bg-slate-800 rounded-xl" />
                <Skeleton className="h-16 bg-slate-800 rounded-xl" />
                <Skeleton className="h-16 bg-slate-800 rounded-xl" />
              </div>
            ) : watchlist && watchlist.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {watchlist.map((item) => (
                  <div
                    key={item.symbol}
                    onClick={() => setLocation(`/stock/${item.symbol}`)}
                    className="flex items-center justify-between p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-rose-500/40 cursor-pointer transition-all hover:bg-slate-900/90"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-lg bg-rose-500/10 text-rose-400 flex items-center justify-center font-bold text-xs">
                        {item.symbol.substring(0, 2)}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-white">{item.symbol}</p>
                        <p className="text-xs text-slate-400 capitalize">{item.assetType.replace("_", " ")}</p>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 bg-slate-900/30 rounded-2xl border border-dashed border-slate-800 max-w-lg mx-auto">
                <Heart className="w-8 h-8 text-slate-700 mx-auto mb-2" />
                <p className="text-slate-400 text-sm font-medium">Your watchlist is empty</p>
                <p className="text-xs text-slate-500 mt-1">Search assets to add them!</p>
              </div>
            )}
          </div>
        )}
      </section>

        {/* User Profile Info */}
        {isAuthenticated && profile && (
          <div className="max-w-2xl mx-auto mb-8">
            <Card className="bg-slate-800/50 border-slate-700 p-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider">Your Profile</p>
                    <p className="text-white font-semibold capitalize">
                      {profile.riskTolerance} Investor • {profile.timeHorizon?.replace("_", " ")}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setLocation("/recommendations")}
                    className="border-slate-600 text-slate-200 hover:bg-slate-800"
                  >
                    View All Recommendations
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}

      {/* Top Recommendations Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-emerald-400" />
              Top 20 Best-Matched Investments
            </h2>
            <p className="text-slate-400 text-sm mt-1">
              {profile
                ? `Personalized recommendations based on your ${profile.riskTolerance} risk profile`
                : "Popular stocks and funds with real-time market data (take quiz for personalized)"}
            </p>
          </div>
        </div>

        {recLoading ? (
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map(i => (
                <Skeleton key={i} className="h-20 bg-slate-800" />
              ))}
            </div>
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map(i => (
                <Skeleton key={i} className="h-20 bg-slate-800" />
              ))}
            </div>
          </div>
        ) : (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Top Stocks */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                Top 10 Stocks
              </h3>
              <div className="space-y-3">
                {topStocks.map((stock: any, idx: number) => (
                  <Card
                    key={stock.symbol}
                    className="bg-slate-800/50 border-slate-700 hover:border-emerald-500/50 cursor-pointer transition-all"
                    onClick={() => setLocation(`/stock/${stock.symbol}`)}
                  >
                    <div className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-sm font-bold">
                          {idx + 1}
                        </span>
                        <div>
                          <p className="text-white font-semibold">{stock.symbol}</p>
                          <p className="text-slate-400 text-sm truncate max-w-[150px]">{stock.name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-emerald-400 font-bold">{stock.matchScore}%</p>
                        <p className="text-slate-500 text-xs">Vol: {stock.volatility}%</p>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-500" />
                    </div>
                  </Card>
                ))}
                {topStocks.length === 0 && (
                  <p className="text-slate-400 text-center py-4">No stock recommendations available</p>
                )}
              </div>
            </div>

            {/* Top Mutual Funds */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-400" />
                Top 10 Mutual Funds
              </h3>
              <div className="space-y-3">
                {topFunds.map((fund: any, idx: number) => (
                  <Card
                    key={fund.symbol}
                    className="bg-slate-800/50 border-slate-700 hover:border-blue-500/50 cursor-pointer transition-all"
                    onClick={() => setLocation(`/stock/${fund.symbol}`)}
                  >
                    <div className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-sm font-bold">
                          {idx + 1}
                        </span>
                        <div>
                          <p className="text-white font-semibold">{fund.symbol}</p>
                          <p className="text-slate-400 text-sm truncate max-w-[150px]">{fund.name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-blue-400 font-bold">{fund.matchScore}%</p>
                        <p className="text-slate-500 text-xs">Vol: {fund.volatility}%</p>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-500" />
                    </div>
                  </Card>
                ))}
                {topFunds.length === 0 && (
                  <p className="text-slate-400 text-center py-4">No fund recommendations available</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* View All Button */}
        <div className="text-center mt-8">
          {profile && (
            <Button
              onClick={() => setLocation("/recommendations")}
              className="bg-emerald-500 hover:bg-emerald-600"
            >
              View All Recommendations
            </Button>
          )}
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="glass-card rounded-[1.75rem] p-6">
            <div className="flex items-center gap-3 mb-4">
              <Search className="w-6 h-6 text-emerald-400" />
              <h3 className="text-lg font-semibold text-white">Live search</h3>
            </div>
            <p className="text-slate-300">
              Discover stocks and mutual funds with fast matching and market-aware pricing.
            </p>
          </div>

          <div className="glass-card rounded-[1.75rem] p-6">
            <div className="flex items-center gap-3 mb-4">
              <Brain className="w-6 h-6 text-emerald-400" />
              <h3 className="text-lg font-semibold text-white">AI insights</h3>
            </div>
            <p className="text-slate-300">
              Get prediction-backed signals and confidence scores without the noise.
            </p>
          </div>

          <div className="glass-card rounded-[1.75rem] p-6">
            <div className="flex items-center gap-3 mb-4">
              <Target className="w-6 h-6 text-emerald-400" />
              <h3 className="text-lg font-semibold text-white">Portfolio fit</h3>
            </div>
            <p className="text-slate-300">
              Match investments to your risk profile with concise, actionable alignment scores.
            </p>
          </div>
        </div>

        <div className="mt-12 glass-panel rounded-[2rem] border-slate-700/50 p-8">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="flex gap-4">
              <BarChart3 className="w-6 h-6 text-emerald-400 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-white mb-2">Real-time alignment</h4>
                <p className="text-slate-300">
                  Market data and scores update from live API sources, keeping recommendations dynamic and responsive.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <AlertCircle className="w-6 h-6 text-emerald-400 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-white mb-2">Clear investor logic</h4>
                <p className="text-slate-300">
                  Designed to reduce noise and make each metric meaningful for smarter decisions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
