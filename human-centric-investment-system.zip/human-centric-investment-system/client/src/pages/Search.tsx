import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Search as SearchIcon, TrendingUp, TrendingDown } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Search() {
  const [, setLocation] = useLocation();
  const searchParams = useSearch();
  const initialQuery = new URLSearchParams(searchParams).get("q") || "";
  const [query, setQuery] = useState(initialQuery);
  const [debouncedQuery, setDebouncedQuery] = useState(initialQuery);

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);

  // Search API call
  const { data: searchResults, isLoading } = trpc.market.search.useQuery(
    { query: debouncedQuery },
    { enabled: debouncedQuery.length > 0 }
  );

  const handleSelectStock = (symbol: string) => {
    setLocation(`/stock/${symbol}`);
  };

  const handleSearch = () => {
    setDebouncedQuery(query);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <div className="bg-slate-950/95 border-b border-slate-800 sticky top-0 z-10 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <SearchIcon className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
              <Input
                autoFocus
                placeholder="Search by symbol, company, fund, or sector"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-10 bg-slate-900/80 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>
            <Button onClick={handleSearch} className="bg-emerald-500 hover:bg-emerald-600 text-slate-950">Search</Button>
          </div>
          <p className="text-sm text-slate-400 mb-4">
            Search live market assets with responsive, API-driven results.
          </p>
          {debouncedQuery && (
            <p className="text-sm text-slate-500">
              {isLoading ? "Searching..." : `Found ${searchResults?.length || 0} results for "${debouncedQuery}"`}
            </p>
          )}
        </div>
      </div>

      {/* Results */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {!debouncedQuery ? (
          <div className="text-center py-12">
            <SearchIcon className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600">Start typing to search for stocks and mutual funds</p>
          </div>
        ) : isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <Card key={i} className="glass-card rounded-3xl p-5">
                <Skeleton className="h-6 w-full mb-2" />
                <Skeleton className="h-4 w-3/4" />
              </Card>
            ))}
          </div>
        ) : searchResults && searchResults.length > 0 ? (
          <div className="space-y-3">
            {searchResults.map((result: any) => (
              <Card
                key={`${result.symbol}-${result.type}`}
                className="bg-slate-900/65 border border-slate-800/80 rounded-[1.5rem] p-5 hover:border-emerald-500/30 hover:bg-slate-900/80 hover:shadow-2xl transition-all cursor-pointer"
                onClick={() => handleSelectStock(result.symbol)}
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-bold text-lg text-white">{result.symbol}</h3>
                      <span className="text-[11px] font-semibold bg-slate-800 text-slate-300 px-2 py-0.5 rounded-lg border border-slate-700/50">
                        {result.type === "mutual_fund" ? "Mutual Fund" : "Stock"}
                      </span>
                      {result.exchange && (
                        <span className="text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-lg border border-emerald-500/20">{result.exchange}</span>
                      )}
                    </div>
                    <p className="text-sm text-slate-200 mt-1.5">{result.name}</p>
                    {result.sector && <p className="text-xs text-slate-300 mt-1">{result.sector}</p>}
                  </div>
                  <Button variant="outline" size="sm" className="border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white rounded-xl px-4 transition-all">
                    View Details
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-slate-600">No results found for "{debouncedQuery}"</p>
            <p className="text-sm text-slate-500 mt-2">Try searching with a different term</p>
          </div>
        )}
      </div>
    </div>
  );
}
