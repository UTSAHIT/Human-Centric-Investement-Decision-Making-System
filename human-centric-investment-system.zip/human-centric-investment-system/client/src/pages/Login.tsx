import { useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Brain, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();

  const [loginData, setLoginData] = useState({ email: "", password: "" });
  const [registerData, setRegisterData] = useState({ name: "", email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const utils = trpc.useContext();

  const saveAuthState = (token: string, user: any) => {
    const primary = rememberMe ? localStorage : sessionStorage;
    const fallback = rememberMe ? sessionStorage : localStorage;

    primary.setItem("auth_token", token);
    primary.setItem("user", JSON.stringify(user));
    fallback.removeItem("auth_token");
    fallback.removeItem("user");
  };

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: (data) => {
      if (data.success && data.token) {
        saveAuthState(data.token, data.user);
        utils.auth.me.invalidate();
        toast.success("Welcome back!");
        setLocation("/");
      } else {
        toast.error(data.error || "Login failed");
      }
    },
    onError: (error) => {
      console.error("Login error:", error);
      toast.error(error.message || "Login failed. Please try again.");
    },
  });

  const registerMutation = trpc.auth.register.useMutation({
    onSuccess: (data) => {
      if (data.success && data.token) {
        saveAuthState(data.token, data.user);
        utils.auth.me.invalidate();
        toast.success("Account created successfully!");
        setLocation("/");
      } else {
        toast.error(data.error || "Registration failed");
      }
    },
    onError: (error) => {
      console.error("Register error:", error);
      toast.error(error.message || "Registration failed. Please try again.");
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginData.email || !loginData.password) {
      toast.error("Please fill in all fields");
      return;
    }
    loginMutation.mutate(loginData);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!registerData.name || !registerData.email || !registerData.password) {
      toast.error("Please fill in all fields");
      return;
    }
    registerMutation.mutate(registerData);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-500/15 rounded-full mb-4 border border-emerald-500/20 shadow-lg shadow-emerald-500/10">
            <Brain className="w-8 h-8 text-emerald-400" />
          </div>
          <h1 className="text-4xl font-semibold tracking-tight text-white">Human Centric</h1>
          <p className="text-slate-400 mt-2 text-sm max-w-md mx-auto">
            Premium investment intelligence built for modern wealth management.
          </p>
        </div>

<Card className="glass-card rounded-[2rem] border-slate-700/90 shadow-slate-950/50 p-1">
  <div className="glass-surface rounded-[2rem] p-8">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="flex w-full bg-slate-900/50 p-1 rounded-lg mb-6">
              <TabsTrigger 
                value="login" 
                className="flex-1 data-[state=active]:bg-emerald-500 data-[state=active]:text-white"
              >
                Sign In
              </TabsTrigger>
              <TabsTrigger 
                value="register" 
                className="flex-1 data-[state=active]:bg-emerald-500 data-[state=active]:text-white"
              >
                Register
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="space-y-4">
              <form onSubmit={handleLogin}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="email" className="text-slate-300">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@domain.com"
                      value={loginData.email}
                      onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                      className="bg-slate-950/80 border-slate-700 text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <div className="relative">
                    <Label htmlFor="password" className="text-slate-300">Password</Label>
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      className="bg-slate-950/80 border-slate-700 text-white placeholder:text-slate-500 pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      className="absolute right-3 top-10 text-slate-400 hover:text-slate-100 transition-colors"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <div className="flex items-center justify-between text-sm text-slate-400">
                    <label className="inline-flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="h-4 w-4 rounded border-slate-600 bg-slate-900 text-emerald-500 focus:ring-emerald-400"
                      />
                      Remember me
                    </label>
                    <button
                      type="button"
                      onClick={() => setLocation("/login")}
                      className="text-slate-300 hover:text-white"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-semibold"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Signing in..." : "Continue"}
                  </Button>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="register" className="space-y-4">
              <form onSubmit={handleRegister}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name" className="text-slate-300">Full Name</Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="John Doe"
                      value={registerData.name}
                      onChange={(e) => setRegisterData({ ...registerData, name: e.target.value })}
                      className="bg-slate-950/80 border-slate-700 text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="reg-email" className="text-slate-300">Email</Label>
                    <Input
                      id="reg-email"
                      type="email"
                      placeholder="you@domain.com"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                      className="bg-slate-950/80 border-slate-700 text-white placeholder:text-slate-500"
                      required
                    />
                  </div>
                  <div className="relative">
                    <Label htmlFor="reg-password" className="text-slate-300">Password</Label>
                    <Input
                      id="reg-password"
                      type={showRegisterPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                      className="bg-slate-950/80 border-slate-700 text-white placeholder:text-slate-500 pr-10"
                      minLength={6}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegisterPassword((prev) => !prev)}
                      className="absolute right-3 top-10 text-slate-400 hover:text-slate-100 transition-colors"
                      aria-label={showRegisterPassword ? "Hide password" : "Show password"}
                    >
                      {showRegisterPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-semibold"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "Creating account..." : "Create Account"}
                  </Button>
                </div>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </Card>

        <p className="text-center text-slate-500 text-sm mt-6">
          By continuing, you agree to our Terms of Service and Privacy Policy.
        </p>
      </div>
    </div>
  );
}