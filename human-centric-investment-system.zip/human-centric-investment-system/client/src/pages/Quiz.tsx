import { useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, CheckCircle, Brain, Shield, Zap, TrendingUp, DollarSign, Lock, ArrowRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { TRPCClientError } from "@trpc/client";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Quiz() {
  const { isAuthenticated, loading } = useAuth({ redirectOnUnauthenticated: false });
  const [, setLocation] = useLocation();

  // All hooks must be called at top level
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState({
    ageGroup: "",
    investmentGoal: "",
    volatilityReaction: "",
    timeHorizon: "",
    experienceLevel: "",
    monthlyInvestment: "",
  });

  const [calculatedProfile, setCalculatedProfile] = useState<{
    riskTolerance: "conservative" | "moderate" | "aggressive";
    title: string;
    description: string;
    icon: any;
    color: string;
  } | null>(null);
  const [forceRetake, setForceRetake] = useState(false);

  const { data: existingProfile, isLoading: profileLoading } = trpc.quiz.getProfile.useQuery(undefined, {
    retry: false,
    enabled: isAuthenticated,
  });

  const submitQuizMutation = trpc.quiz.submitQuiz.useMutation({
    networkMode: 'always',
    retry: 1,
  });

  const questions_list = [
    {
      id: "ageGroup",
      question: "What is your investment age group?",
      description: "Your investment horizon is often correlated with your age group to optimize asset compounding.",
      type: "radio",
      options: [
        { value: "under_30", label: "Under 30 years old (High compound potential)", score: 10 },
        { value: "30_50", label: "30 to 50 years old (Balanced growth phase)", score: 6 },
        { value: "over_50", label: "Over 50 years old (Capital preservation phase)", score: 2 },
      ],
    },
    {
      id: "investmentGoal",
      question: "What is your primary investment goal?",
      description: "Tell us what you want to achieve with your hard-earned capital.",
      type: "radio",
      options: [
        { value: "wealth_preservation", label: "Wealth Preservation - Avoid losing money & match inflation", score: 2 },
        { value: "income_generation", label: "Income Generation - Receive steady dividend or interest payouts", score: 6 },
        { value: "capital_growth", label: "Capital Growth - Maximize capital gains over the long run", score: 10 },
      ],
    },
    {
      id: "volatilityReaction",
      question: "If your portfolio dropped 20% in a month due to market changes, how would you react?",
      description: "Your psychological response to volatility is key to your optimal portfolio allocation.",
      type: "radio",
      options: [
        { value: "sell_all", label: "Sell everything immediately to prevent further losses", score: 2 },
        { value: "do_nothing", label: "Do nothing and patiently wait for market recovery", score: 6 },
        { value: "buy_more", label: "View it as a discount and buy more assets", score: 10 },
      ],
    },
    {
      id: "timeHorizon",
      question: "How long do you plan to hold your investments before withdrawing significant funds?",
      description: "Longer durations allow for higher risk tolerance as markets have time to cycle.",
      type: "radio",
      options: [
        { value: "short_term", label: "Short Term (Less than 3 years)", score: 2 },
        { value: "medium_term", label: "Medium Term (3 to 10 years)", score: 6 },
        { value: "long_term", label: "Long Term (More than 10 years)", score: 10 },
      ],
    },
    {
      id: "experienceLevel",
      question: "How would you describe your understanding of financial markets and investing?",
      description: "Your familiarity with asset classes helps us tailor educational alerts.",
      type: "radio",
      options: [
        { value: "beginner", label: "Beginner - Brand new to stock markets & mutual funds", score: 2 },
        { value: "intermediate", label: "Intermediate - Have bought stocks/funds before, understand basics", score: 6 },
        { value: "advanced", label: "Advanced - Actively trade, understand options, metrics & indicators", score: 10 },
      ],
    },
    {
      id: "monthlyInvestment",
      question: "How much can you comfortably invest monthly?",
      description: "This helps calculate compounding forecasts and dollar-cost averaging projections.",
      type: "text",
      placeholder: "e.g., 500",
    },
  ];

  if (loading || (isAuthenticated && profileLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center p-8">
        <div className="max-w-xl w-full">
          <Button variant="ghost" onClick={() => setLocation("/")} className="text-slate-400 hover:text-white mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <Card className="p-8 bg-slate-800 border-slate-700 text-center relative overflow-hidden shadow-2xl space-y-6">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl" />
            <div className="w-16 h-16 bg-slate-700/50 rounded-full flex items-center justify-center mx-auto animate-pulse">
              <Lock className="w-8 h-8 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">Sign In Required</h3>
              <p className="text-slate-300 text-sm leading-relaxed">
                Please sign in to take the investment quiz and get personalized recommendations.
              </p>
            </div>
            <Button 
              onClick={() => setLocation("/login")}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold"
              size="lg"
            >
              Go to Sign In
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  if (existingProfile && !forceRetake) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="max-w-xl w-full">
          <Card className="p-8 bg-slate-800 border-slate-700 text-white shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl" />

            <div className="text-center mb-6">
              <div className="inline-flex p-4 rounded-full bg-slate-700/50 mb-4 border border-slate-600">
                <CheckCircle className="w-12 h-12 text-emerald-400" />
              </div>
              <h1 className="text-sm font-semibold text-emerald-400 uppercase tracking-widest">Profile Already Exists</h1>
              <h2 className="text-3xl font-extrabold text-white mt-1">Quiz Already Completed</h2>
            </div>

            <p className="text-slate-300 text-center leading-relaxed text-base mb-8">
              Your current profile is preserved. Retake the quiz only when you want to update your risk profile.
            </p>

            <div className="space-y-4 bg-slate-900/60 p-5 rounded-xl border border-slate-700 mb-8">
              <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-3">
                <span className="text-slate-400">Risk Profile:</span>
                <span className="font-bold text-white uppercase">{existingProfile.riskTolerance}</span>
              </div>
              <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-3">
                <span className="text-slate-400">Investment Goal:</span>
                <span className="font-bold text-white capitalize">{existingProfile.investmentGoal?.replace("_", " ") || "N/A"}</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-400">Time Horizon:</span>
                <span className="font-bold text-white capitalize">{existingProfile.timeHorizon?.replace("_", " ") || "N/A"}</span>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Button
                onClick={() => setLocation("/recommendations")}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold"
              >
                <ArrowRight className="w-4 h-4 mr-2" />
                View Recommendations
              </Button>
              <Button
                onClick={() => {
                  setForceRetake(true);
                  setStep(0);
                  setFormData({
                    ageGroup: "",
                    investmentGoal: "",
                    volatilityReaction: "",
                    timeHorizon: "",
                    experienceLevel: "",
                    monthlyInvestment: "",
                  });
                  setCalculatedProfile(null);
                }}
                variant="outline"
                className="w-full border-slate-700 text-white hover:bg-slate-700"
              >
                Retake Quiz
              </Button>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  const currentQuestion = questions_list[step];
  const progress = ((step + 1) / questions_list.length) * 100;

  const calculateResults = () => {
    let score = 0;

    const q1 = questions_list[0]?.options?.find(o => o.value === formData.ageGroup);
    score += q1 ? q1.score : 6;

    const q2 = questions_list[1]?.options?.find(o => o.value === formData.investmentGoal);
    score += q2 ? q2.score : 6;

    const q3 = questions_list[2]?.options?.find(o => o.value === formData.volatilityReaction);
    score += q3 ? q3.score : 6;

    const q4 = questions_list[3]?.options?.find(o => o.value === formData.timeHorizon);
    score += q4 ? q4.score : 6;

    const q5 = questions_list[4]?.options?.find(o => o.value === formData.experienceLevel);
    score += q5 ? q5.score : 6;

    let tolerance: "conservative" | "moderate" | "aggressive" = "moderate";
    let title = "Balanced Investor";
    let description = "You balance steady asset appreciation with modest downside protection. A combination of diversified equity mutual funds, blue-chip stocks, and fixed-income assets fits you best.";
    let icon = Brain;
    let color = "text-blue-500 border-blue-200 bg-blue-50";

    if (score <= 22) {
      tolerance = "conservative";
      title = "Conservative Investor";
      description = "Your primary focus is wealth preservation and stable, low-volatility returns. High-quality dividend-paying stocks and defensive mutual funds are ideal for your profile.";
      icon = Shield;
      color = "text-emerald-600 border-emerald-200 bg-emerald-50";
    } else if (score >= 38) {
      tolerance = "aggressive";
      title = "Aggressive Investor";
      description = "You actively seek maximum capital appreciation and are highly comfortable with short-term market swings. You thrive in high-growth equities, sector mutual funds, and momentum investing.";
      icon = Zap;
      color = "text-purple-600 border-purple-200 bg-purple-50";
    }

    return {
      tolerance,
      title,
      description,
      icon,
      color,
    };
  };

  const handleNext = async () => {
    if (step < questions_list.length - 1) {
      setStep(step + 1);
    } else {
      const result = calculateResults();

      setCalculatedProfile({
        riskTolerance: result.tolerance,
        title: result.title,
        description: result.description,
        icon: result.icon,
        color: result.color,
      });
    }
  };

  const handleSaveProfile = async () => {
    if (!calculatedProfile) return;

    try {
      const dbTimeHorizon = formData.timeHorizon === "short_term" ? "short_term" : formData.timeHorizon === "long_term" ? "long_term" : "medium_term";
      const dbExperience = formData.experienceLevel === "beginner" ? "beginner" : formData.experienceLevel === "advanced" ? "advanced" : "intermediate";

      const result = await submitQuizMutation.mutateAsync({
        riskTolerance: calculatedProfile.riskTolerance,
        investmentGoal: formData.investmentGoal,
        timeHorizon: dbTimeHorizon,
        experienceLevel: dbExperience,
        monthlyInvestment: formData.monthlyInvestment ? parseFloat(formData.monthlyInvestment) : undefined,
        quizResponses: formData,
      });

      const success = result?.success ?? result?.profile != null;
      if (success) {
        toast.success("Investment profile created successfully!");
        setLocation("/recommendations");
      } else {
        toast.error((result as any)?.error || "Failed to save profile. Please try again.");
      }
    } catch (error: unknown) {
      console.error("Quiz save error:", error);
      if (
        error instanceof TRPCClientError &&
        error.data?.code === "UNAUTHORIZED"
      ) {
        toast.error("Session expired. Please sign in again.");
        localStorage.removeItem("auth_token");
        localStorage.removeItem("user");
        setLocation("/login");
        return;
      }

      const message =
        error instanceof Error
          ? error.message
          : typeof error === "object" && error !== null && "message" in error
          ? String((error as any).message)
          : "Failed to save investment profile. Please try again.";

      if (message.includes("Please login") || message.includes("UNAUTHORIZED")) {
        toast.error("Session expired. Please sign in again.");
        localStorage.removeItem("auth_token");
        localStorage.removeItem("user");
        setLocation("/login");
      } else {
        toast.error(message);
      }
    }
  };

  const handlePrevious = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  const handleChange = (value: string) => {
    setFormData({
      ...formData,
      [currentQuestion.id]: value,
    });
  };

  const isCurrentAnswered = formData[currentQuestion.id as keyof typeof formData] !== "";

  if (calculatedProfile) {
    const IconComponent = calculatedProfile.icon;
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="max-w-xl w-full">
          <Card className="p-8 bg-slate-800 border-slate-700 text-white shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl" />

            <div className="text-center mb-6">
              <div className="inline-flex p-4 rounded-full bg-slate-700/50 mb-4 border border-slate-600">
                <IconComponent className="w-12 h-12 text-emerald-400" />
              </div>
              <h1 className="text-sm font-semibold text-emerald-400 uppercase tracking-widest">Profile Analysis Complete</h1>
              <h2 className="text-3xl font-extrabold text-white mt-1">{calculatedProfile.title}</h2>
            </div>

            <p className="text-slate-300 text-center leading-relaxed text-base mb-8">
              {calculatedProfile.description}
            </p>

            <div className="space-y-4 bg-slate-900/60 p-5 rounded-xl border border-slate-700 mb-8">
              <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-3">
                <span className="text-slate-400">Risk Profile:</span>
                <span className="font-bold text-white uppercase">{calculatedProfile.riskTolerance}</span>
              </div>
              <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-3">
                <span className="text-slate-400">Investment Goal:</span>
                <span className="font-bold text-white capitalize">{formData.investmentGoal.replace("_", " ")}</span>
              </div>
              <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-3">
                <span className="text-slate-400">Horizon:</span>
                <span className="font-bold text-white capitalize">{formData.timeHorizon.replace("_", " ")}</span>
              </div>
              {formData.monthlyInvestment && (
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-400">Monthly Contribution:</span>
                  <span className="font-bold text-emerald-400">${formData.monthlyInvestment}</span>
                </div>
              )}
            </div>

            <div className="flex gap-4">
              <Button
                variant="outline"
                onClick={() => setCalculatedProfile(null)}
                className="flex-1 border-slate-700 text-white hover:bg-slate-700"
              >
                Back to Edit
              </Button>
              <Button
                onClick={handleSaveProfile}
                disabled={submitQuizMutation.isPending}
                className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold"
              >
                Confirm & View Recommendations
              </Button>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-between p-4">
      <div className="max-w-2xl mx-auto w-full pt-6">
        <Button variant="ghost" onClick={() => setLocation("/")} className="text-slate-400 hover:text-white mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="mb-8 text-center">
          <h1 className="text-3xl font-extrabold text-white">Investor Profiling DSS</h1>
          <p className="text-slate-400 mt-2">Answer these questions to define your risk capacity and receive mathematically matched recommendations.</p>
        </div>

        <Card className="p-8 bg-slate-800 border-slate-700 text-white shadow-xl relative">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <h2 className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                Question {step + 1} of {questions_list.length}
              </h2>
              <span className="text-xs text-slate-400">{Math.round(progress)}% Complete</span>
            </div>
            <Progress value={progress} className="h-1 bg-slate-700" />
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-bold text-white mb-2">{currentQuestion.question}</h2>
            <p className="text-sm text-slate-400 mb-6">{currentQuestion.description}</p>

            {currentQuestion.type === "radio" ? (
              <RadioGroup value={formData[currentQuestion.id as keyof typeof formData]} onValueChange={handleChange}>
                <div className="space-y-3">
                  {(currentQuestion as any).options?.map((option: any) => (
                    <div
                      key={option.value}
                      onClick={() => handleChange(option.value)}
                      className={`flex items-center space-x-3 p-4 border rounded-xl hover:border-emerald-500 hover:bg-slate-700/50 cursor-pointer transition-all ${
                        formData[currentQuestion.id as keyof typeof formData] === option.value
                          ? "border-emerald-500 bg-emerald-500/10 text-white"
                          : "border-slate-700 bg-slate-800/40 text-slate-300"
                      }`}
                    >
                      <RadioGroupItem value={option.value} id={option.value} className="border-slate-500 text-emerald-500" />
                      <Label htmlFor={option.value} className="flex-1 cursor-pointer font-medium">
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            ) : (
              <div className="relative">
                <DollarSign className="absolute left-3 top-3.5 w-5 h-5 text-slate-400" />
                <Input
                  type="number"
                  placeholder={currentQuestion.placeholder}
                  value={formData[currentQuestion.id as keyof typeof formData]}
                  onChange={(e) => handleChange(e.target.value)}
                  className="text-lg bg-slate-900 border-slate-700 pl-10 h-12 text-white placeholder-slate-500 focus:border-emerald-500"
                />
              </div>
            )}
          </div>

          <div className="flex gap-4 justify-between border-t border-slate-700/60 pt-6">
            <Button variant="outline" onClick={handlePrevious} disabled={step === 0} className="px-6 border-slate-700 text-slate-300 hover:bg-slate-700">
              Previous
            </Button>
            <Button
              onClick={handleNext}
              disabled={!isCurrentAnswered || submitQuizMutation.isPending}
              className="px-8 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold"
            >
              {step === questions_list.length - 1 ? "Calculate Profile" : "Next Question"}
            </Button>
          </div>
        </Card>

        <div className="mt-6 flex items-center justify-center gap-2 text-slate-500 text-xs">
          <CheckCircle className="w-4 h-4 text-emerald-500/70" />
          Answers are processed locally using standard Modern Portfolio Theory allocation models.
        </div>
      </div>
      <div />
    </div>
  );
}
