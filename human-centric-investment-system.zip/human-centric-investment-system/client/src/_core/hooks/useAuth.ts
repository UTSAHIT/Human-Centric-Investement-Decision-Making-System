import { trpc } from "@/lib/trpc";
import { TRPCClientError } from "@trpc/client";
import { useCallback, useEffect, useState } from "react";

type User = {
  id: number;
  name: string;
  email: string;
  openId?: string | null;
  role?: string;
};

type UseAuthOptions = {
  redirectOnUnauthenticated?: boolean;
  redirectPath?: string;
};

export function useAuth(options?: UseAuthOptions) {
  const { redirectPath = "/login" } = options ?? {};
  const utils = trpc.useUtils();

  const authQuery = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  const serverUser = authQuery.data;
  const authLoading = authQuery.isLoading;
  const authError = authQuery.isError;

  const readStoredUser = () => {
    if (typeof window === "undefined") return null;

    const token =
      localStorage.getItem("auth_token") || sessionStorage.getItem("auth_token");
    if (!token) return null;

    const userStr =
      localStorage.getItem("user") || sessionStorage.getItem("user");
    if (!userStr) return null;

    try {
      return JSON.parse(userStr) as User;
    } catch {
      return null;
    }
  };

  const [storedUser, setStoredUser] = useState<User | null>(() => readStoredUser());

  useEffect(() => {
    if (typeof window === "undefined") return;

    const readUser = () => {
      setStoredUser(readStoredUser());
    };

    readUser();
    const handleStorage = (event: StorageEvent) => {
      if (event.key === "auth_token" || event.key === "user") {
        readUser();
      }
    };

    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, []);

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      localStorage.removeItem("auth_token");
      localStorage.removeItem("user");
      utils.auth.me.setData(undefined, null);
    },
  });

  const logout = useCallback(async () => {
    try {
      await logoutMutation.mutateAsync();
    } catch (error: unknown) {
      if (
        error instanceof TRPCClientError &&
        error.data?.code === "UNAUTHORIZED"
      ) {
        return;
      }
      throw error;
    } finally {
      localStorage.removeItem("auth_token");
      localStorage.removeItem("user");
      utils.auth.me.setData(undefined, null);
    }
  }, [logoutMutation, utils]);

  const user = serverUser ?? storedUser;
  const isAuthenticated = !!user;

  return {
    user,
    loading: authLoading || logoutMutation.isPending,
    error: null,
    isAuthenticated,
    refresh: () => {},
    logout,
  };
}