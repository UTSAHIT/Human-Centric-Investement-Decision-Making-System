type Profile = {
  riskTolerance: "conservative" | "moderate" | "aggressive";
  timeHorizon: "short_term" | "medium_term" | "long_term";
  investmentGoal?: string | null;
  experienceLevel?: "beginner" | "intermediate" | "advanced";
};

type ScoreInput = {
  assetType: "stock" | "mutual_fund";
  volatilityPercent: number;
  expectedChangePercent?: number;
  peRatio?: number | null;
  dividendYield?: number | null;
};

export function clampPercent(value: number, floor = 0, ceiling = 100) {
  if (!Number.isFinite(value)) return floor;
  return Math.max(floor, Math.min(ceiling, Math.round(value)));
}

export function calculateVolatilityPercent(rows: any[]) {
  const prices = rows.map((row) => Number(row.price ?? row.currentPrice ?? row.nav ?? 0)).filter((price) => price > 0);
  if (prices.length <= 1) return 10;
  const returns = prices.slice(1).map((price, index) => (price - prices[index]) / prices[index]);
  const mean = returns.reduce((sum, value) => sum + value, 0) / returns.length;
  const variance = returns.reduce((sum, value) => sum + Math.pow(value - mean, 2), 0) / returns.length;
  return Math.round(Math.min(80, Math.sqrt(variance) * Math.sqrt(252) * 100) * 10) / 10;
}

export function scoreAssetMatch(profile: Profile, asset: ScoreInput) {
  const volatility = Math.max(0, Math.min(80, asset.volatilityPercent || 0));
  const expectedChange = Math.max(-40, Math.min(40, asset.expectedChangePercent ?? 0));
  const isFund = asset.assetType === "mutual_fund";

  // 1. Expected Return Score (35%) - Profile-aware: reward good returns WITH low volatility
  let returnScore = 50;
  if (profile.riskTolerance === "conservative") {
    const isLowVol = volatility <= 20;
    if (expectedChange >= 5 && expectedChange <= 25) {
      returnScore = isLowVol ? 85 + (expectedChange - 5) : 65 + (expectedChange - 5);
    } else if (expectedChange > 25) {
      returnScore = isLowVol ? Math.min(100, 95 + (expectedChange - 25) * 0.5) : Math.max(45, 75 - (expectedChange - 25));
    } else if (expectedChange >= 0) {
      returnScore = 60 + (expectedChange * 2);
    } else {
      returnScore = Math.max(15, 50 + (expectedChange * 1.5));
    }
  } else if (profile.riskTolerance === "aggressive") {
    if (expectedChange >= 10) {
      returnScore = 85 + Math.min(15, (expectedChange - 10));
    } else if (expectedChange >= 0) {
      returnScore = 50 + (expectedChange * 3);
    } else {
      returnScore = Math.max(20, 50 + (expectedChange * 2));
    }
  } else {
    if (expectedChange >= 0) {
      returnScore = 50 + (expectedChange * 1.2);
    } else {
      returnScore = Math.max(20, 50 + (expectedChange * 1.5));
    }
  }

  // 2. User Risk Match Score (25%) - Profile-aware
  let riskMatchScore = 50;
  if (profile.riskTolerance === "conservative") {
    if (volatility <= 15) {
      riskMatchScore = 90;
    } else if (volatility <= 22) {
      riskMatchScore = 80;
    } else if (volatility <= 30) {
      riskMatchScore = 70;
    } else if (volatility <= 40) {
      riskMatchScore = 60;
    } else {
      riskMatchScore = Math.max(25, 55 - (volatility - 40));
    }
  } else if (profile.riskTolerance === "aggressive") {
    if (volatility >= 20 && volatility <= 40) {
      riskMatchScore = 85 + Math.min(15, (40 - volatility));
    } else if (volatility < 20) {
      riskMatchScore = 60 + (volatility);
    } else {
      riskMatchScore = Math.max(25, 90 - (volatility - 40));
    }
  } else {
    const dev = Math.abs(volatility - 15);
    riskMatchScore = Math.max(15, 90 - (dev * 2.5));
  }

  if (profile.timeHorizon === "short_term") {
    riskMatchScore = Math.max(0, riskMatchScore - (volatility * 1.5));
  } else if (profile.timeHorizon === "long_term") {
    riskMatchScore = Math.min(100, riskMatchScore + 10);
  }

  // 3. Market Momentum Score (20%)
  let momentumScore = 50;
  if (expectedChange > 1.5) {
    momentumScore = Math.min(100, 65 + (expectedChange * 1.0));
  } else if (expectedChange < -1.5) {
    momentumScore = Math.max(0, 35 + (expectedChange * 1.5));
  } else {
    momentumScore = 50;
  }

  // 4. Diversification Score (10%)
  let diversificationScore = 80;
  if (profile.riskTolerance === "conservative") {
    diversificationScore = isFund ? 95 : (volatility <= 25 ? 75 : 55);
  } else if (profile.riskTolerance === "aggressive") {
    diversificationScore = isFund ? 70 : 95;
  } else {
    diversificationScore = 85;
  }
  if (profile.experienceLevel === "beginner" && isFund) {
    diversificationScore = Math.min(100, diversificationScore + 5);
  }

  // 5. Liquidity Score (10%)
  const liquidityScore = isFund ? 80 : 95;

  // Calculate weighted final score
  const weightedScore = (0.35 * returnScore) + 
                        (0.25 * riskMatchScore) + 
                        (0.20 * momentumScore) + 
                        (0.10 * diversificationScore) + 
                        (0.10 * liquidityScore);

  const matchScore = clampPercent(weightedScore, 5, 100);

  return {
    matchScore,
    components: {
      expectedReturn: Math.round(returnScore),
      userRiskMatch: Math.round(riskMatchScore),
      marketMomentum: Math.round(momentumScore),
      diversification: Math.round(diversificationScore),
      liquidity: Math.round(liquidityScore)
    }
  };
}
